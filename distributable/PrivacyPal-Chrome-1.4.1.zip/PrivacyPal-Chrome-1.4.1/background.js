var self = (() => {
  // src/config/config.js
  var DEFAULT_ENDPOINTS = {
    // API endpoint for PrivacyPal Cloud services
    // Production: https://api.privacypal.ai
    // Development: http://localhost:42026 (can be changed in settings)
    apiUrl: "https://api.privacypal.ai",
    // User Portal endpoint for account management and subscriptions
    // Production: https://portal.privacypal.ai
    // Development: http://localhost:5174 (can be changed in settings)
    userPortalUrl: "https://portal.privacypal.ai"
  };
  async function loadConfig() {
    try {
      const stored = await chrome.storage.local.get(["apiUrl", "userPortalUrl"]);
      return {
        apiUrl: stored.apiUrl || DEFAULT_ENDPOINTS.apiUrl,
        userPortalUrl: stored.userPortalUrl || DEFAULT_ENDPOINTS.userPortalUrl
      };
    } catch (error) {
      console.warn("[PrivacyPal] Failed to load config from storage, using defaults:", error);
      return DEFAULT_ENDPOINTS;
    }
  }

  // src/background/service-worker.js
  var DEFAULT_CONFIG = {
    enabled: true,
    apiUrl: DEFAULT_ENDPOINTS.apiUrl,
    userPortalUrl: DEFAULT_ENDPOINTS.userPortalUrl,
    // apiKey is no longer stored here - it comes from authenticated user's JWT token
    debug: true,
    showNotifications: true
  };
  var stats = {
    requestsIntercepted: 0,
    responsesModified: 0,
    dataProtected: 0,
    lastInterception: null,
    sessionStart: Date.now(),
    continuationIds: []
    // Track all continuationIds for accurate stats
  };
  async function getCurrentJWTToken() {
    try {
      const result = await chrome.storage.local.get(["privacypal_session"]);
      const session = result.privacypal_session;
      console.log("[PrivacyPal] \u{1F50D} Checking session:", {
        hasSession: !!session,
        hasJwtTokens: !!session?.jwtTokens,
        hasAccessToken: !!session?.jwtTokens?.access_token,
        tokenLength: session?.jwtTokens?.access_token?.length || 0
      });
      if (session?.jwtTokens?.access_token) {
        const token = session.jwtTokens.access_token;
        console.log("[PrivacyPal] \u2705 Token retrieved:", {
          length: token.length,
          preview: `${token.substring(0, 20)}...${token.substring(token.length - 10)}`
        });
        return token;
      }
      console.warn("[PrivacyPal] \u26A0\uFE0F No access token in session");
      return null;
    } catch (error) {
      console.error("[PrivacyPal] \u274C Failed to get JWT token:", error);
      return null;
    }
  }
  chrome.runtime.onInstalled.addListener(async (details) => {
    console.log("[PrivacyPal] Extension installed:", details.reason);
    const config = await loadConfig();
    const initialConfig = {
      ...DEFAULT_CONFIG,
      apiUrl: config.apiUrl,
      userPortalUrl: config.userPortalUrl
    };
    const existing = await chrome.storage.local.get(["apiUrl", "userPortalUrl", "enabled", "debug", "showNotifications"]);
    const configToSave = {
      ...DEFAULT_CONFIG,
      apiUrl: existing.apiUrl || config.apiUrl,
      userPortalUrl: existing.userPortalUrl || config.userPortalUrl,
      enabled: existing.enabled !== void 0 ? existing.enabled : DEFAULT_CONFIG.enabled,
      debug: existing.debug !== void 0 ? existing.debug : DEFAULT_CONFIG.debug,
      showNotifications: existing.showNotifications !== void 0 ? existing.showNotifications : DEFAULT_CONFIG.showNotifications
    };
    await chrome.storage.local.set(configToSave);
    await chrome.storage.local.set({ stats });
    console.log("[PrivacyPal] Configuration initialized");
    if (details.reason === "install") {
      const finalConfig = await loadConfig();
      chrome.tabs.create({
        url: finalConfig.userPortalUrl
      });
    }
  });
  chrome.runtime.onConnect.addListener((port) => {
    console.log("[PrivacyPal] Service worker connected");
    port.onDisconnect.addListener(() => {
      console.log("[PrivacyPal] Service worker disconnected");
    });
  });
  try {
    if (chrome && chrome.alarms) {
      chrome.alarms.create("privacypal-keepalive", {
        delayInMinutes: 0.25,
        // 15 seconds
        periodInMinutes: 0.25
        // Repeat every 15 seconds
      }).catch((err) => {
        console.warn("[PrivacyPal] Could not create keep-alive alarm:", err);
      });
      chrome.alarms.onAlarm.addListener((alarm) => {
        if (alarm && alarm.name === "privacypal-keepalive") {
          try {
            chrome.storage.local.get(["keepAlive"], () => {
              if (chrome.runtime.lastError) {
                console.log("[PrivacyPal] Keep-alive ping:", chrome.runtime.lastError.message);
              }
            });
          } catch (err) {
          }
        }
      });
    }
  } catch (error) {
    console.warn("[PrivacyPal] Keep-alive setup failed (non-critical):", error.message);
  }
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log("[PrivacyPal] Message received:", request.action || request.type, {
      from: sender?.tab?.url || sender?.url || "unknown",
      hasData: !!request.data,
      hasApiKey: !!request.apiKey
    });
    chrome.storage.local.get(["keepAlive"], () => {
    });
    if (request.type === "OAUTH_COMPLETE") {
      console.log("[PrivacyPal] OAuth completion received:", { state: request.state, success: request.success });
      sendResponse({ success: true, received: true });
      return true;
    }
    switch (request.action) {
      case "ping":
        sendResponse({ success: true, pong: true });
        return false;
      case "interceptorReady":
        handleInterceptorReady(request, sender);
        sendResponse({ success: true });
        break;
      case "requestIntercepted":
        handleRequestIntercepted(request, sender);
        sendResponse({ success: true });
        break;
      case "encodeData":
        (async () => {
          let responseSent = false;
          const safeSendResponse = (response) => {
            if (!responseSent) {
              try {
                sendResponse(response);
                responseSent = true;
                console.log("[PrivacyPal] \u2705 EncodeData response sent successfully");
              } catch (err) {
                console.error("[PrivacyPal] \u274C Failed to send response (channel closed):", err);
                responseSent = true;
              }
            }
          };
          try {
            let apiKey = request.apiKey;
            if (!apiKey) {
              apiKey = await getCurrentJWTToken();
            }
            let tokenInfo = null;
            if (apiKey) {
              try {
                const parts = apiKey.split(".");
                if (parts.length === 3) {
                  const payload = JSON.parse(atob(parts[1].replace(/-/g, "+").replace(/_/g, "/")));
                  tokenInfo = {
                    isValidFormat: true,
                    payload: {
                      user_id: payload.user_id,
                      email: payload.email,
                      exp: payload.exp,
                      iat: payload.iat,
                      expiresAt: payload.exp ? new Date(payload.exp * 1e3).toISOString() : null,
                      isExpired: payload.exp ? payload.exp < Date.now() / 1e3 : null
                    }
                  };
                } else {
                  tokenInfo = { isValidFormat: false, reason: "Not a JWT (does not have 3 parts)" };
                }
              } catch (e) {
                tokenInfo = { isValidFormat: false, reason: `Decode error: ${e.message}` };
              }
            }
            console.log("[PrivacyPal] \u{1F511} Token status:", {
              hasToken: !!apiKey,
              tokenLength: apiKey?.length || 0,
              tokenPreview: apiKey ? `${apiKey.substring(0, 20)}...${apiKey.substring(apiKey.length - 10)}` : "null",
              apiUrl: request.apiUrl || DEFAULT_ENDPOINTS.apiUrl,
              source: request.apiKey ? "passed_from_interceptor" : "storage",
              passedTokenLength: request.apiKey?.length || 0,
              tokenInfo
            });
            if (request.apiKey && (!apiKey || apiKey.length === 0)) {
              console.error("[PrivacyPal] \u26A0\uFE0F WARNING: Interceptor passed token but it appears empty!");
            }
            if (apiKey && tokenInfo && !tokenInfo.isValidFormat) {
              console.error("[PrivacyPal] \u26A0\uFE0F WARNING: Token does not appear to be a valid JWT!", tokenInfo);
            }
            if (!apiKey) {
              console.error("[PrivacyPal] \u274C No JWT token found. User must sign in.");
              safeSendResponse({
                success: false,
                error: "Not authenticated. Please sign in to use PrivacyPal."
              });
              return;
            }
            const encodePromise = proxyEncodeRequest(request.data, request.apiUrl || DEFAULT_ENDPOINTS.apiUrl, apiKey, request.platform);
            const timeoutPromise = new Promise((_, reject) => {
              setTimeout(() => {
                reject(new Error("Encode request timed out after 60 seconds"));
              }, 6e4);
            });
            console.log("[PrivacyPal] \u23F3 Waiting for encode API response...");
            const result = await Promise.race([encodePromise, timeoutPromise]);
            console.log("[PrivacyPal] \u2705 Encode response ready, sending to bridge", {
              success: result.success,
              hasContinuationId: !!result.data?.continuationId
            });
            safeSendResponse(result);
          } catch (error) {
            console.error("[PrivacyPal] \u274C Encode error:", error);
            const errorMessage = error.message || String(error);
            safeSendResponse({
              success: false,
              error: errorMessage,
              timeout: errorMessage.includes("timeout")
            });
          }
        })();
        return true;
      case "decodeData":
        (async () => {
          let responseSent = false;
          const safeSendResponse = (response) => {
            if (!responseSent) {
              try {
                sendResponse(response);
                responseSent = true;
              } catch (err) {
                console.error("[PrivacyPal] Failed to send decodeData response:", err);
                responseSent = true;
              }
            }
          };
          try {
            let apiKey = request.apiKey || await getCurrentJWTToken();
            if (!apiKey) {
              safeSendResponse({
                success: false,
                error: "Not authenticated. Please sign in to use PrivacyPal."
              });
              return;
            }
            const result = await proxyDecodeRequest(request.data, request.continuationId, request.hashes, request.apiUrl || DEFAULT_ENDPOINTS.apiUrl, apiKey);
            safeSendResponse(result);
          } catch (error) {
            console.error("[PrivacyPal] decodeData error:", error);
            safeSendResponse({ success: false, error: error.message || String(error) });
          }
        })();
        return true;
      case "encodeFile":
        (async () => {
          let responseSent = false;
          const safeSendResponse = (response) => {
            if (!responseSent) {
              try {
                sendResponse(response);
                responseSent = true;
              } catch (err) {
                console.error("[PrivacyPal] Failed to send encodeFile response:", err);
                responseSent = true;
              }
            }
          };
          try {
            let apiKey = request.apiKey || await getCurrentJWTToken();
            if (!apiKey) {
              safeSendResponse({
                success: false,
                error: "Not authenticated. Please sign in to use PrivacyPal."
              });
              return;
            }
            console.log("[PrivacyPal] Processing encodeFile request...", {
              fileName: request.fileName,
              dataLength: request.fileData?.length,
              hasApiKey: !!apiKey,
              platform: request.platform
            });
            const encodePromise = proxyEncodeFileRequest(request.fileData, request.fileName, request.apiUrl || DEFAULT_ENDPOINTS.apiUrl, apiKey, request.platform);
            const timeoutPromise = new Promise((_, reject) => {
              setTimeout(() => {
                reject(new Error("File encode request timed out after 60 seconds"));
              }, 6e4);
            });
            const result = await Promise.race([encodePromise, timeoutPromise]);
            console.log("[PrivacyPal] File encode response ready", {
              success: result.success,
              hasContinuationId: !!result.data?.continuationId
            });
            safeSendResponse(result);
          } catch (error) {
            console.error("[PrivacyPal] encodeFile error:", error);
            const errorMessage = error.message || String(error);
            safeSendResponse({
              success: false,
              error: errorMessage,
              timeout: errorMessage.includes("timeout")
            });
          }
        })();
        return true;
      case "getConfig":
        chrome.storage.local.get(["apiUrl", "userPortalUrl", "enabled", "debug", "showNotifications"], (result) => {
          try {
            let apiUrl = result.apiUrl || DEFAULT_CONFIG.apiUrl;
            let userPortalUrl = result.userPortalUrl || DEFAULT_CONFIG.userPortalUrl;
            if (apiUrl.includes("localhost:42026") || apiUrl.includes("127.0.0.1:42026")) {
              apiUrl = DEFAULT_CONFIG.apiUrl;
              chrome.storage.local.set({ apiUrl });
            }
            if (userPortalUrl.includes("localhost:5174") || userPortalUrl.includes("127.0.0.1:5174")) {
              userPortalUrl = DEFAULT_CONFIG.userPortalUrl;
              chrome.storage.local.set({ userPortalUrl });
            }
            const config = {
              ...DEFAULT_CONFIG,
              ...result,
              apiUrl,
              userPortalUrl
            };
            sendResponse({ config });
          } catch (err) {
            console.error("[PrivacyPal] Failed to send getConfig response:", err);
            sendResponse({ config: DEFAULT_CONFIG });
          }
        });
        return true;
      case "getSession":
        chrome.storage.local.get(["privacypal_session"], (result) => {
          try {
            sendResponse({ privacypal_session: result.privacypal_session || null });
          } catch (err) {
            console.error("[PrivacyPal] Failed to send getSession response:", err);
          }
        });
        return true;
      case "updateConfig":
        chrome.storage.local.set(request.config, () => {
          sendResponse({ success: true });
          broadcastConfigChange(request.config);
        });
        return true;
      case "getStats":
        chrome.storage.local.get(["stats"], (result) => {
          const currentStats = result.stats || stats;
          console.log("[PrivacyPal] getStats response:", currentStats);
          sendResponse({ stats: currentStats });
        });
        return true;
      case "resetStats":
        stats = {
          requestsIntercepted: 0,
          responsesModified: 0,
          dataProtected: 0,
          lastInterception: null,
          sessionStart: Date.now(),
          continuationIds: []
        };
        chrome.storage.local.set({ stats }, () => {
          sendResponse({ success: true, stats });
        });
        return true;
      case "recordContinuationId":
        recordContinuationId(request.continuationId, request.dataProtected);
        sendResponse({ success: true });
        return true;
      case "testConnection":
        (async () => {
          try {
            const apiKey = await getCurrentJWTToken();
            if (!apiKey) {
              sendResponse({ success: false, error: "Not authenticated. Please sign in to test connection." });
              return;
            }
            const result = await testConnection(request.apiUrl || DEFAULT_ENDPOINTS.apiUrl, apiKey);
            sendResponse(result);
          } catch (error) {
            sendResponse({ success: false, error: error.message });
          }
        })();
        return true;
      default:
        sendResponse({ error: "Unknown action" });
    }
  });
  function handleInterceptorReady(data, sender) {
    console.log("[PrivacyPal] Interceptor ready on:", data.url);
    if (sender.tab?.id) {
      chrome.action.setBadgeText({
        text: "\u2713",
        tabId: sender.tab.id
      });
      chrome.action.setBadgeBackgroundColor({
        color: "#4169e1",
        tabId: sender.tab.id
      });
    }
  }
  function handleRequestIntercepted(data, sender) {
    if (data.continuationId) {
      const dataProtected = data.stats?.dataProtected || 0;
      recordContinuationId(data.continuationId, dataProtected);
    } else {
      stats.requestsIntercepted = data.stats?.requestsIntercepted || 0;
      stats.responsesModified = data.stats?.responsesModified || 0;
      stats.dataProtected = (stats.dataProtected || 0) + (data.stats?.dataProtected || 0);
      stats.lastInterception = (/* @__PURE__ */ new Date()).toISOString();
      chrome.storage.local.set({ stats });
    }
    console.log("[PrivacyPal] Request intercepted:", {
      platform: data.platform,
      continuationId: data.continuationId,
      dataProtected: data.stats?.dataProtected || 0
    });
    chrome.storage.local.get(["showNotifications"], (result) => {
      if (result.showNotifications) {
        showInterceptionNotification(data.platform, sender.tab?.id);
      }
    });
  }
  function recordContinuationId(continuationId, dataProtected = 0) {
    if (!continuationId)
      return;
    chrome.storage.local.get(["stats"], (result) => {
      const currentStats = result.stats || { ...stats };
      if (!currentStats.continuationIds) {
        currentStats.continuationIds = [];
      }
      if (!currentStats.continuationIds.includes(continuationId)) {
        currentStats.continuationIds.push(continuationId);
        currentStats.requestsIntercepted = currentStats.continuationIds.length;
        currentStats.lastInterception = (/* @__PURE__ */ new Date()).toISOString();
      }
      currentStats.dataProtected = (currentStats.dataProtected || 0) + (dataProtected || 0);
      stats = currentStats;
      chrome.storage.local.set({ stats });
      console.log("[PrivacyPal] Stats updated:", {
        continuationIds: currentStats.continuationIds.length,
        dataProtected: currentStats.dataProtected
      });
    });
  }
  function showInterceptionNotification(platform, tabId) {
    if (!tabId)
      return;
    chrome.action.setBadgeText({
      text: "\u{1F6E1}\uFE0F",
      tabId
    });
    chrome.action.setBadgeBackgroundColor({
      color: "#10a37f",
      tabId
    });
    setTimeout(() => {
      chrome.action.setBadgeText({
        text: "\u2713",
        tabId
      });
      chrome.action.setBadgeBackgroundColor({
        color: "#4169e1",
        tabId
      });
    }, 2e3);
  }
  function broadcastConfigChange(config) {
    chrome.tabs.query({}, (tabs) => {
      tabs.forEach((tab) => {
        chrome.tabs.sendMessage(tab.id, {
          action: "configUpdated",
          config
        }).catch(() => {
        });
      });
    });
  }
  async function testConnection(apiUrl, apiKey) {
    try {
      const response = await fetch(`${apiUrl}/health`, {
        method: "GET",
        headers: {
          "x-access-token": apiKey,
          "Content-Type": "application/json"
        }
      });
      if (response.ok) {
        return { success: true, message: "Connected to PrivacyPal API" };
      } else {
        return {
          success: false,
          error: `API returned status ${response.status}`
        };
      }
    } catch (error) {
      return {
        success: false,
        error: `Connection failed: ${error.message}`
      };
    }
  }
  chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === "complete" && tab.url) {
      const isChatGPT = tab.url.includes("chatgpt.com");
      const isClaude = tab.url.includes("claude.ai");
      if (isChatGPT || isClaude) {
        console.log("[PrivacyPal] Supported page detected:", tab.url);
        chrome.action.setBadgeText({
          text: "\u2713",
          tabId
        });
        chrome.action.setBadgeBackgroundColor({
          color: "#4169e1",
          tabId
        });
      }
    }
  });
  chrome.runtime.onStartup.addListener(async () => {
    console.log("[PrivacyPal] Extension started");
    const result = await chrome.storage.local.get(["stats"]);
    if (result.stats) {
      stats = result.stats;
    }
  });
  chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.create({
      id: "privacypal-toggle",
      title: "Toggle PrivacyPal Protection",
      contexts: ["page"]
    });
    chrome.contextMenus.create({
      id: "privacypal-stats",
      title: "View Protection Statistics",
      contexts: ["page"]
    });
  });
  chrome.contextMenus.onClicked.addListener((info, tab) => {
    switch (info.menuItemId) {
      case "privacypal-toggle":
        toggleProtection();
        break;
      case "privacypal-stats":
        showStatsNotification();
        break;
    }
  });
  async function toggleProtection() {
    const result = await chrome.storage.local.get(["enabled"]);
    const newState = !result.enabled;
    await chrome.storage.local.set({ enabled: newState });
    const message = newState ? "\u2705 Protection Enabled" : "\u23F8\uFE0F Protection Disabled";
    console.log("[PrivacyPal]", message);
    broadcastConfigChange({ enabled: newState });
  }
  async function showStatsNotification() {
    const result = await chrome.storage.local.get(["stats"]);
    const currentStats = result.stats || stats;
    console.log("[PrivacyPal] Statistics:", currentStats);
  }
  async function proxyEncodeRequest(data, apiUrl, apiKey, platform = null) {
    try {
      console.log("[PrivacyPal] Starting encode request", {
        dataLength: data?.length,
        apiUrl,
        hasApiKey: !!apiKey,
        apiKeyPreview: apiKey ? `${apiKey.substring(0, 20)}...` : "null",
        platform
      });
      if (!data) {
        throw new Error("No data provided for encode request");
      }
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 6e4);
      try {
        const headers = {
          "Content-Type": "application/json"
        };
        if (apiKey) {
          headers["x-access-token"] = apiKey;
          let tokenPayload = null;
          try {
            const parts = apiKey.split(".");
            if (parts.length === 3) {
              tokenPayload = JSON.parse(atob(parts[1].replace(/-/g, "+").replace(/_/g, "/")));
            }
          } catch (e) {
          }
          console.log("[PrivacyPal] \u{1F4E4} Sending request with token header", {
            tokenLength: apiKey.length,
            tokenPreview: `${apiKey.substring(0, 30)}...${apiKey.substring(apiKey.length - 20)}`,
            apiUrl,
            headerName: "x-access-token",
            tokenPayload: tokenPayload ? {
              user_id: tokenPayload.user_id,
              email: tokenPayload.email,
              exp: tokenPayload.exp,
              expiresAt: tokenPayload.exp ? new Date(tokenPayload.exp * 1e3).toISOString() : null
            } : null
          });
        } else {
          console.error("[PrivacyPal] \u274C No token - request will fail with 401");
          throw new Error("No authentication token available. Please sign in to use PrivacyPal.");
        }
        console.log("[PrivacyPal] \u{1F535} Making encode request to:", `${apiUrl}/api/scanner/encode`);
        const response = await fetch(`${apiUrl}/api/scanner/encode`, {
          method: "POST",
          headers,
          body: JSON.stringify({
            data,
            sourceContainer: "browser_extension",
            metadata: {
              source: "chat_interceptor",
              platform: platform || "browser_extension",
              timestamp: Date.now()
            }
          }),
          signal: controller.signal
        });
        clearTimeout(timeoutId);
        if (!response.ok) {
          const errorText = await response.text();
          let errorDetails;
          try {
            errorDetails = JSON.parse(errorText);
          } catch {
            errorDetails = { raw: errorText };
          }
          console.error("[PrivacyPal] Encode API error", {
            status: response.status,
            statusText: response.statusText,
            error: errorText,
            errorDetails,
            apiUrl,
            hasApiKey: !!apiKey,
            apiKeyLength: apiKey?.length,
            tokenPreview: apiKey ? `${apiKey.substring(0, 30)}...${apiKey.substring(apiKey.length - 20)}` : "null",
            requestHeaders: Object.keys(headers)
          });
          if (response.status === 401) {
            console.log("[PrivacyPal] \u{1F504} 401 error - attempting token refresh...");
            const storage = await chrome.storage.local.get(["privacypal_session"]);
            if (storage.privacypal_session?.jwtTokens?.access_token) {
              const config = await loadConfig();
              try {
                const refreshResponse = await fetch(`${config.apiUrl}/api/user/refresh-token`, {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({ token: storage.privacypal_session.jwtTokens.access_token })
                });
                if (refreshResponse.ok) {
                  const refreshData = await refreshResponse.json();
                  const newToken = refreshData.data?.token || refreshData.token;
                  if (newToken) {
                    storage.privacypal_session.jwtTokens.access_token = newToken;
                    storage.privacypal_session.jwtTokens.expires_at = Date.now() + 28800 * 1e3;
                    await chrome.storage.local.set({ privacypal_session: storage.privacypal_session });
                    console.log("[PrivacyPal] \u2705 Token refreshed, retrying encode request...");
                    const retryHeaders = {
                      "Content-Type": "application/json",
                      "x-access-token": newToken
                    };
                    const retryController = new AbortController();
                    const retryTimeoutId = setTimeout(() => retryController.abort(), 6e4);
                    const retryResponse = await fetch(`${apiUrl}/api/scanner/encode`, {
                      method: "POST",
                      headers: retryHeaders,
                      body: JSON.stringify({
                        data,
                        sourceContainer: "browser_extension",
                        metadata: {
                          source: "chat_interceptor",
                          platform: platform || "browser_extension",
                          timestamp: Date.now()
                        }
                      }),
                      signal: retryController.signal
                    });
                    clearTimeout(retryTimeoutId);
                    if (retryResponse.ok) {
                      const retryResult = await retryResponse.json();
                      console.log("[PrivacyPal] \u2705 Encode request successful after token refresh");
                      return { success: true, data: retryResult };
                    }
                  }
                }
              } catch (refreshError) {
                console.error("[PrivacyPal] Token refresh failed:", refreshError);
              }
            }
            const errorMsg = errorDetails?.message || errorDetails?.error || errorText;
            throw new Error(`Authentication failed (401). Token expired or invalid. Please sign in again. Details: ${errorMsg}`);
          }
          throw new Error(`Encode API returned ${response.status}: ${errorText}`);
        }
        const result = await response.json();
        console.log("[PrivacyPal] Encode request successful", {
          hasContinuationId: !!result.continuationId,
          transformationsCount: result.transformations?.length
        });
        return { success: true, data: result };
      } catch (fetchError) {
        clearTimeout(timeoutId);
        if (fetchError.name === "AbortError") {
          throw new Error("Encode request timed out after 25 seconds");
        }
        throw fetchError;
      }
    } catch (error) {
      console.error("[PrivacyPal] Encode proxy error:", error);
      throw error;
    }
  }
  async function proxyDecodeRequest(data, continuationId, hashes, apiUrl, apiKey) {
    try {
      if (!apiKey) {
        throw new Error("No API key provided for decode request");
      }
      const response = await fetch(`${apiUrl}/api/scanner/decode`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-access-token": apiKey
        },
        body: JSON.stringify({
          continuationId,
          data,
          sensitiveHashes: hashes,
          authorization: {
            token: apiKey,
            purpose: "Browser Extension - Decode AI Response",
            type: "jwt"
          }
        })
      });
      if (!response.ok) {
        throw new Error(`Decode API returned ${response.status}`);
      }
      const result = await response.json();
      return { success: true, data: result };
    } catch (error) {
      console.error("[PrivacyPal] Decode proxy error:", error);
      return { success: false, error: error.message };
    }
  }
  async function proxyEncodeFileRequest(fileData, fileName, apiUrl, apiKey, platform = null) {
    try {
      if (!fileData) {
        throw new Error("No file data provided for encode request");
      }
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 6e4);
      try {
        const response = await fetch(`${apiUrl}/api/scanner/encode`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            ...apiKey ? { "x-access-token": apiKey } : {}
          },
          body: JSON.stringify({
            data: fileData,
            sourceContainer: "browser_extension",
            sourceElement: "file_upload",
            metadata: {
              source: "file_upload",
              platform: platform || "browser_extension",
              fileName,
              timestamp: Date.now()
            }
          }),
          signal: controller.signal
        });
        clearTimeout(timeoutId);
        if (!response.ok) {
          const errorText = await response.text();
          console.error("[PrivacyPal] File encode API error", { status: response.status, error: errorText });
          throw new Error(`Encode API returned ${response.status}: ${errorText}`);
        }
        const result = await response.json();
        console.log("[PrivacyPal] File encode request successful", {
          hasContinuationId: !!result.continuationId,
          fileName
        });
        return { success: true, data: result };
      } catch (fetchError) {
        clearTimeout(timeoutId);
        if (fetchError.name === "AbortError") {
          throw new Error("File encode request timed out after 25 seconds");
        }
        throw fetchError;
      }
    } catch (error) {
      console.error("[PrivacyPal] File encode proxy error:", error);
      return { success: false, error: error.message || String(error) };
    }
  }
  console.log("[PrivacyPal] Background service worker initialized");
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2NvbmZpZy9jb25maWcuanMiLCAiLi4vc3JjL2JhY2tncm91bmQvc2VydmljZS13b3JrZXIuanMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbIi8qKlxyXG4gKiBQcml2YWN5UGFsIEJyb3dzZXIgRXh0ZW5zaW9uIC0gQ29uZmlndXJhdGlvblxyXG4gKiBcclxuICogVGhpcyBmaWxlIGNvbnRhaW5zIGRlZmF1bHQgY29uZmlndXJhdGlvbiB2YWx1ZXMgZm9yIHRoZSBleHRlbnNpb24uXHJcbiAqIFRoZXNlIGNhbiBiZSBvdmVycmlkZGVuIHZpYSBleHRlbnNpb24gc2V0dGluZ3MgaW4gdGhlIHBvcHVwIFVJLlxyXG4gKiBcclxuICogRm9yIHByb2R1Y3Rpb24gZGVwbG95bWVudHMsIG1vZGlmeSB0aGVzZSB2YWx1ZXMgYmVmb3JlIGJ1aWxkaW5nIHRoZSBleHRlbnNpb24uXHJcbiAqL1xyXG5cclxuLy8gUHJvZHVjdGlvbiBBUEkgVVJMIC0gY2FuIGJlIG92ZXJyaWRkZW4gdmlhIGV4dGVuc2lvbiBzZXR0aW5nc1xyXG4vLyBGb3IgbG9jYWwgZGV2ZWxvcG1lbnQsIHVzZXJzIGNhbiBjaGFuZ2UgdGhpcyBpbiB0aGUgZXh0ZW5zaW9uIHNldHRpbmdzIFVJXHJcbmV4cG9ydCBjb25zdCBERUZBVUxUX0VORFBPSU5UUyA9IHtcclxuICAvLyBBUEkgZW5kcG9pbnQgZm9yIFByaXZhY3lQYWwgQ2xvdWQgc2VydmljZXNcclxuICAvLyBQcm9kdWN0aW9uOiBodHRwczovL2FwaS5wcml2YWN5cGFsLmFpXHJcbiAgLy8gRGV2ZWxvcG1lbnQ6IGh0dHA6Ly9sb2NhbGhvc3Q6NDIwMjYgKGNhbiBiZSBjaGFuZ2VkIGluIHNldHRpbmdzKVxyXG4gIGFwaVVybDogJ2h0dHBzOi8vYXBpLnByaXZhY3lwYWwuYWknLFxyXG4gIFxyXG4gIC8vIFVzZXIgUG9ydGFsIGVuZHBvaW50IGZvciBhY2NvdW50IG1hbmFnZW1lbnQgYW5kIHN1YnNjcmlwdGlvbnNcclxuICAvLyBQcm9kdWN0aW9uOiBodHRwczovL3BvcnRhbC5wcml2YWN5cGFsLmFpXHJcbiAgLy8gRGV2ZWxvcG1lbnQ6IGh0dHA6Ly9sb2NhbGhvc3Q6NTE3NCAoY2FuIGJlIGNoYW5nZWQgaW4gc2V0dGluZ3MpXHJcbiAgdXNlclBvcnRhbFVybDogJ2h0dHBzOi8vcG9ydGFsLnByaXZhY3lwYWwuYWknXHJcbn07XHJcblxyXG4vKipcclxuICogTG9hZCBjb25maWd1cmF0aW9uIGZyb20gc3RvcmFnZSBvciB1c2UgZGVmYXVsdHNcclxuICogVGhpcyBhbGxvd3MgcnVudGltZSBjb25maWd1cmF0aW9uIHZpYSBleHRlbnNpb24gc2V0dGluZ3NcclxuICovXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBsb2FkQ29uZmlnKCkge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBzdG9yZWQgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoWydhcGlVcmwnLCAndXNlclBvcnRhbFVybCddKTtcclxuICAgIHJldHVybiB7XHJcbiAgICAgIGFwaVVybDogc3RvcmVkLmFwaVVybCB8fCBERUZBVUxUX0VORFBPSU5UUy5hcGlVcmwsXHJcbiAgICAgIHVzZXJQb3J0YWxVcmw6IHN0b3JlZC51c2VyUG9ydGFsVXJsIHx8IERFRkFVTFRfRU5EUE9JTlRTLnVzZXJQb3J0YWxVcmxcclxuICAgIH07XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUud2FybignW1ByaXZhY3lQYWxdIEZhaWxlZCB0byBsb2FkIGNvbmZpZyBmcm9tIHN0b3JhZ2UsIHVzaW5nIGRlZmF1bHRzOicsIGVycm9yKTtcclxuICAgIHJldHVybiBERUZBVUxUX0VORFBPSU5UUztcclxuICB9XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBTYXZlIGNvbmZpZ3VyYXRpb24gdG8gc3RvcmFnZVxyXG4gKi9cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNhdmVDb25maWcoY29uZmlnKSB7XHJcbiAgdHJ5IHtcclxuICAgIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7XHJcbiAgICAgIGFwaVVybDogY29uZmlnLmFwaVVybCxcclxuICAgICAgdXNlclBvcnRhbFVybDogY29uZmlnLnVzZXJQb3J0YWxVcmxcclxuICAgIH0pO1xyXG4gICAgcmV0dXJuIHRydWU7XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoJ1tQcml2YWN5UGFsXSBGYWlsZWQgdG8gc2F2ZSBjb25maWc6JywgZXJyb3IpO1xyXG4gICAgcmV0dXJuIGZhbHNlO1xyXG4gIH1cclxufVxyXG5cclxuIiwgIi8qKlxyXG4gKiBQcml2YWN5UGFsIEJyb3dzZXIgRXh0ZW5zaW9uIC0gQmFja2dyb3VuZCBTZXJ2aWNlIFdvcmtlclxyXG4gKiBNYW5hZ2VzIGV4dGVuc2lvbiBzdGF0ZSwgY29uZmlndXJhdGlvbiwgYW5kIG1lc3NhZ2UgcGFzc2luZ1xyXG4gKi9cclxuXHJcbmltcG9ydCB7IERFRkFVTFRfRU5EUE9JTlRTLCBsb2FkQ29uZmlnIH0gZnJvbSAnLi4vY29uZmlnL2NvbmZpZy5qcyc7XHJcblxyXG4vLyBEZWZhdWx0IGNvbmZpZ3VyYXRpb25cclxuY29uc3QgREVGQVVMVF9DT05GSUcgPSB7XHJcbiAgZW5hYmxlZDogdHJ1ZSxcclxuICBhcGlVcmw6IERFRkFVTFRfRU5EUE9JTlRTLmFwaVVybCxcclxuICB1c2VyUG9ydGFsVXJsOiBERUZBVUxUX0VORFBPSU5UUy51c2VyUG9ydGFsVXJsLFxyXG4gIC8vIGFwaUtleSBpcyBubyBsb25nZXIgc3RvcmVkIGhlcmUgLSBpdCBjb21lcyBmcm9tIGF1dGhlbnRpY2F0ZWQgdXNlcidzIEpXVCB0b2tlblxyXG4gIGRlYnVnOiB0cnVlLFxyXG4gIHNob3dOb3RpZmljYXRpb25zOiB0cnVlXHJcbn07XHJcblxyXG4vLyBTdGF0aXN0aWNzIHRyYWNraW5nXHJcbmxldCBzdGF0cyA9IHtcclxuICByZXF1ZXN0c0ludGVyY2VwdGVkOiAwLFxyXG4gIHJlc3BvbnNlc01vZGlmaWVkOiAwLFxyXG4gIGRhdGFQcm90ZWN0ZWQ6IDAsXHJcbiAgbGFzdEludGVyY2VwdGlvbjogbnVsbCxcclxuICBzZXNzaW9uU3RhcnQ6IERhdGUubm93KCksXHJcbiAgY29udGludWF0aW9uSWRzOiBbXSAvLyBUcmFjayBhbGwgY29udGludWF0aW9uSWRzIGZvciBhY2N1cmF0ZSBzdGF0c1xyXG59O1xyXG5cclxuLyoqXHJcbiAqIEdldCB0aGUgY3VycmVudCBKV1QgdG9rZW4gZnJvbSBhdXRoZW50aWNhdGVkIHVzZXIgc2Vzc2lvblxyXG4gKiBOTyBWQUxJREFUSU9OIC0ganVzdCBmZXRjaCBhbmQgcmV0dXJuIHRoZSB0b2tlbiwgbGV0IHRoZSBBUEkgaGFuZGxlIHZhbGlkYXRpb25cclxuICovXHJcbmFzeW5jIGZ1bmN0aW9uIGdldEN1cnJlbnRKV1RUb2tlbigpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KFsncHJpdmFjeXBhbF9zZXNzaW9uJ10pO1xyXG4gICAgY29uc3Qgc2Vzc2lvbiA9IHJlc3VsdC5wcml2YWN5cGFsX3Nlc3Npb247XHJcbiAgICBcclxuICAgIGNvbnNvbGUubG9nKCdbUHJpdmFjeVBhbF0gXHVEODNEXHVERDBEIENoZWNraW5nIHNlc3Npb246Jywge1xyXG4gICAgICBoYXNTZXNzaW9uOiAhIXNlc3Npb24sXHJcbiAgICAgIGhhc0p3dFRva2VuczogISFzZXNzaW9uPy5qd3RUb2tlbnMsXHJcbiAgICAgIGhhc0FjY2Vzc1Rva2VuOiAhIXNlc3Npb24/Lmp3dFRva2Vucz8uYWNjZXNzX3Rva2VuLFxyXG4gICAgICB0b2tlbkxlbmd0aDogc2Vzc2lvbj8uand0VG9rZW5zPy5hY2Nlc3NfdG9rZW4/Lmxlbmd0aCB8fCAwXHJcbiAgICB9KTtcclxuICAgIFxyXG4gICAgaWYgKHNlc3Npb24/Lmp3dFRva2Vucz8uYWNjZXNzX3Rva2VuKSB7XHJcbiAgICAgIGNvbnN0IHRva2VuID0gc2Vzc2lvbi5qd3RUb2tlbnMuYWNjZXNzX3Rva2VuO1xyXG4gICAgICBjb25zb2xlLmxvZygnW1ByaXZhY3lQYWxdIFx1MjcwNSBUb2tlbiByZXRyaWV2ZWQ6Jywge1xyXG4gICAgICAgIGxlbmd0aDogdG9rZW4ubGVuZ3RoLFxyXG4gICAgICAgIHByZXZpZXc6IGAke3Rva2VuLnN1YnN0cmluZygwLCAyMCl9Li4uJHt0b2tlbi5zdWJzdHJpbmcodG9rZW4ubGVuZ3RoIC0gMTApfWBcclxuICAgICAgfSk7XHJcbiAgICAgIHJldHVybiB0b2tlbjtcclxuICAgIH1cclxuICAgIFxyXG4gICAgY29uc29sZS53YXJuKCdbUHJpdmFjeVBhbF0gXHUyNkEwXHVGRTBGIE5vIGFjY2VzcyB0b2tlbiBpbiBzZXNzaW9uJyk7XHJcbiAgICByZXR1cm4gbnVsbDtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcignW1ByaXZhY3lQYWxdIFx1Mjc0QyBGYWlsZWQgdG8gZ2V0IEpXVCB0b2tlbjonLCBlcnJvcik7XHJcbiAgICByZXR1cm4gbnVsbDtcclxuICB9XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBJbml0aWFsaXplIGV4dGVuc2lvbiBvbiBpbnN0YWxsXHJcbiAqL1xyXG5jaHJvbWUucnVudGltZS5vbkluc3RhbGxlZC5hZGRMaXN0ZW5lcihhc3luYyAoZGV0YWlscykgPT4ge1xyXG4gIGNvbnNvbGUubG9nKCdbUHJpdmFjeVBhbF0gRXh0ZW5zaW9uIGluc3RhbGxlZDonLCBkZXRhaWxzLnJlYXNvbik7XHJcbiAgXHJcbiAgLy8gTG9hZCBjb25maWcgdG8gZ2V0IGN1cnJlbnQgZW5kcG9pbnRzIChtYXkgaGF2ZSBiZWVuIHNldCB2aWEgc2V0dGluZ3MpXHJcbiAgY29uc3QgY29uZmlnID0gYXdhaXQgbG9hZENvbmZpZygpO1xyXG4gIFxyXG4gIC8vIE1lcmdlIGNvbmZpZyBlbmRwb2ludHMgd2l0aCBkZWZhdWx0IGNvbmZpZ1xyXG4gIGNvbnN0IGluaXRpYWxDb25maWcgPSB7XHJcbiAgICAuLi5ERUZBVUxUX0NPTkZJRyxcclxuICAgIGFwaVVybDogY29uZmlnLmFwaVVybCxcclxuICAgIHVzZXJQb3J0YWxVcmw6IGNvbmZpZy51c2VyUG9ydGFsVXJsXHJcbiAgfTtcclxuICBcclxuICAvLyBTZXQgZGVmYXVsdCBjb25maWd1cmF0aW9uIChvbmx5IGlmIG5vdCBhbHJlYWR5IHNldClcclxuICBjb25zdCBleGlzdGluZyA9IGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChbJ2FwaVVybCcsICd1c2VyUG9ydGFsVXJsJywgJ2VuYWJsZWQnLCAnZGVidWcnLCAnc2hvd05vdGlmaWNhdGlvbnMnXSk7XHJcbiAgY29uc3QgY29uZmlnVG9TYXZlID0ge1xyXG4gICAgLi4uREVGQVVMVF9DT05GSUcsXHJcbiAgICBhcGlVcmw6IGV4aXN0aW5nLmFwaVVybCB8fCBjb25maWcuYXBpVXJsLFxyXG4gICAgdXNlclBvcnRhbFVybDogZXhpc3RpbmcudXNlclBvcnRhbFVybCB8fCBjb25maWcudXNlclBvcnRhbFVybCxcclxuICAgIGVuYWJsZWQ6IGV4aXN0aW5nLmVuYWJsZWQgIT09IHVuZGVmaW5lZCA/IGV4aXN0aW5nLmVuYWJsZWQgOiBERUZBVUxUX0NPTkZJRy5lbmFibGVkLFxyXG4gICAgZGVidWc6IGV4aXN0aW5nLmRlYnVnICE9PSB1bmRlZmluZWQgPyBleGlzdGluZy5kZWJ1ZyA6IERFRkFVTFRfQ09ORklHLmRlYnVnLFxyXG4gICAgc2hvd05vdGlmaWNhdGlvbnM6IGV4aXN0aW5nLnNob3dOb3RpZmljYXRpb25zICE9PSB1bmRlZmluZWQgPyBleGlzdGluZy5zaG93Tm90aWZpY2F0aW9ucyA6IERFRkFVTFRfQ09ORklHLnNob3dOb3RpZmljYXRpb25zXHJcbiAgfTtcclxuICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoY29uZmlnVG9TYXZlKTtcclxuICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoeyBzdGF0cyB9KTtcclxuICBcclxuICBjb25zb2xlLmxvZygnW1ByaXZhY3lQYWxdIENvbmZpZ3VyYXRpb24gaW5pdGlhbGl6ZWQnKTtcclxuXHJcbiAgLy8gU2hvdyB3ZWxjb21lIHBhZ2Ugb24gZmlyc3QgaW5zdGFsbCAtIHJlZGlyZWN0IHRvIFVzZXIgUG9ydGFsXHJcbiAgaWYgKGRldGFpbHMucmVhc29uID09PSAnaW5zdGFsbCcpIHtcclxuICAgIGNvbnN0IGZpbmFsQ29uZmlnID0gYXdhaXQgbG9hZENvbmZpZygpO1xyXG4gICAgY2hyb21lLnRhYnMuY3JlYXRlKHtcclxuICAgICAgdXJsOiBmaW5hbENvbmZpZy51c2VyUG9ydGFsVXJsXHJcbiAgICB9KTtcclxuICB9XHJcbn0pO1xyXG5cclxuLyoqXHJcbiAqIEtlZXAgc2VydmljZSB3b3JrZXIgYWxpdmUgYnkgbGlzdGVuaW5nIGZvciBtZXNzYWdlc1xyXG4gKiBUaGlzIHByZXZlbnRzIHRoZSBzZXJ2aWNlIHdvcmtlciBmcm9tIGJlaW5nIHRlcm1pbmF0ZWRcclxuICovXHJcbmNocm9tZS5ydW50aW1lLm9uQ29ubmVjdC5hZGRMaXN0ZW5lcigocG9ydCkgPT4ge1xyXG4gIGNvbnNvbGUubG9nKCdbUHJpdmFjeVBhbF0gU2VydmljZSB3b3JrZXIgY29ubmVjdGVkJyk7XHJcbiAgcG9ydC5vbkRpc2Nvbm5lY3QuYWRkTGlzdGVuZXIoKCkgPT4ge1xyXG4gICAgY29uc29sZS5sb2coJ1tQcml2YWN5UGFsXSBTZXJ2aWNlIHdvcmtlciBkaXNjb25uZWN0ZWQnKTtcclxuICB9KTtcclxufSk7XHJcblxyXG4vKipcclxuICogS2VlcCBzZXJ2aWNlIHdvcmtlciBhbGl2ZSB3aXRoIHBlcmlvZGljIHBpbmdzIHVzaW5nIGNocm9tZS5hbGFybXNcclxuICogU2VydmljZSB3b3JrZXJzIGFyZSBldmVudC1kcml2ZW4gYW5kIHdpbGwgd2FrZSB1cCB3aGVuIG1lc3NhZ2VzIGFycml2ZVxyXG4gKiBUaGlzIGtlZXAtYWxpdmUgaXMgb3B0aW9uYWwgLSBtZXNzYWdlcyB3aWxsIHdha2UgdGhlIHNlcnZpY2Ugd29ya2VyXHJcbiAqL1xyXG50cnkge1xyXG4gIGlmIChjaHJvbWUgJiYgY2hyb21lLmFsYXJtcykge1xyXG4gICAgLy8gQ3JlYXRlIGEgcGVyc2lzdGVudCBhbGFybSBmb3Iga2VlcC1hbGl2ZSAoaWYgYWxhcm1zIHBlcm1pc3Npb24gaXMgZ3JhbnRlZClcclxuICAgIGNocm9tZS5hbGFybXMuY3JlYXRlKCdwcml2YWN5cGFsLWtlZXBhbGl2ZScsIHtcclxuICAgICAgZGVsYXlJbk1pbnV0ZXM6IDAuMjUsIC8vIDE1IHNlY29uZHNcclxuICAgICAgcGVyaW9kSW5NaW51dGVzOiAwLjI1IC8vIFJlcGVhdCBldmVyeSAxNSBzZWNvbmRzXHJcbiAgICB9KS5jYXRjaCgoZXJyKSA9PiB7XHJcbiAgICAgIGNvbnNvbGUud2FybignW1ByaXZhY3lQYWxdIENvdWxkIG5vdCBjcmVhdGUga2VlcC1hbGl2ZSBhbGFybTonLCBlcnIpO1xyXG4gICAgfSk7XHJcblxyXG4gICAgLy8gTGlzdGVuIGZvciB0aGUga2VlcC1hbGl2ZSBhbGFybVxyXG4gICAgY2hyb21lLmFsYXJtcy5vbkFsYXJtLmFkZExpc3RlbmVyKChhbGFybSkgPT4ge1xyXG4gICAgICBpZiAoYWxhcm0gJiYgYWxhcm0ubmFtZSA9PT0gJ3ByaXZhY3lwYWwta2VlcGFsaXZlJykge1xyXG4gICAgICAgIC8vIFBlcmZvcm0gYSBsaWdodHdlaWdodCBzdG9yYWdlIG9wZXJhdGlvbiB0byBrZWVwIHNlcnZpY2Ugd29ya2VyIGFjdGl2ZVxyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoWydrZWVwQWxpdmUnXSwgKCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoY2hyb21lLnJ1bnRpbWUubGFzdEVycm9yKSB7XHJcbiAgICAgICAgICAgICAgY29uc29sZS5sb2coJ1tQcml2YWN5UGFsXSBLZWVwLWFsaXZlIHBpbmc6JywgY2hyb21lLnJ1bnRpbWUubGFzdEVycm9yLm1lc3NhZ2UpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgIC8vIElnbm9yZSBzdG9yYWdlIGVycm9yc1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgfVxyXG59IGNhdGNoIChlcnJvcikge1xyXG4gIC8vIFNpbGVudGx5IGZhaWwgLSBzZXJ2aWNlIHdvcmtlciB3aWxsIHN0aWxsIHdvcmtcclxuICBjb25zb2xlLndhcm4oJ1tQcml2YWN5UGFsXSBLZWVwLWFsaXZlIHNldHVwIGZhaWxlZCAobm9uLWNyaXRpY2FsKTonLCBlcnJvci5tZXNzYWdlKTtcclxufVxyXG5cclxuLyoqXHJcbiAqIExpc3RlbiBmb3IgbWVzc2FnZXMgZnJvbSBjb250ZW50IHNjcmlwdHMgYW5kIHBvcHVwXHJcbiAqL1xyXG5jaHJvbWUucnVudGltZS5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIoKHJlcXVlc3QsIHNlbmRlciwgc2VuZFJlc3BvbnNlKSA9PiB7XHJcbiAgY29uc29sZS5sb2coJ1tQcml2YWN5UGFsXSBNZXNzYWdlIHJlY2VpdmVkOicsIHJlcXVlc3QuYWN0aW9uIHx8IHJlcXVlc3QudHlwZSwge1xyXG4gICAgZnJvbTogc2VuZGVyPy50YWI/LnVybCB8fCBzZW5kZXI/LnVybCB8fCAndW5rbm93bicsXHJcbiAgICBoYXNEYXRhOiAhIXJlcXVlc3QuZGF0YSxcclxuICAgIGhhc0FwaUtleTogISFyZXF1ZXN0LmFwaUtleVxyXG4gIH0pO1xyXG4gIFxyXG4gIC8vIEtlZXAgc2VydmljZSB3b3JrZXIgYWxpdmUgYnkgcGVyZm9ybWluZyBhIHN0b3JhZ2Ugb3BlcmF0aW9uXHJcbiAgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KFsna2VlcEFsaXZlJ10sICgpID0+IHtcclxuICAgIC8vIFRoaXMgaGVscHMga2VlcCB0aGUgc2VydmljZSB3b3JrZXIgYWN0aXZlXHJcbiAgfSk7XHJcblxyXG4gICAgLy8gSGFuZGxlIE9BdXRoIGNvbXBsZXRpb24gbWVzc2FnZXNcclxuICAgIGlmIChyZXF1ZXN0LnR5cGUgPT09ICdPQVVUSF9DT01QTEVURScpIHtcclxuICAgICAgY29uc29sZS5sb2coJ1tQcml2YWN5UGFsXSBPQXV0aCBjb21wbGV0aW9uIHJlY2VpdmVkOicsIHsgc3RhdGU6IHJlcXVlc3Quc3RhdGUsIHN1Y2Nlc3M6IHJlcXVlc3Quc3VjY2VzcyB9KTtcclxuICAgICAgc2VuZFJlc3BvbnNlKHsgc3VjY2VzczogdHJ1ZSwgcmVjZWl2ZWQ6IHRydWUgfSk7XHJcbiAgICAgIHJldHVybiB0cnVlOyAvLyBBc3luYyByZXNwb25zZVxyXG4gICAgfVxyXG5cclxuICAgIHN3aXRjaCAocmVxdWVzdC5hY3Rpb24pIHtcclxuICAgICAgY2FzZSAncGluZyc6XHJcbiAgICAgICAgLy8gS2VlcCBzZXJ2aWNlIHdvcmtlciBhbGl2ZVxyXG4gICAgICAgIHNlbmRSZXNwb25zZSh7IHN1Y2Nlc3M6IHRydWUsIHBvbmc6IHRydWUgfSk7XHJcbiAgICAgICAgcmV0dXJuIGZhbHNlOyAvLyBTeW5jaHJvbm91cyByZXNwb25zZVxyXG4gICAgICBcclxuICAgICAgY2FzZSAnaW50ZXJjZXB0b3JSZWFkeSc6XHJcbiAgICAgICAgaGFuZGxlSW50ZXJjZXB0b3JSZWFkeShyZXF1ZXN0LCBzZW5kZXIpO1xyXG4gICAgICAgIHNlbmRSZXNwb25zZSh7IHN1Y2Nlc3M6IHRydWUgfSk7XHJcbiAgICAgICAgYnJlYWs7XHJcblxyXG4gICAgICBjYXNlICdyZXF1ZXN0SW50ZXJjZXB0ZWQnOlxyXG4gICAgICAgIGhhbmRsZVJlcXVlc3RJbnRlcmNlcHRlZChyZXF1ZXN0LCBzZW5kZXIpO1xyXG4gICAgICAgIHNlbmRSZXNwb25zZSh7IHN1Y2Nlc3M6IHRydWUgfSk7XHJcbiAgICAgICAgYnJlYWs7XHJcblxyXG4gICAgICBjYXNlICdlbmNvZGVEYXRhJzpcclxuICAgICAgICAvLyBQcm94eSBTREsgZW5jb2RlIGNhbGwgdG8gYnlwYXNzIENTUFxyXG4gICAgICAgIC8vIFVzZSBhIGhlbHBlciB0byBlbnN1cmUgc2VuZFJlc3BvbnNlIGlzIGFsd2F5cyBjYWxsZWRcclxuICAgICAgICAoYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgICAgbGV0IHJlc3BvbnNlU2VudCA9IGZhbHNlO1xyXG4gICAgICAgICAgY29uc3Qgc2FmZVNlbmRSZXNwb25zZSA9IChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoIXJlc3BvbnNlU2VudCkge1xyXG4gICAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICBzZW5kUmVzcG9uc2UocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICAgICAgcmVzcG9uc2VTZW50ID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdbUHJpdmFjeVBhbF0gXHUyNzA1IEVuY29kZURhdGEgcmVzcG9uc2Ugc2VudCBzdWNjZXNzZnVsbHknKTtcclxuICAgICAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ1tQcml2YWN5UGFsXSBcdTI3NEMgRmFpbGVkIHRvIHNlbmQgcmVzcG9uc2UgKGNoYW5uZWwgY2xvc2VkKTonLCBlcnIpO1xyXG4gICAgICAgICAgICAgICAgcmVzcG9uc2VTZW50ID0gdHJ1ZTsgLy8gTWFyayBhcyBzZW50IHRvIHByZXZlbnQgcmV0cnlcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgLy8gVXNlIHBhc3NlZCBhcGlLZXkgaWYgcHJvdmlkZWQgKGZyb20gaW50ZXJjZXB0b3IpLCBvdGhlcndpc2UgZ2V0IGZyb20gc3RvcmFnZVxyXG4gICAgICAgICAgICBsZXQgYXBpS2V5ID0gcmVxdWVzdC5hcGlLZXk7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICBpZiAoIWFwaUtleSkge1xyXG4gICAgICAgICAgICAgIC8vIEZhbGxiYWNrIHRvIGdldHRpbmcgdG9rZW4gZnJvbSBzdG9yYWdlXHJcbiAgICAgICAgICAgICAgYXBpS2V5ID0gYXdhaXQgZ2V0Q3VycmVudEpXVFRva2VuKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIC8vIERlY29kZSBKV1QgdG9rZW4gdG8gdmVyaWZ5IGZvcm1hdCAod2l0aG91dCB2ZXJpZnlpbmcgc2lnbmF0dXJlKVxyXG4gICAgICAgICAgICBsZXQgdG9rZW5JbmZvID0gbnVsbDtcclxuICAgICAgICAgICAgaWYgKGFwaUtleSkge1xyXG4gICAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICBjb25zdCBwYXJ0cyA9IGFwaUtleS5zcGxpdCgnLicpO1xyXG4gICAgICAgICAgICAgICAgaWYgKHBhcnRzLmxlbmd0aCA9PT0gMykge1xyXG4gICAgICAgICAgICAgICAgICAvLyBEZWNvZGUgcGF5bG9hZCAoc2Vjb25kIHBhcnQpXHJcbiAgICAgICAgICAgICAgICAgIGNvbnN0IHBheWxvYWQgPSBKU09OLnBhcnNlKGF0b2IocGFydHNbMV0ucmVwbGFjZSgvLS9nLCAnKycpLnJlcGxhY2UoL18vZywgJy8nKSkpO1xyXG4gICAgICAgICAgICAgICAgICB0b2tlbkluZm8gPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgaXNWYWxpZEZvcm1hdDogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICBwYXlsb2FkOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICB1c2VyX2lkOiBwYXlsb2FkLnVzZXJfaWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICBlbWFpbDogcGF5bG9hZC5lbWFpbCxcclxuICAgICAgICAgICAgICAgICAgICAgIGV4cDogcGF5bG9hZC5leHAsXHJcbiAgICAgICAgICAgICAgICAgICAgICBpYXQ6IHBheWxvYWQuaWF0LFxyXG4gICAgICAgICAgICAgICAgICAgICAgZXhwaXJlc0F0OiBwYXlsb2FkLmV4cCA/IG5ldyBEYXRlKHBheWxvYWQuZXhwICogMTAwMCkudG9JU09TdHJpbmcoKSA6IG51bGwsXHJcbiAgICAgICAgICAgICAgICAgICAgICBpc0V4cGlyZWQ6IHBheWxvYWQuZXhwID8gcGF5bG9hZC5leHAgPCAoRGF0ZS5ub3coKSAvIDEwMDApIDogbnVsbFxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgIHRva2VuSW5mbyA9IHsgaXNWYWxpZEZvcm1hdDogZmFsc2UsIHJlYXNvbjogJ05vdCBhIEpXVCAoZG9lcyBub3QgaGF2ZSAzIHBhcnRzKScgfTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgICB0b2tlbkluZm8gPSB7IGlzVmFsaWRGb3JtYXQ6IGZhbHNlLCByZWFzb246IGBEZWNvZGUgZXJyb3I6ICR7ZS5tZXNzYWdlfWAgfTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIC8vIExvZyB0b2tlbiBzdGF0dXMgZm9yIGRlYnVnZ2luZ1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZygnW1ByaXZhY3lQYWxdIFx1RDgzRFx1REQxMSBUb2tlbiBzdGF0dXM6Jywge1xyXG4gICAgICAgICAgICAgIGhhc1Rva2VuOiAhIWFwaUtleSxcclxuICAgICAgICAgICAgICB0b2tlbkxlbmd0aDogYXBpS2V5Py5sZW5ndGggfHwgMCxcclxuICAgICAgICAgICAgICB0b2tlblByZXZpZXc6IGFwaUtleSA/IGAke2FwaUtleS5zdWJzdHJpbmcoMCwgMjApfS4uLiR7YXBpS2V5LnN1YnN0cmluZyhhcGlLZXkubGVuZ3RoIC0gMTApfWAgOiAnbnVsbCcsXHJcbiAgICAgICAgICAgICAgYXBpVXJsOiByZXF1ZXN0LmFwaVVybCB8fCBERUZBVUxUX0VORFBPSU5UUy5hcGlVcmwsXHJcbiAgICAgICAgICAgICAgc291cmNlOiByZXF1ZXN0LmFwaUtleSA/ICdwYXNzZWRfZnJvbV9pbnRlcmNlcHRvcicgOiAnc3RvcmFnZScsXHJcbiAgICAgICAgICAgICAgcGFzc2VkVG9rZW5MZW5ndGg6IHJlcXVlc3QuYXBpS2V5Py5sZW5ndGggfHwgMCxcclxuICAgICAgICAgICAgICB0b2tlbkluZm9cclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAvLyBJZiB3ZSBnb3QgYSB0b2tlbiBmcm9tIGludGVyY2VwdG9yLCB2ZXJpZnkgaXQncyBub3QgZW1wdHkvdW5kZWZpbmVkXHJcbiAgICAgICAgICAgIGlmIChyZXF1ZXN0LmFwaUtleSAmJiAoIWFwaUtleSB8fCBhcGlLZXkubGVuZ3RoID09PSAwKSkge1xyXG4gICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ1tQcml2YWN5UGFsXSBcdTI2QTBcdUZFMEYgV0FSTklORzogSW50ZXJjZXB0b3IgcGFzc2VkIHRva2VuIGJ1dCBpdCBhcHBlYXJzIGVtcHR5IScpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAvLyBXYXJuIGlmIHRva2VuIGZvcm1hdCBpcyBpbnZhbGlkXHJcbiAgICAgICAgICAgIGlmIChhcGlLZXkgJiYgdG9rZW5JbmZvICYmICF0b2tlbkluZm8uaXNWYWxpZEZvcm1hdCkge1xyXG4gICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ1tQcml2YWN5UGFsXSBcdTI2QTBcdUZFMEYgV0FSTklORzogVG9rZW4gZG9lcyBub3QgYXBwZWFyIHRvIGJlIGEgdmFsaWQgSldUIScsIHRva2VuSW5mbyk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIGlmICghYXBpS2V5KSB7XHJcbiAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignW1ByaXZhY3lQYWxdIFx1Mjc0QyBObyBKV1QgdG9rZW4gZm91bmQuIFVzZXIgbXVzdCBzaWduIGluLicpO1xyXG4gICAgICAgICAgICAgIHNhZmVTZW5kUmVzcG9uc2UoeyBcclxuICAgICAgICAgICAgICAgIHN1Y2Nlc3M6IGZhbHNlLCBcclxuICAgICAgICAgICAgICAgIGVycm9yOiAnTm90IGF1dGhlbnRpY2F0ZWQuIFBsZWFzZSBzaWduIGluIHRvIHVzZSBQcml2YWN5UGFsLicgXHJcbiAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAvLyBBZGQgdGltZW91dCB3cmFwcGVyIHRvIHByZXZlbnQgaGFuZ2luZ1xyXG4gICAgICAgICAgICBjb25zdCBlbmNvZGVQcm9taXNlID0gcHJveHlFbmNvZGVSZXF1ZXN0KHJlcXVlc3QuZGF0YSwgcmVxdWVzdC5hcGlVcmwgfHwgREVGQVVMVF9FTkRQT0lOVFMuYXBpVXJsLCBhcGlLZXksIHJlcXVlc3QucGxhdGZvcm0pO1xyXG4gICAgICAgICAgICBjb25zdCB0aW1lb3V0UHJvbWlzZSA9IG5ldyBQcm9taXNlKChfLCByZWplY3QpID0+IHtcclxuICAgICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAgICAgICAgIHJlamVjdChuZXcgRXJyb3IoJ0VuY29kZSByZXF1ZXN0IHRpbWVkIG91dCBhZnRlciA2MCBzZWNvbmRzJykpO1xyXG4gICAgICAgICAgICAgIH0sIDYwMDAwKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICBjb25zb2xlLmxvZygnW1ByaXZhY3lQYWxdIFx1MjNGMyBXYWl0aW5nIGZvciBlbmNvZGUgQVBJIHJlc3BvbnNlLi4uJyk7XHJcbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IFByb21pc2UucmFjZShbZW5jb2RlUHJvbWlzZSwgdGltZW91dFByb21pc2VdKTtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdbUHJpdmFjeVBhbF0gXHUyNzA1IEVuY29kZSByZXNwb25zZSByZWFkeSwgc2VuZGluZyB0byBicmlkZ2UnLCB7XHJcbiAgICAgICAgICAgICAgc3VjY2VzczogcmVzdWx0LnN1Y2Nlc3MsXHJcbiAgICAgICAgICAgICAgaGFzQ29udGludWF0aW9uSWQ6ICEhcmVzdWx0LmRhdGE/LmNvbnRpbnVhdGlvbklkXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICBzYWZlU2VuZFJlc3BvbnNlKHJlc3VsdCk7XHJcbiAgICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKCdbUHJpdmFjeVBhbF0gXHUyNzRDIEVuY29kZSBlcnJvcjonLCBlcnJvcik7XHJcbiAgICAgICAgICAgIGNvbnN0IGVycm9yTWVzc2FnZSA9IGVycm9yLm1lc3NhZ2UgfHwgU3RyaW5nKGVycm9yKTtcclxuICAgICAgICAgICAgc2FmZVNlbmRSZXNwb25zZSh7IFxyXG4gICAgICAgICAgICAgIHN1Y2Nlc3M6IGZhbHNlLCBcclxuICAgICAgICAgICAgICBlcnJvcjogZXJyb3JNZXNzYWdlLFxyXG4gICAgICAgICAgICAgIHRpbWVvdXQ6IGVycm9yTWVzc2FnZS5pbmNsdWRlcygndGltZW91dCcpXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pKCk7XHJcbiAgICAgICAgcmV0dXJuIHRydWU7IC8vIENSSVRJQ0FMOiBLZWVwIG1lc3NhZ2UgY2hhbm5lbCBvcGVuIGZvciBhc3luYyByZXNwb25zZVxyXG5cclxuICAgICAgY2FzZSAnZGVjb2RlRGF0YSc6XHJcbiAgICAgICAgLy8gUHJveHkgU0RLIGRlY29kZSBjYWxsIHRvIGJ5cGFzcyBDU1BcclxuICAgICAgICAoYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgICAgbGV0IHJlc3BvbnNlU2VudCA9IGZhbHNlO1xyXG4gICAgICAgICAgY29uc3Qgc2FmZVNlbmRSZXNwb25zZSA9IChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoIXJlc3BvbnNlU2VudCkge1xyXG4gICAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICBzZW5kUmVzcG9uc2UocmVzcG9uc2UpO1xyXG4gICAgICAgICAgICAgICAgcmVzcG9uc2VTZW50ID0gdHJ1ZTtcclxuICAgICAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ1tQcml2YWN5UGFsXSBGYWlsZWQgdG8gc2VuZCBkZWNvZGVEYXRhIHJlc3BvbnNlOicsIGVycik7XHJcbiAgICAgICAgICAgICAgICByZXNwb25zZVNlbnQgPSB0cnVlO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfTtcclxuXHJcbiAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAvLyBVc2UgcGFzc2VkIGFwaUtleSBpZiBwcm92aWRlZCwgb3RoZXJ3aXNlIGdldCBmcm9tIHN0b3JhZ2VcclxuICAgICAgICAgICAgbGV0IGFwaUtleSA9IHJlcXVlc3QuYXBpS2V5IHx8IGF3YWl0IGdldEN1cnJlbnRKV1RUb2tlbigpO1xyXG4gICAgICAgICAgICBpZiAoIWFwaUtleSkge1xyXG4gICAgICAgICAgICAgIHNhZmVTZW5kUmVzcG9uc2UoeyBcclxuICAgICAgICAgICAgICAgIHN1Y2Nlc3M6IGZhbHNlLCBcclxuICAgICAgICAgICAgICAgIGVycm9yOiAnTm90IGF1dGhlbnRpY2F0ZWQuIFBsZWFzZSBzaWduIGluIHRvIHVzZSBQcml2YWN5UGFsLicgXHJcbiAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHByb3h5RGVjb2RlUmVxdWVzdChyZXF1ZXN0LmRhdGEsIHJlcXVlc3QuY29udGludWF0aW9uSWQsIHJlcXVlc3QuaGFzaGVzLCByZXF1ZXN0LmFwaVVybCB8fCBERUZBVUxUX0VORFBPSU5UUy5hcGlVcmwsIGFwaUtleSk7XHJcbiAgICAgICAgICAgIHNhZmVTZW5kUmVzcG9uc2UocmVzdWx0KTtcclxuICAgICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ1tQcml2YWN5UGFsXSBkZWNvZGVEYXRhIGVycm9yOicsIGVycm9yKTtcclxuICAgICAgICAgICAgc2FmZVNlbmRSZXNwb25zZSh7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogZXJyb3IubWVzc2FnZSB8fCBTdHJpbmcoZXJyb3IpIH0pO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pKCk7XHJcbiAgICAgICAgcmV0dXJuIHRydWU7IC8vIEFzeW5jIHJlc3BvbnNlXHJcblxyXG4gICAgICBjYXNlICdlbmNvZGVGaWxlJzpcclxuICAgICAgICAvLyBQcm94eSBmaWxlIGVuY29kaW5nIHJlcXVlc3QgdGhyb3VnaCBiYWNrZ3JvdW5kIChieXBhc3NlcyBDU1ApXHJcbiAgICAgICAgKGFzeW5jICgpID0+IHtcclxuICAgICAgICAgIGxldCByZXNwb25zZVNlbnQgPSBmYWxzZTtcclxuICAgICAgICAgIGNvbnN0IHNhZmVTZW5kUmVzcG9uc2UgPSAocmVzcG9uc2UpID0+IHtcclxuICAgICAgICAgICAgaWYgKCFyZXNwb25zZVNlbnQpIHtcclxuICAgICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgc2VuZFJlc3BvbnNlKHJlc3BvbnNlKTtcclxuICAgICAgICAgICAgICAgIHJlc3BvbnNlU2VudCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKCdbUHJpdmFjeVBhbF0gRmFpbGVkIHRvIHNlbmQgZW5jb2RlRmlsZSByZXNwb25zZTonLCBlcnIpO1xyXG4gICAgICAgICAgICAgICAgcmVzcG9uc2VTZW50ID0gdHJ1ZTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH07XHJcblxyXG4gICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgLy8gVXNlIHBhc3NlZCBhcGlLZXkgaWYgcHJvdmlkZWQsIG90aGVyd2lzZSBnZXQgZnJvbSBzdG9yYWdlXHJcbiAgICAgICAgICAgIGxldCBhcGlLZXkgPSByZXF1ZXN0LmFwaUtleSB8fCBhd2FpdCBnZXRDdXJyZW50SldUVG9rZW4oKTtcclxuICAgICAgICAgICAgaWYgKCFhcGlLZXkpIHtcclxuICAgICAgICAgICAgICBzYWZlU2VuZFJlc3BvbnNlKHsgXHJcbiAgICAgICAgICAgICAgICBzdWNjZXNzOiBmYWxzZSwgXHJcbiAgICAgICAgICAgICAgICBlcnJvcjogJ05vdCBhdXRoZW50aWNhdGVkLiBQbGVhc2Ugc2lnbiBpbiB0byB1c2UgUHJpdmFjeVBhbC4nIFxyXG4gICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBjb25zb2xlLmxvZygnW1ByaXZhY3lQYWxdIFByb2Nlc3NpbmcgZW5jb2RlRmlsZSByZXF1ZXN0Li4uJywge1xyXG4gICAgICAgICAgICAgIGZpbGVOYW1lOiByZXF1ZXN0LmZpbGVOYW1lLFxyXG4gICAgICAgICAgICAgIGRhdGFMZW5ndGg6IHJlcXVlc3QuZmlsZURhdGE/Lmxlbmd0aCxcclxuICAgICAgICAgICAgICBoYXNBcGlLZXk6ICEhYXBpS2V5LFxyXG4gICAgICAgICAgICAgIHBsYXRmb3JtOiByZXF1ZXN0LnBsYXRmb3JtXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgLy8gQWRkIHRpbWVvdXQgd3JhcHBlciAoMjUgc2Vjb25kcyBtYXgpXHJcbiAgICAgICAgICAgIGNvbnN0IGVuY29kZVByb21pc2UgPSBwcm94eUVuY29kZUZpbGVSZXF1ZXN0KHJlcXVlc3QuZmlsZURhdGEsIHJlcXVlc3QuZmlsZU5hbWUsIHJlcXVlc3QuYXBpVXJsIHx8IERFRkFVTFRfRU5EUE9JTlRTLmFwaVVybCwgYXBpS2V5LCByZXF1ZXN0LnBsYXRmb3JtKTtcclxuICAgICAgICAgICAgY29uc3QgdGltZW91dFByb21pc2UgPSBuZXcgUHJvbWlzZSgoXywgcmVqZWN0KSA9PiB7XHJcbiAgICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICByZWplY3QobmV3IEVycm9yKCdGaWxlIGVuY29kZSByZXF1ZXN0IHRpbWVkIG91dCBhZnRlciA2MCBzZWNvbmRzJykpO1xyXG4gICAgICAgICAgICAgIH0sIDYwMDAwKTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBQcm9taXNlLnJhY2UoW2VuY29kZVByb21pc2UsIHRpbWVvdXRQcm9taXNlXSk7XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICBjb25zb2xlLmxvZygnW1ByaXZhY3lQYWxdIEZpbGUgZW5jb2RlIHJlc3BvbnNlIHJlYWR5Jywge1xyXG4gICAgICAgICAgICAgIHN1Y2Nlc3M6IHJlc3VsdC5zdWNjZXNzLFxyXG4gICAgICAgICAgICAgIGhhc0NvbnRpbnVhdGlvbklkOiAhIXJlc3VsdC5kYXRhPy5jb250aW51YXRpb25JZFxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgc2FmZVNlbmRSZXNwb25zZShyZXN1bHQpO1xyXG4gICAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcignW1ByaXZhY3lQYWxdIGVuY29kZUZpbGUgZXJyb3I6JywgZXJyb3IpO1xyXG4gICAgICAgICAgICBjb25zdCBlcnJvck1lc3NhZ2UgPSBlcnJvci5tZXNzYWdlIHx8IFN0cmluZyhlcnJvcik7XHJcbiAgICAgICAgICAgIHNhZmVTZW5kUmVzcG9uc2UoeyBcclxuICAgICAgICAgICAgICBzdWNjZXNzOiBmYWxzZSwgXHJcbiAgICAgICAgICAgICAgZXJyb3I6IGVycm9yTWVzc2FnZSxcclxuICAgICAgICAgICAgICB0aW1lb3V0OiBlcnJvck1lc3NhZ2UuaW5jbHVkZXMoJ3RpbWVvdXQnKVxyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9KSgpO1xyXG4gICAgICAgIHJldHVybiB0cnVlOyAvLyBBc3luYyByZXNwb25zZVxyXG5cclxuICAgICAgY2FzZSAnZ2V0Q29uZmlnJzpcclxuICAgICAgICBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoWydhcGlVcmwnLCAndXNlclBvcnRhbFVybCcsICdlbmFibGVkJywgJ2RlYnVnJywgJ3Nob3dOb3RpZmljYXRpb25zJ10sIChyZXN1bHQpID0+IHtcclxuICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIC8vIE1pZ3JhdGUgbG9jYWxob3N0IFVSTHMgdG8gcHJvZHVjdGlvbiBVUkxzXHJcbiAgICAgICAgICAgIGxldCBhcGlVcmwgPSByZXN1bHQuYXBpVXJsIHx8IERFRkFVTFRfQ09ORklHLmFwaVVybDtcclxuICAgICAgICAgICAgbGV0IHVzZXJQb3J0YWxVcmwgPSByZXN1bHQudXNlclBvcnRhbFVybCB8fCBERUZBVUxUX0NPTkZJRy51c2VyUG9ydGFsVXJsO1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgaWYgKGFwaVVybC5pbmNsdWRlcygnbG9jYWxob3N0OjQyMDI2JykgfHwgYXBpVXJsLmluY2x1ZGVzKCcxMjcuMC4wLjE6NDIwMjYnKSkge1xyXG4gICAgICAgICAgICAgIGFwaVVybCA9IERFRkFVTFRfQ09ORklHLmFwaVVybDtcclxuICAgICAgICAgICAgICAvLyBVcGRhdGUgc3RvcmVkIGNvbmZpZ1xyXG4gICAgICAgICAgICAgIGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7IGFwaVVybCB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgaWYgKHVzZXJQb3J0YWxVcmwuaW5jbHVkZXMoJ2xvY2FsaG9zdDo1MTc0JykgfHwgdXNlclBvcnRhbFVybC5pbmNsdWRlcygnMTI3LjAuMC4xOjUxNzQnKSkge1xyXG4gICAgICAgICAgICAgIHVzZXJQb3J0YWxVcmwgPSBERUZBVUxUX0NPTkZJRy51c2VyUG9ydGFsVXJsO1xyXG4gICAgICAgICAgICAgIC8vIFVwZGF0ZSBzdG9yZWQgY29uZmlnXHJcbiAgICAgICAgICAgICAgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgdXNlclBvcnRhbFVybCB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgY29uc3QgY29uZmlnID0ge1xyXG4gICAgICAgICAgICAgIC4uLkRFRkFVTFRfQ09ORklHLFxyXG4gICAgICAgICAgICAgIC4uLnJlc3VsdCxcclxuICAgICAgICAgICAgICBhcGlVcmwsXHJcbiAgICAgICAgICAgICAgdXNlclBvcnRhbFVybFxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICBzZW5kUmVzcG9uc2UoeyBjb25maWcgfSk7XHJcbiAgICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcignW1ByaXZhY3lQYWxdIEZhaWxlZCB0byBzZW5kIGdldENvbmZpZyByZXNwb25zZTonLCBlcnIpO1xyXG4gICAgICAgICAgICBzZW5kUmVzcG9uc2UoeyBjb25maWc6IERFRkFVTFRfQ09ORklHIH0pO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHJldHVybiB0cnVlOyAvLyBBc3luYyByZXNwb25zZVxyXG5cclxuICAgICAgY2FzZSAnZ2V0U2Vzc2lvbic6XHJcbiAgICAgICAgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KFsncHJpdmFjeXBhbF9zZXNzaW9uJ10sIChyZXN1bHQpID0+IHtcclxuICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIHNlbmRSZXNwb25zZSh7IHByaXZhY3lwYWxfc2Vzc2lvbjogcmVzdWx0LnByaXZhY3lwYWxfc2Vzc2lvbiB8fCBudWxsIH0pO1xyXG4gICAgICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ1tQcml2YWN5UGFsXSBGYWlsZWQgdG8gc2VuZCBnZXRTZXNzaW9uIHJlc3BvbnNlOicsIGVycik7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgcmV0dXJuIHRydWU7IC8vIEFzeW5jIHJlc3BvbnNlXHJcblxyXG4gICAgICBjYXNlICd1cGRhdGVDb25maWcnOlxyXG4gICAgICAgIGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldChyZXF1ZXN0LmNvbmZpZywgKCkgPT4ge1xyXG4gICAgICAgICAgc2VuZFJlc3BvbnNlKHsgc3VjY2VzczogdHJ1ZSB9KTtcclxuICAgICAgICAgIGJyb2FkY2FzdENvbmZpZ0NoYW5nZShyZXF1ZXN0LmNvbmZpZyk7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgcmV0dXJuIHRydWU7IC8vIEFzeW5jIHJlc3BvbnNlXHJcblxyXG4gICAgICBjYXNlICdnZXRTdGF0cyc6XHJcbiAgICAgICAgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KFsnc3RhdHMnXSwgKHJlc3VsdCkgPT4ge1xyXG4gICAgICAgICAgY29uc3QgY3VycmVudFN0YXRzID0gcmVzdWx0LnN0YXRzIHx8IHN0YXRzO1xyXG4gICAgICAgICAgY29uc29sZS5sb2coJ1tQcml2YWN5UGFsXSBnZXRTdGF0cyByZXNwb25zZTonLCBjdXJyZW50U3RhdHMpO1xyXG4gICAgICAgICAgc2VuZFJlc3BvbnNlKHsgc3RhdHM6IGN1cnJlbnRTdGF0cyB9KTtcclxuICAgICAgICB9KTtcclxuICAgICAgICByZXR1cm4gdHJ1ZTsgLy8gQXN5bmMgcmVzcG9uc2VcclxuXHJcbiAgICAgIGNhc2UgJ3Jlc2V0U3RhdHMnOlxyXG4gICAgICAgIHN0YXRzID0ge1xyXG4gICAgICAgICAgcmVxdWVzdHNJbnRlcmNlcHRlZDogMCxcclxuICAgICAgICAgIHJlc3BvbnNlc01vZGlmaWVkOiAwLFxyXG4gICAgICAgICAgZGF0YVByb3RlY3RlZDogMCxcclxuICAgICAgICAgIGxhc3RJbnRlcmNlcHRpb246IG51bGwsXHJcbiAgICAgICAgICBzZXNzaW9uU3RhcnQ6IERhdGUubm93KCksXHJcbiAgICAgICAgICBjb250aW51YXRpb25JZHM6IFtdXHJcbiAgICAgICAgfTtcclxuICAgICAgICBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoeyBzdGF0cyB9LCAoKSA9PiB7XHJcbiAgICAgICAgICBzZW5kUmVzcG9uc2UoeyBzdWNjZXNzOiB0cnVlLCBzdGF0cyB9KTtcclxuICAgICAgICB9KTtcclxuICAgICAgICByZXR1cm4gdHJ1ZTsgLy8gQXN5bmMgcmVzcG9uc2VcclxuXHJcbiAgICAgIGNhc2UgJ3JlY29yZENvbnRpbnVhdGlvbklkJzpcclxuICAgICAgICAvLyBSZWNvcmQgYSBjb250aW51YXRpb25JZCB3aGVuIGEgcmVxdWVzdCBpcyBpbnRlcmNlcHRlZFxyXG4gICAgICAgIHJlY29yZENvbnRpbnVhdGlvbklkKHJlcXVlc3QuY29udGludWF0aW9uSWQsIHJlcXVlc3QuZGF0YVByb3RlY3RlZCk7XHJcbiAgICAgICAgc2VuZFJlc3BvbnNlKHsgc3VjY2VzczogdHJ1ZSB9KTtcclxuICAgICAgICByZXR1cm4gdHJ1ZTsgLy8gQXN5bmMgcmVzcG9uc2VcclxuXHJcbiAgICAgIGNhc2UgJ3Rlc3RDb25uZWN0aW9uJzpcclxuICAgICAgICAoYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgLy8gR2V0IEpXVCB0b2tlbiBmcm9tIGF1dGhlbnRpY2F0ZWQgc2Vzc2lvblxyXG4gICAgICAgICAgICBjb25zdCBhcGlLZXkgPSBhd2FpdCBnZXRDdXJyZW50SldUVG9rZW4oKTtcclxuICAgICAgICAgICAgaWYgKCFhcGlLZXkpIHtcclxuICAgICAgICAgICAgICBzZW5kUmVzcG9uc2UoeyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6ICdOb3QgYXV0aGVudGljYXRlZC4gUGxlYXNlIHNpZ24gaW4gdG8gdGVzdCBjb25uZWN0aW9uLicgfSk7XHJcbiAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHRlc3RDb25uZWN0aW9uKHJlcXVlc3QuYXBpVXJsIHx8IERFRkFVTFRfRU5EUE9JTlRTLmFwaVVybCwgYXBpS2V5KTtcclxuICAgICAgICAgICAgc2VuZFJlc3BvbnNlKHJlc3VsdCk7XHJcbiAgICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgICBzZW5kUmVzcG9uc2UoeyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IGVycm9yLm1lc3NhZ2UgfSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSkoKTtcclxuICAgICAgICByZXR1cm4gdHJ1ZTsgLy8gQXN5bmMgcmVzcG9uc2VcclxuXHJcbiAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgc2VuZFJlc3BvbnNlKHsgZXJyb3I6ICdVbmtub3duIGFjdGlvbicgfSk7XHJcbiAgICB9XHJcbiAgfSk7XHJcblxyXG4vKipcclxuICogSGFuZGxlIGludGVyY2VwdG9yIHJlYWR5IG5vdGlmaWNhdGlvblxyXG4gKi9cclxuZnVuY3Rpb24gaGFuZGxlSW50ZXJjZXB0b3JSZWFkeShkYXRhLCBzZW5kZXIpIHtcclxuICBjb25zb2xlLmxvZygnW1ByaXZhY3lQYWxdIEludGVyY2VwdG9yIHJlYWR5IG9uOicsIGRhdGEudXJsKTtcclxuICBcclxuICAvLyBVcGRhdGUgYmFkZ2UgdG8gc2hvdyBleHRlbnNpb24gaXMgYWN0aXZlXHJcbiAgaWYgKHNlbmRlci50YWI/LmlkKSB7XHJcbiAgICBjaHJvbWUuYWN0aW9uLnNldEJhZGdlVGV4dCh7XHJcbiAgICAgIHRleHQ6ICdcdTI3MTMnLFxyXG4gICAgICB0YWJJZDogc2VuZGVyLnRhYi5pZFxyXG4gICAgfSk7XHJcblxyXG4gICAgY2hyb21lLmFjdGlvbi5zZXRCYWRnZUJhY2tncm91bmRDb2xvcih7XHJcbiAgICAgIGNvbG9yOiAnIzQxNjllMScsXHJcbiAgICAgIHRhYklkOiBzZW5kZXIudGFiLmlkXHJcbiAgICB9KTtcclxuICB9XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBIYW5kbGUgcmVxdWVzdCBpbnRlcmNlcHRpb24gbm90aWZpY2F0aW9uXHJcbiAqL1xyXG5mdW5jdGlvbiBoYW5kbGVSZXF1ZXN0SW50ZXJjZXB0ZWQoZGF0YSwgc2VuZGVyKSB7XHJcbiAgLy8gUmVjb3JkIGNvbnRpbnVhdGlvbklkIGlmIHByb3ZpZGVkICh0aGlzIHdpbGwgdXBkYXRlIHN0YXRzKVxyXG4gIGlmIChkYXRhLmNvbnRpbnVhdGlvbklkKSB7XHJcbiAgICBjb25zdCBkYXRhUHJvdGVjdGVkID0gZGF0YS5zdGF0cz8uZGF0YVByb3RlY3RlZCB8fCAwO1xyXG4gICAgcmVjb3JkQ29udGludWF0aW9uSWQoZGF0YS5jb250aW51YXRpb25JZCwgZGF0YVByb3RlY3RlZCk7XHJcbiAgfSBlbHNlIHtcclxuICAgIC8vIEZhbGxiYWNrOiB1cGRhdGUgc3RhdHMgZGlyZWN0bHkgaWYgbm8gY29udGludWF0aW9uSWRcclxuICAgIHN0YXRzLnJlcXVlc3RzSW50ZXJjZXB0ZWQgPSAoZGF0YS5zdGF0cz8ucmVxdWVzdHNJbnRlcmNlcHRlZCB8fCAwKTtcclxuICAgIHN0YXRzLnJlc3BvbnNlc01vZGlmaWVkID0gKGRhdGEuc3RhdHM/LnJlc3BvbnNlc01vZGlmaWVkIHx8IDApO1xyXG4gICAgc3RhdHMuZGF0YVByb3RlY3RlZCA9IChzdGF0cy5kYXRhUHJvdGVjdGVkIHx8IDApICsgKGRhdGEuc3RhdHM/LmRhdGFQcm90ZWN0ZWQgfHwgMCk7XHJcbiAgICBzdGF0cy5sYXN0SW50ZXJjZXB0aW9uID0gbmV3IERhdGUoKS50b0lTT1N0cmluZygpO1xyXG4gICAgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgc3RhdHMgfSk7XHJcbiAgfVxyXG5cclxuICBjb25zb2xlLmxvZygnW1ByaXZhY3lQYWxdIFJlcXVlc3QgaW50ZXJjZXB0ZWQ6Jywge1xyXG4gICAgcGxhdGZvcm06IGRhdGEucGxhdGZvcm0sXHJcbiAgICBjb250aW51YXRpb25JZDogZGF0YS5jb250aW51YXRpb25JZCxcclxuICAgIGRhdGFQcm90ZWN0ZWQ6IGRhdGEuc3RhdHM/LmRhdGFQcm90ZWN0ZWQgfHwgMFxyXG4gIH0pO1xyXG5cclxuICAvLyBTaG93IG5vdGlmaWNhdGlvbiBpZiBlbmFibGVkXHJcbiAgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KFsnc2hvd05vdGlmaWNhdGlvbnMnXSwgKHJlc3VsdCkgPT4ge1xyXG4gICAgaWYgKHJlc3VsdC5zaG93Tm90aWZpY2F0aW9ucykge1xyXG4gICAgICBzaG93SW50ZXJjZXB0aW9uTm90aWZpY2F0aW9uKGRhdGEucGxhdGZvcm0sIHNlbmRlci50YWI/LmlkKTtcclxuICAgIH1cclxuICB9KTtcclxufVxyXG5cclxuLyoqXHJcbiAqIFJlY29yZCBhIGNvbnRpbnVhdGlvbklkIGZvciBzdGF0cyB0cmFja2luZ1xyXG4gKi9cclxuZnVuY3Rpb24gcmVjb3JkQ29udGludWF0aW9uSWQoY29udGludWF0aW9uSWQsIGRhdGFQcm90ZWN0ZWQgPSAwKSB7XHJcbiAgaWYgKCFjb250aW51YXRpb25JZCkgcmV0dXJuO1xyXG4gIFxyXG4gIC8vIExvYWQgY3VycmVudCBzdGF0c1xyXG4gIGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChbJ3N0YXRzJ10sIChyZXN1bHQpID0+IHtcclxuICAgIGNvbnN0IGN1cnJlbnRTdGF0cyA9IHJlc3VsdC5zdGF0cyB8fCB7IC4uLnN0YXRzIH07XHJcbiAgICBcclxuICAgIC8vIEVuc3VyZSBjb250aW51YXRpb25JZHMgYXJyYXkgZXhpc3RzXHJcbiAgICBpZiAoIWN1cnJlbnRTdGF0cy5jb250aW51YXRpb25JZHMpIHtcclxuICAgICAgY3VycmVudFN0YXRzLmNvbnRpbnVhdGlvbklkcyA9IFtdO1xyXG4gICAgfVxyXG4gICAgXHJcbiAgICAvLyBBZGQgY29udGludWF0aW9uSWQgaWYgbm90IGFscmVhZHkgcHJlc2VudFxyXG4gICAgaWYgKCFjdXJyZW50U3RhdHMuY29udGludWF0aW9uSWRzLmluY2x1ZGVzKGNvbnRpbnVhdGlvbklkKSkge1xyXG4gICAgICBjdXJyZW50U3RhdHMuY29udGludWF0aW9uSWRzLnB1c2goY29udGludWF0aW9uSWQpO1xyXG4gICAgICBjdXJyZW50U3RhdHMucmVxdWVzdHNJbnRlcmNlcHRlZCA9IGN1cnJlbnRTdGF0cy5jb250aW51YXRpb25JZHMubGVuZ3RoO1xyXG4gICAgICBjdXJyZW50U3RhdHMubGFzdEludGVyY2VwdGlvbiA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcclxuICAgIH1cclxuICAgIFxyXG4gICAgLy8gQWx3YXlzIGFjY3VtdWxhdGUgZGF0YVByb3RlY3RlZCAoZXZlbiBpZiBjb250aW51YXRpb25JZCBhbHJlYWR5IGV4aXN0cywgZGF0YSBwb2ludHMgbWF5IGJlIG5ldylcclxuICAgIGN1cnJlbnRTdGF0cy5kYXRhUHJvdGVjdGVkID0gKGN1cnJlbnRTdGF0cy5kYXRhUHJvdGVjdGVkIHx8IDApICsgKGRhdGFQcm90ZWN0ZWQgfHwgMCk7XHJcbiAgICBcclxuICAgIC8vIFVwZGF0ZSBzdGF0c1xyXG4gICAgc3RhdHMgPSBjdXJyZW50U3RhdHM7XHJcbiAgICBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoeyBzdGF0cyB9KTtcclxuICAgIFxyXG4gICAgY29uc29sZS5sb2coJ1tQcml2YWN5UGFsXSBTdGF0cyB1cGRhdGVkOicsIHtcclxuICAgICAgY29udGludWF0aW9uSWRzOiBjdXJyZW50U3RhdHMuY29udGludWF0aW9uSWRzLmxlbmd0aCxcclxuICAgICAgZGF0YVByb3RlY3RlZDogY3VycmVudFN0YXRzLmRhdGFQcm90ZWN0ZWRcclxuICAgIH0pO1xyXG4gIH0pO1xyXG59XHJcblxyXG4vKipcclxuICogU2hvdyBpbnRlcmNlcHRpb24gbm90aWZpY2F0aW9uXHJcbiAqL1xyXG5mdW5jdGlvbiBzaG93SW50ZXJjZXB0aW9uTm90aWZpY2F0aW9uKHBsYXRmb3JtLCB0YWJJZCkge1xyXG4gIGlmICghdGFiSWQpIHJldHVybjtcclxuXHJcbiAgLy8gVXBkYXRlIGJhZGdlXHJcbiAgY2hyb21lLmFjdGlvbi5zZXRCYWRnZVRleHQoe1xyXG4gICAgdGV4dDogJ1x1RDgzRFx1REVFMVx1RkUwRicsXHJcbiAgICB0YWJJZDogdGFiSWRcclxuICB9KTtcclxuXHJcbiAgY2hyb21lLmFjdGlvbi5zZXRCYWRnZUJhY2tncm91bmRDb2xvcih7XHJcbiAgICBjb2xvcjogJyMxMGEzN2YnLFxyXG4gICAgdGFiSWQ6IHRhYklkXHJcbiAgfSk7XHJcblxyXG4gIC8vIENsZWFyIGJhZGdlIGFmdGVyIDIgc2Vjb25kc1xyXG4gIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgY2hyb21lLmFjdGlvbi5zZXRCYWRnZVRleHQoe1xyXG4gICAgICB0ZXh0OiAnXHUyNzEzJyxcclxuICAgICAgdGFiSWQ6IHRhYklkXHJcbiAgICB9KTtcclxuICAgIFxyXG4gICAgY2hyb21lLmFjdGlvbi5zZXRCYWRnZUJhY2tncm91bmRDb2xvcih7XHJcbiAgICAgIGNvbG9yOiAnIzQxNjllMScsXHJcbiAgICAgIHRhYklkOiB0YWJJZFxyXG4gICAgfSk7XHJcbiAgfSwgMjAwMCk7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBCcm9hZGNhc3QgY29uZmlndXJhdGlvbiBjaGFuZ2VzIHRvIGFsbCB0YWJzXHJcbiAqL1xyXG5mdW5jdGlvbiBicm9hZGNhc3RDb25maWdDaGFuZ2UoY29uZmlnKSB7XHJcbiAgY2hyb21lLnRhYnMucXVlcnkoe30sICh0YWJzKSA9PiB7XHJcbiAgICB0YWJzLmZvckVhY2goKHRhYikgPT4ge1xyXG4gICAgICBjaHJvbWUudGFicy5zZW5kTWVzc2FnZSh0YWIuaWQsIHtcclxuICAgICAgICBhY3Rpb246ICdjb25maWdVcGRhdGVkJyxcclxuICAgICAgICBjb25maWc6IGNvbmZpZ1xyXG4gICAgICB9KS5jYXRjaCgoKSA9PiB7XHJcbiAgICAgICAgLy8gVGFiIG1pZ2h0IG5vdCBoYXZlIGNvbnRlbnQgc2NyaXB0IGxvYWRlZFxyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH0pO1xyXG59XHJcblxyXG4vKipcclxuICogVGVzdCBjb25uZWN0aW9uIHRvIFByaXZhY3lQYWwgQVBJXHJcbiAqL1xyXG5hc3luYyBmdW5jdGlvbiB0ZXN0Q29ubmVjdGlvbihhcGlVcmwsIGFwaUtleSkge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke2FwaVVybH0vaGVhbHRoYCwge1xyXG4gICAgICBtZXRob2Q6ICdHRVQnLFxyXG4gICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgJ3gtYWNjZXNzLXRva2VuJzogYXBpS2V5LFxyXG4gICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbidcclxuICAgICAgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgaWYgKHJlc3BvbnNlLm9rKSB7XHJcbiAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIG1lc3NhZ2U6ICdDb25uZWN0ZWQgdG8gUHJpdmFjeVBhbCBBUEknIH07XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXR1cm4geyBcclxuICAgICAgICBzdWNjZXNzOiBmYWxzZSwgXHJcbiAgICAgICAgZXJyb3I6IGBBUEkgcmV0dXJuZWQgc3RhdHVzICR7cmVzcG9uc2Uuc3RhdHVzfWAgXHJcbiAgICAgIH07XHJcbiAgICB9XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIHJldHVybiB7IFxyXG4gICAgICBzdWNjZXNzOiBmYWxzZSwgXHJcbiAgICAgIGVycm9yOiBgQ29ubmVjdGlvbiBmYWlsZWQ6ICR7ZXJyb3IubWVzc2FnZX1gIFxyXG4gICAgfTtcclxuICB9XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBNb25pdG9yIHRhYiB1cGRhdGVzIHRvIGluamVjdCBjb250ZW50IHNjcmlwdHMgb24gc3VwcG9ydGVkIHBhZ2VzXHJcbiAqL1xyXG5jaHJvbWUudGFicy5vblVwZGF0ZWQuYWRkTGlzdGVuZXIoKHRhYklkLCBjaGFuZ2VJbmZvLCB0YWIpID0+IHtcclxuICBpZiAoY2hhbmdlSW5mby5zdGF0dXMgPT09ICdjb21wbGV0ZScgJiYgdGFiLnVybCkge1xyXG4gICAgY29uc3QgaXNDaGF0R1BUID0gdGFiLnVybC5pbmNsdWRlcygnY2hhdGdwdC5jb20nKTtcclxuICAgIGNvbnN0IGlzQ2xhdWRlID0gdGFiLnVybC5pbmNsdWRlcygnY2xhdWRlLmFpJyk7XHJcbiAgICBcclxuICAgIGlmIChpc0NoYXRHUFQgfHwgaXNDbGF1ZGUpIHtcclxuICAgICAgY29uc29sZS5sb2coJ1tQcml2YWN5UGFsXSBTdXBwb3J0ZWQgcGFnZSBkZXRlY3RlZDonLCB0YWIudXJsKTtcclxuICAgICAgXHJcbiAgICAgIC8vIFNob3cgYmFkZ2VcclxuICAgICAgY2hyb21lLmFjdGlvbi5zZXRCYWRnZVRleHQoe1xyXG4gICAgICAgIHRleHQ6ICdcdTI3MTMnLFxyXG4gICAgICAgIHRhYklkOiB0YWJJZFxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGNocm9tZS5hY3Rpb24uc2V0QmFkZ2VCYWNrZ3JvdW5kQ29sb3Ioe1xyXG4gICAgICAgIGNvbG9yOiAnIzQxNjllMScsXHJcbiAgICAgICAgdGFiSWQ6IHRhYklkXHJcbiAgICAgIH0pO1xyXG4gICAgfVxyXG4gIH1cclxufSk7XHJcblxyXG4vKipcclxuICogSGFuZGxlIGV4dGVuc2lvbiBzdGFydHVwXHJcbiAqL1xyXG5jaHJvbWUucnVudGltZS5vblN0YXJ0dXAuYWRkTGlzdGVuZXIoYXN5bmMgKCkgPT4ge1xyXG4gIGNvbnNvbGUubG9nKCdbUHJpdmFjeVBhbF0gRXh0ZW5zaW9uIHN0YXJ0ZWQnKTtcclxuICBcclxuICAvLyBMb2FkIHN0YXRzIGZyb20gc3RvcmFnZVxyXG4gIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChbJ3N0YXRzJ10pO1xyXG4gIGlmIChyZXN1bHQuc3RhdHMpIHtcclxuICAgIHN0YXRzID0gcmVzdWx0LnN0YXRzO1xyXG4gIH1cclxufSk7XHJcblxyXG4vKipcclxuICogQ29udGV4dCBtZW51IGNyZWF0aW9uXHJcbiAqL1xyXG5jaHJvbWUucnVudGltZS5vbkluc3RhbGxlZC5hZGRMaXN0ZW5lcigoKSA9PiB7XHJcbiAgY2hyb21lLmNvbnRleHRNZW51cy5jcmVhdGUoe1xyXG4gICAgaWQ6ICdwcml2YWN5cGFsLXRvZ2dsZScsXHJcbiAgICB0aXRsZTogJ1RvZ2dsZSBQcml2YWN5UGFsIFByb3RlY3Rpb24nLFxyXG4gICAgY29udGV4dHM6IFsncGFnZSddXHJcbiAgfSk7XHJcblxyXG4gIGNocm9tZS5jb250ZXh0TWVudXMuY3JlYXRlKHtcclxuICAgIGlkOiAncHJpdmFjeXBhbC1zdGF0cycsXHJcbiAgICB0aXRsZTogJ1ZpZXcgUHJvdGVjdGlvbiBTdGF0aXN0aWNzJyxcclxuICAgIGNvbnRleHRzOiBbJ3BhZ2UnXVxyXG4gIH0pO1xyXG59KTtcclxuXHJcbi8qKlxyXG4gKiBIYW5kbGUgY29udGV4dCBtZW51IGNsaWNrc1xyXG4gKi9cclxuY2hyb21lLmNvbnRleHRNZW51cy5vbkNsaWNrZWQuYWRkTGlzdGVuZXIoKGluZm8sIHRhYikgPT4ge1xyXG4gIHN3aXRjaCAoaW5mby5tZW51SXRlbUlkKSB7XHJcbiAgICBjYXNlICdwcml2YWN5cGFsLXRvZ2dsZSc6XHJcbiAgICAgIHRvZ2dsZVByb3RlY3Rpb24oKTtcclxuICAgICAgYnJlYWs7XHJcbiAgICBcclxuICAgIGNhc2UgJ3ByaXZhY3lwYWwtc3RhdHMnOlxyXG4gICAgICBzaG93U3RhdHNOb3RpZmljYXRpb24oKTtcclxuICAgICAgYnJlYWs7XHJcbiAgfVxyXG59KTtcclxuXHJcbi8qKlxyXG4gKiBUb2dnbGUgcHJvdGVjdGlvbiBvbi9vZmZcclxuICovXHJcbmFzeW5jIGZ1bmN0aW9uIHRvZ2dsZVByb3RlY3Rpb24oKSB7XHJcbiAgY29uc3QgcmVzdWx0ID0gYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KFsnZW5hYmxlZCddKTtcclxuICBjb25zdCBuZXdTdGF0ZSA9ICFyZXN1bHQuZW5hYmxlZDtcclxuICBcclxuICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoeyBlbmFibGVkOiBuZXdTdGF0ZSB9KTtcclxuICBcclxuICBjb25zdCBtZXNzYWdlID0gbmV3U3RhdGUgPyAnXHUyNzA1IFByb3RlY3Rpb24gRW5hYmxlZCcgOiAnXHUyM0Y4XHVGRTBGIFByb3RlY3Rpb24gRGlzYWJsZWQnO1xyXG4gIFxyXG4gIGNvbnNvbGUubG9nKCdbUHJpdmFjeVBhbF0nLCBtZXNzYWdlKTtcclxuICBcclxuICAvLyBCcm9hZGNhc3QgdG8gYWxsIHRhYnNcclxuICBicm9hZGNhc3RDb25maWdDaGFuZ2UoeyBlbmFibGVkOiBuZXdTdGF0ZSB9KTtcclxufVxyXG5cclxuLyoqXHJcbiAqIFNob3cgc3RhdGlzdGljcyBub3RpZmljYXRpb25cclxuICovXHJcbmFzeW5jIGZ1bmN0aW9uIHNob3dTdGF0c05vdGlmaWNhdGlvbigpIHtcclxuICBjb25zdCByZXN1bHQgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoWydzdGF0cyddKTtcclxuICBjb25zdCBjdXJyZW50U3RhdHMgPSByZXN1bHQuc3RhdHMgfHwgc3RhdHM7XHJcbiAgXHJcbiAgY29uc29sZS5sb2coJ1tQcml2YWN5UGFsXSBTdGF0aXN0aWNzOicsIGN1cnJlbnRTdGF0cyk7XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBQcm94eSBlbmNvZGUgcmVxdWVzdCB0aHJvdWdoIGJhY2tncm91bmQgKGJ5cGFzc2VzIENTUClcclxuICovXHJcbmFzeW5jIGZ1bmN0aW9uIHByb3h5RW5jb2RlUmVxdWVzdChkYXRhLCBhcGlVcmwsIGFwaUtleSwgcGxhdGZvcm0gPSBudWxsKSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnNvbGUubG9nKCdbUHJpdmFjeVBhbF0gU3RhcnRpbmcgZW5jb2RlIHJlcXVlc3QnLCB7IFxyXG4gICAgICBkYXRhTGVuZ3RoOiBkYXRhPy5sZW5ndGgsIFxyXG4gICAgICBhcGlVcmwsIFxyXG4gICAgICBoYXNBcGlLZXk6ICEhYXBpS2V5LFxyXG4gICAgICBhcGlLZXlQcmV2aWV3OiBhcGlLZXkgPyBgJHthcGlLZXkuc3Vic3RyaW5nKDAsIDIwKX0uLi5gIDogJ251bGwnLFxyXG4gICAgICBwbGF0Zm9ybSBcclxuICAgIH0pO1xyXG4gICAgXHJcbiAgICBpZiAoIWRhdGEpIHtcclxuICAgICAgdGhyb3cgbmV3IEVycm9yKCdObyBkYXRhIHByb3ZpZGVkIGZvciBlbmNvZGUgcmVxdWVzdCcpO1xyXG4gICAgfVxyXG4gICAgXHJcbiAgICAvLyBObyB0b2tlbiB2YWxpZGF0aW9uIC0ganVzdCBwYXNzIHRocm91Z2gsIEFQSSB3aWxsIGhhbmRsZSBhdXRoIGVycm9yc1xyXG4gICAgLy8gSWYgYXBpS2V5IGlzIG51bGwvdW5kZWZpbmVkLCBBUEkgd2lsbCByZXR1cm4gNDAxXHJcbiAgICAvLyBBZGQgdGltZW91dCB0byBwcmV2ZW50IGhhbmdpbmcgKGluY3JlYXNlZCBmb3Igc2xvdyBBUEkpXHJcbiAgICBjb25zdCBjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xyXG4gICAgY29uc3QgdGltZW91dElkID0gc2V0VGltZW91dCgoKSA9PiBjb250cm9sbGVyLmFib3J0KCksIDYwMDAwKTsgLy8gNjAgc2Vjb25kIHRpbWVvdXRcclxuICAgIFxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgaGVhZGVycyA9IHtcclxuICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nXHJcbiAgICAgIH07XHJcbiAgICAgIFxyXG4gICAgICBpZiAoYXBpS2V5KSB7XHJcbiAgICAgICAgaGVhZGVyc1sneC1hY2Nlc3MtdG9rZW4nXSA9IGFwaUtleTtcclxuICAgICAgICBcclxuICAgICAgICAvLyBEZWNvZGUgdG9rZW4gdG8gc2hvdyB3aGF0IHdlJ3JlIHNlbmRpbmdcclxuICAgICAgICBsZXQgdG9rZW5QYXlsb2FkID0gbnVsbDtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgY29uc3QgcGFydHMgPSBhcGlLZXkuc3BsaXQoJy4nKTtcclxuICAgICAgICAgIGlmIChwYXJ0cy5sZW5ndGggPT09IDMpIHtcclxuICAgICAgICAgICAgdG9rZW5QYXlsb2FkID0gSlNPTi5wYXJzZShhdG9iKHBhcnRzWzFdLnJlcGxhY2UoLy0vZywgJysnKS5yZXBsYWNlKC9fL2csICcvJykpKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAvLyBJZ25vcmUgZGVjb2RlIGVycm9yc1xyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgICAgICBjb25zb2xlLmxvZygnW1ByaXZhY3lQYWxdIFx1RDgzRFx1RENFNCBTZW5kaW5nIHJlcXVlc3Qgd2l0aCB0b2tlbiBoZWFkZXInLCB7XHJcbiAgICAgICAgICB0b2tlbkxlbmd0aDogYXBpS2V5Lmxlbmd0aCxcclxuICAgICAgICAgIHRva2VuUHJldmlldzogYCR7YXBpS2V5LnN1YnN0cmluZygwLCAzMCl9Li4uJHthcGlLZXkuc3Vic3RyaW5nKGFwaUtleS5sZW5ndGggLSAyMCl9YCxcclxuICAgICAgICAgIGFwaVVybCxcclxuICAgICAgICAgIGhlYWRlck5hbWU6ICd4LWFjY2Vzcy10b2tlbicsXHJcbiAgICAgICAgICB0b2tlblBheWxvYWQ6IHRva2VuUGF5bG9hZCA/IHtcclxuICAgICAgICAgICAgdXNlcl9pZDogdG9rZW5QYXlsb2FkLnVzZXJfaWQsXHJcbiAgICAgICAgICAgIGVtYWlsOiB0b2tlblBheWxvYWQuZW1haWwsXHJcbiAgICAgICAgICAgIGV4cDogdG9rZW5QYXlsb2FkLmV4cCxcclxuICAgICAgICAgICAgZXhwaXJlc0F0OiB0b2tlblBheWxvYWQuZXhwID8gbmV3IERhdGUodG9rZW5QYXlsb2FkLmV4cCAqIDEwMDApLnRvSVNPU3RyaW5nKCkgOiBudWxsXHJcbiAgICAgICAgICB9IDogbnVsbFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ1tQcml2YWN5UGFsXSBcdTI3NEMgTm8gdG9rZW4gLSByZXF1ZXN0IHdpbGwgZmFpbCB3aXRoIDQwMScpO1xyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcignTm8gYXV0aGVudGljYXRpb24gdG9rZW4gYXZhaWxhYmxlLiBQbGVhc2Ugc2lnbiBpbiB0byB1c2UgUHJpdmFjeVBhbC4nKTtcclxuICAgICAgfVxyXG4gICAgICBcclxuICAgICAgY29uc29sZS5sb2coJ1tQcml2YWN5UGFsXSBcdUQ4M0RcdUREMzUgTWFraW5nIGVuY29kZSByZXF1ZXN0IHRvOicsIGAke2FwaVVybH0vYXBpL3NjYW5uZXIvZW5jb2RlYCk7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7YXBpVXJsfS9hcGkvc2Nhbm5lci9lbmNvZGVgLCB7XHJcbiAgICAgICAgbWV0aG9kOiAnUE9TVCcsXHJcbiAgICAgICAgaGVhZGVycyxcclxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgICBkYXRhLFxyXG4gICAgICAgICAgc291cmNlQ29udGFpbmVyOiAnYnJvd3Nlcl9leHRlbnNpb24nLFxyXG4gICAgICAgICAgbWV0YWRhdGE6IHsgXHJcbiAgICAgICAgICAgIHNvdXJjZTogJ2NoYXRfaW50ZXJjZXB0b3InLCBcclxuICAgICAgICAgICAgcGxhdGZvcm06IHBsYXRmb3JtIHx8ICdicm93c2VyX2V4dGVuc2lvbicsXHJcbiAgICAgICAgICAgIHRpbWVzdGFtcDogRGF0ZS5ub3coKSBcclxuICAgICAgICAgIH1cclxuICAgICAgICB9KSxcclxuICAgICAgICBzaWduYWw6IGNvbnRyb2xsZXIuc2lnbmFsXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgY2xlYXJUaW1lb3V0KHRpbWVvdXRJZCk7XHJcblxyXG4gICAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XHJcbiAgICAgICAgY29uc3QgZXJyb3JUZXh0ID0gYXdhaXQgcmVzcG9uc2UudGV4dCgpO1xyXG4gICAgICAgIGxldCBlcnJvckRldGFpbHM7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGVycm9yRGV0YWlscyA9IEpTT04ucGFyc2UoZXJyb3JUZXh0KTtcclxuICAgICAgICB9IGNhdGNoIHtcclxuICAgICAgICAgIGVycm9yRGV0YWlscyA9IHsgcmF3OiBlcnJvclRleHQgfTtcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICAgICAgY29uc29sZS5lcnJvcignW1ByaXZhY3lQYWxdIEVuY29kZSBBUEkgZXJyb3InLCB7IFxyXG4gICAgICAgICAgc3RhdHVzOiByZXNwb25zZS5zdGF0dXMsIFxyXG4gICAgICAgICAgc3RhdHVzVGV4dDogcmVzcG9uc2Uuc3RhdHVzVGV4dCxcclxuICAgICAgICAgIGVycm9yOiBlcnJvclRleHQsXHJcbiAgICAgICAgICBlcnJvckRldGFpbHMsXHJcbiAgICAgICAgICBhcGlVcmwsXHJcbiAgICAgICAgICBoYXNBcGlLZXk6ICEhYXBpS2V5LFxyXG4gICAgICAgICAgYXBpS2V5TGVuZ3RoOiBhcGlLZXk/Lmxlbmd0aCxcclxuICAgICAgICAgIHRva2VuUHJldmlldzogYXBpS2V5ID8gYCR7YXBpS2V5LnN1YnN0cmluZygwLCAzMCl9Li4uJHthcGlLZXkuc3Vic3RyaW5nKGFwaUtleS5sZW5ndGggLSAyMCl9YCA6ICdudWxsJyxcclxuICAgICAgICAgIHJlcXVlc3RIZWFkZXJzOiBPYmplY3Qua2V5cyhoZWFkZXJzKVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIFxyXG4gICAgICAgIC8vIElmIDQwMSwgdHJ5IHRvIHJlZnJlc2ggdGhlIHRva2VuIGFuZCByZXRyeSBvbmNlXHJcbiAgICAgICAgaWYgKHJlc3BvbnNlLnN0YXR1cyA9PT0gNDAxKSB7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZygnW1ByaXZhY3lQYWxdIFx1RDgzRFx1REQwNCA0MDEgZXJyb3IgLSBhdHRlbXB0aW5nIHRva2VuIHJlZnJlc2guLi4nKTtcclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLy8gVHJ5IHRvIHJlZnJlc2ggdG9rZW4gZnJvbSBzdG9yYWdlXHJcbiAgICAgICAgICBjb25zdCBzdG9yYWdlID0gYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KFsncHJpdmFjeXBhbF9zZXNzaW9uJ10pO1xyXG4gICAgICAgICAgaWYgKHN0b3JhZ2UucHJpdmFjeXBhbF9zZXNzaW9uPy5qd3RUb2tlbnM/LmFjY2Vzc190b2tlbikge1xyXG4gICAgICAgICAgICBjb25zdCBjb25maWcgPSBhd2FpdCBsb2FkQ29uZmlnKCk7XHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgY29uc3QgcmVmcmVzaFJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7Y29uZmlnLmFwaVVybH0vYXBpL3VzZXIvcmVmcmVzaC10b2tlbmAsIHtcclxuICAgICAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxyXG4gICAgICAgICAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0sXHJcbiAgICAgICAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IHRva2VuOiBzdG9yYWdlLnByaXZhY3lwYWxfc2Vzc2lvbi5qd3RUb2tlbnMuYWNjZXNzX3Rva2VuIH0pXHJcbiAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgaWYgKHJlZnJlc2hSZXNwb25zZS5vaykge1xyXG4gICAgICAgICAgICAgICAgY29uc3QgcmVmcmVzaERhdGEgPSBhd2FpdCByZWZyZXNoUmVzcG9uc2UuanNvbigpO1xyXG4gICAgICAgICAgICAgICAgY29uc3QgbmV3VG9rZW4gPSByZWZyZXNoRGF0YS5kYXRhPy50b2tlbiB8fCByZWZyZXNoRGF0YS50b2tlbjtcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgaWYgKG5ld1Rva2VuKSB7XHJcbiAgICAgICAgICAgICAgICAgIC8vIFVwZGF0ZSBzZXNzaW9uIHdpdGggbmV3IHRva2VuXHJcbiAgICAgICAgICAgICAgICAgIHN0b3JhZ2UucHJpdmFjeXBhbF9zZXNzaW9uLmp3dFRva2Vucy5hY2Nlc3NfdG9rZW4gPSBuZXdUb2tlbjtcclxuICAgICAgICAgICAgICAgICAgc3RvcmFnZS5wcml2YWN5cGFsX3Nlc3Npb24uand0VG9rZW5zLmV4cGlyZXNfYXQgPSBEYXRlLm5vdygpICsgKDI4ODAwICogMTAwMCk7XHJcbiAgICAgICAgICAgICAgICAgIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7IHByaXZhY3lwYWxfc2Vzc2lvbjogc3RvcmFnZS5wcml2YWN5cGFsX3Nlc3Npb24gfSk7XHJcbiAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnW1ByaXZhY3lQYWxdIFx1MjcwNSBUb2tlbiByZWZyZXNoZWQsIHJldHJ5aW5nIGVuY29kZSByZXF1ZXN0Li4uJyk7XHJcbiAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAvLyBSZXRyeSB0aGUgZW5jb2RlIHJlcXVlc3Qgd2l0aCBuZXcgdG9rZW5cclxuICAgICAgICAgICAgICAgICAgY29uc3QgcmV0cnlIZWFkZXJzID0ge1xyXG4gICAgICAgICAgICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXHJcbiAgICAgICAgICAgICAgICAgICAgJ3gtYWNjZXNzLXRva2VuJzogbmV3VG9rZW5cclxuICAgICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgIC8vIENyZWF0ZSBuZXcgY29udHJvbGxlciBmb3IgcmV0cnkgKG9yaWdpbmFsIG1pZ2h0IGJlIGFib3J0ZWQpXHJcbiAgICAgICAgICAgICAgICAgIGNvbnN0IHJldHJ5Q29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcclxuICAgICAgICAgICAgICAgICAgY29uc3QgcmV0cnlUaW1lb3V0SWQgPSBzZXRUaW1lb3V0KCgpID0+IHJldHJ5Q29udHJvbGxlci5hYm9ydCgpLCA2MDAwMCk7XHJcbiAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICBjb25zdCByZXRyeVJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7YXBpVXJsfS9hcGkvc2Nhbm5lci9lbmNvZGVgLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXHJcbiAgICAgICAgICAgICAgICAgICAgaGVhZGVyczogcmV0cnlIZWFkZXJzLFxyXG4gICAgICAgICAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICAgICAgICAgICAgICAgIGRhdGEsXHJcbiAgICAgICAgICAgICAgICAgICAgICBzb3VyY2VDb250YWluZXI6ICdicm93c2VyX2V4dGVuc2lvbicsXHJcbiAgICAgICAgICAgICAgICAgICAgICBtZXRhZGF0YTogeyBcclxuICAgICAgICAgICAgICAgICAgICAgICAgc291cmNlOiAnY2hhdF9pbnRlcmNlcHRvcicsIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGF0Zm9ybTogcGxhdGZvcm0gfHwgJ2Jyb3dzZXJfZXh0ZW5zaW9uJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGltZXN0YW1wOiBEYXRlLm5vdygpIFxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0pLFxyXG4gICAgICAgICAgICAgICAgICAgIHNpZ25hbDogcmV0cnlDb250cm9sbGVyLnNpZ25hbFxyXG4gICAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgIGNsZWFyVGltZW91dChyZXRyeVRpbWVvdXRJZCk7XHJcbiAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICBpZiAocmV0cnlSZXNwb25zZS5vaykge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHJldHJ5UmVzdWx0ID0gYXdhaXQgcmV0cnlSZXNwb25zZS5qc29uKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ1tQcml2YWN5UGFsXSBcdTI3MDUgRW5jb2RlIHJlcXVlc3Qgc3VjY2Vzc2Z1bCBhZnRlciB0b2tlbiByZWZyZXNoJyk7XHJcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSwgZGF0YTogcmV0cnlSZXN1bHQgfTtcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSBjYXRjaCAocmVmcmVzaEVycm9yKSB7XHJcbiAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignW1ByaXZhY3lQYWxdIFRva2VuIHJlZnJlc2ggZmFpbGVkOicsIHJlZnJlc2hFcnJvcik7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICAgIFxyXG4gICAgICAgICAgLy8gSWYgcmVmcmVzaCBmYWlsZWQgb3Igbm90IHBvc3NpYmxlLCB0aHJvdyBlcnJvclxyXG4gICAgICAgICAgY29uc3QgZXJyb3JNc2cgPSBlcnJvckRldGFpbHM/Lm1lc3NhZ2UgfHwgZXJyb3JEZXRhaWxzPy5lcnJvciB8fCBlcnJvclRleHQ7XHJcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYEF1dGhlbnRpY2F0aW9uIGZhaWxlZCAoNDAxKS4gVG9rZW4gZXhwaXJlZCBvciBpbnZhbGlkLiBQbGVhc2Ugc2lnbiBpbiBhZ2Fpbi4gRGV0YWlsczogJHtlcnJvck1zZ31gKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBFbmNvZGUgQVBJIHJldHVybmVkICR7cmVzcG9uc2Uuc3RhdHVzfTogJHtlcnJvclRleHR9YCk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcclxuICAgICAgY29uc29sZS5sb2coJ1tQcml2YWN5UGFsXSBFbmNvZGUgcmVxdWVzdCBzdWNjZXNzZnVsJywgeyBcclxuICAgICAgICBoYXNDb250aW51YXRpb25JZDogISFyZXN1bHQuY29udGludWF0aW9uSWQsXHJcbiAgICAgICAgdHJhbnNmb3JtYXRpb25zQ291bnQ6IHJlc3VsdC50cmFuc2Zvcm1hdGlvbnM/Lmxlbmd0aCBcclxuICAgICAgfSk7XHJcbiAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIGRhdGE6IHJlc3VsdCB9O1xyXG4gICAgfSBjYXRjaCAoZmV0Y2hFcnJvcikge1xyXG4gICAgICBjbGVhclRpbWVvdXQodGltZW91dElkKTtcclxuICAgICAgaWYgKGZldGNoRXJyb3IubmFtZSA9PT0gJ0Fib3J0RXJyb3InKSB7XHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdFbmNvZGUgcmVxdWVzdCB0aW1lZCBvdXQgYWZ0ZXIgMjUgc2Vjb25kcycpO1xyXG4gICAgICB9XHJcbiAgICAgIHRocm93IGZldGNoRXJyb3I7XHJcbiAgICB9XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoJ1tQcml2YWN5UGFsXSBFbmNvZGUgcHJveHkgZXJyb3I6JywgZXJyb3IpO1xyXG4gICAgdGhyb3cgZXJyb3I7IC8vIFJlLXRocm93IHNvIHRoZSBjYWxsZXIgY2FuIGhhbmRsZSBpdFxyXG4gIH1cclxufVxyXG5cclxuLyoqXHJcbiAqIFByb3h5IGRlY29kZSByZXF1ZXN0IHRocm91Z2ggYmFja2dyb3VuZCAoYnlwYXNzZXMgQ1NQKVxyXG4gKi9cclxuYXN5bmMgZnVuY3Rpb24gcHJveHlEZWNvZGVSZXF1ZXN0KGRhdGEsIGNvbnRpbnVhdGlvbklkLCBoYXNoZXMsIGFwaVVybCwgYXBpS2V5KSB7XHJcbiAgdHJ5IHtcclxuICAgIGlmICghYXBpS2V5KSB7XHJcbiAgICAgIHRocm93IG5ldyBFcnJvcignTm8gQVBJIGtleSBwcm92aWRlZCBmb3IgZGVjb2RlIHJlcXVlc3QnKTtcclxuICAgIH1cclxuICAgIFxyXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHthcGlVcmx9L2FwaS9zY2FubmVyL2RlY29kZWAsIHtcclxuICAgICAgbWV0aG9kOiAnUE9TVCcsXHJcbiAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxyXG4gICAgICAgICd4LWFjY2Vzcy10b2tlbic6IGFwaUtleVxyXG4gICAgICB9LFxyXG4gICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgY29udGludWF0aW9uSWQsXHJcbiAgICAgICAgZGF0YSxcclxuICAgICAgICBzZW5zaXRpdmVIYXNoZXM6IGhhc2hlcyxcclxuICAgICAgICBhdXRob3JpemF0aW9uOiB7XHJcbiAgICAgICAgICB0b2tlbjogYXBpS2V5LFxyXG4gICAgICAgICAgcHVycG9zZTogJ0Jyb3dzZXIgRXh0ZW5zaW9uIC0gRGVjb2RlIEFJIFJlc3BvbnNlJyxcclxuICAgICAgICAgIHR5cGU6ICdqd3QnXHJcbiAgICAgICAgfVxyXG4gICAgICB9KVxyXG4gICAgfSk7XHJcblxyXG4gICAgaWYgKCFyZXNwb25zZS5vaykge1xyXG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYERlY29kZSBBUEkgcmV0dXJuZWQgJHtyZXNwb25zZS5zdGF0dXN9YCk7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSwgZGF0YTogcmVzdWx0IH07XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoJ1tQcml2YWN5UGFsXSBEZWNvZGUgcHJveHkgZXJyb3I6JywgZXJyb3IpO1xyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBlcnJvci5tZXNzYWdlIH07XHJcbiAgfVxyXG59XHJcblxyXG4vKipcclxuICogUHJveHkgZmlsZSBlbmNvZGluZyByZXF1ZXN0IHRocm91Z2ggYmFja2dyb3VuZCAoYnlwYXNzZXMgQ1NQKVxyXG4gKiBFbmNvZGVzIHRleHQgY29udGVudCBleHRyYWN0ZWQgZnJvbSBmaWxlc1xyXG4gKi9cclxuYXN5bmMgZnVuY3Rpb24gcHJveHlFbmNvZGVGaWxlUmVxdWVzdChmaWxlRGF0YSwgZmlsZU5hbWUsIGFwaVVybCwgYXBpS2V5LCBwbGF0Zm9ybSA9IG51bGwpIHtcclxuICB0cnkge1xyXG4gICAgaWYgKCFmaWxlRGF0YSkge1xyXG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ05vIGZpbGUgZGF0YSBwcm92aWRlZCBmb3IgZW5jb2RlIHJlcXVlc3QnKTtcclxuICAgIH1cclxuICAgIFxyXG4gICAgLy8gTm8gdG9rZW4gdmFsaWRhdGlvbiAtIGp1c3QgcGFzcyB0aHJvdWdoLCBBUEkgd2lsbCBoYW5kbGUgYXV0aCBlcnJvcnNcclxuICAgIFxyXG4gICAgLy8gQWRkIHRpbWVvdXQgdG8gcHJldmVudCBoYW5naW5nIChpbmNyZWFzZWQgZm9yIHNsb3cgQVBJKVxyXG4gICAgY29uc3QgY29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcclxuICAgIGNvbnN0IHRpbWVvdXRJZCA9IHNldFRpbWVvdXQoKCkgPT4gY29udHJvbGxlci5hYm9ydCgpLCA2MDAwMCk7IC8vIDYwIHNlY29uZCB0aW1lb3V0XHJcbiAgICBcclxuICAgIHRyeSB7XHJcbiAgICAgIC8vIGZpbGVEYXRhIHNob3VsZCBiZSB0aGUgdGV4dCBjb250ZW50IGV4dHJhY3RlZCBmcm9tIHRoZSBmaWxlXHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7YXBpVXJsfS9hcGkvc2Nhbm5lci9lbmNvZGVgLCB7XHJcbiAgICAgICAgbWV0aG9kOiAnUE9TVCcsXHJcbiAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgICAgICAgIC4uLihhcGlLZXkgPyB7ICd4LWFjY2Vzcy10b2tlbic6IGFwaUtleSB9IDoge30pXHJcbiAgICAgICAgfSxcclxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgICBkYXRhOiBmaWxlRGF0YSxcclxuICAgICAgICAgIHNvdXJjZUNvbnRhaW5lcjogJ2Jyb3dzZXJfZXh0ZW5zaW9uJyxcclxuICAgICAgICAgIHNvdXJjZUVsZW1lbnQ6ICdmaWxlX3VwbG9hZCcsXHJcbiAgICAgICAgICBtZXRhZGF0YTogeyBcclxuICAgICAgICAgICAgc291cmNlOiAnZmlsZV91cGxvYWQnLCBcclxuICAgICAgICAgICAgcGxhdGZvcm06IHBsYXRmb3JtIHx8ICdicm93c2VyX2V4dGVuc2lvbicsXHJcbiAgICAgICAgICAgIGZpbGVOYW1lOiBmaWxlTmFtZSxcclxuICAgICAgICAgICAgdGltZXN0YW1wOiBEYXRlLm5vdygpIFxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pLFxyXG4gICAgICAgIHNpZ25hbDogY29udHJvbGxlci5zaWduYWxcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBjbGVhclRpbWVvdXQodGltZW91dElkKTtcclxuXHJcbiAgICAgIGlmICghcmVzcG9uc2Uub2spIHtcclxuICAgICAgICBjb25zdCBlcnJvclRleHQgPSBhd2FpdCByZXNwb25zZS50ZXh0KCk7XHJcbiAgICAgICAgY29uc29sZS5lcnJvcignW1ByaXZhY3lQYWxdIEZpbGUgZW5jb2RlIEFQSSBlcnJvcicsIHsgc3RhdHVzOiByZXNwb25zZS5zdGF0dXMsIGVycm9yOiBlcnJvclRleHQgfSk7XHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBFbmNvZGUgQVBJIHJldHVybmVkICR7cmVzcG9uc2Uuc3RhdHVzfTogJHtlcnJvclRleHR9YCk7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcclxuICAgICAgY29uc29sZS5sb2coJ1tQcml2YWN5UGFsXSBGaWxlIGVuY29kZSByZXF1ZXN0IHN1Y2Nlc3NmdWwnLCB7IFxyXG4gICAgICAgIGhhc0NvbnRpbnVhdGlvbklkOiAhIXJlc3VsdC5jb250aW51YXRpb25JZCxcclxuICAgICAgICBmaWxlTmFtZSBcclxuICAgICAgfSk7XHJcbiAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUsIGRhdGE6IHJlc3VsdCB9O1xyXG4gICAgfSBjYXRjaCAoZmV0Y2hFcnJvcikge1xyXG4gICAgICBjbGVhclRpbWVvdXQodGltZW91dElkKTtcclxuICAgICAgaWYgKGZldGNoRXJyb3IubmFtZSA9PT0gJ0Fib3J0RXJyb3InKSB7XHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdGaWxlIGVuY29kZSByZXF1ZXN0IHRpbWVkIG91dCBhZnRlciAyNSBzZWNvbmRzJyk7XHJcbiAgICAgIH1cclxuICAgICAgdGhyb3cgZmV0Y2hFcnJvcjtcclxuICAgIH1cclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcignW1ByaXZhY3lQYWxdIEZpbGUgZW5jb2RlIHByb3h5IGVycm9yOicsIGVycm9yKTtcclxuICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogZXJyb3IubWVzc2FnZSB8fCBTdHJpbmcoZXJyb3IpIH07XHJcbiAgfVxyXG59XHJcblxyXG5jb25zb2xlLmxvZygnW1ByaXZhY3lQYWxdIEJhY2tncm91bmQgc2VydmljZSB3b3JrZXIgaW5pdGlhbGl6ZWQnKTtcclxuIl0sCiAgIm1hcHBpbmdzIjogIjs7QUFXTyxNQUFNLG9CQUFvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLElBSS9CLFFBQVE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUtSLGVBQWU7QUFBQSxFQUNqQjtBQU1BLGlCQUFzQixhQUFhO0FBQ2pDLFFBQUk7QUFDRixZQUFNLFNBQVMsTUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLENBQUMsVUFBVSxlQUFlLENBQUM7QUFDekUsYUFBTztBQUFBLFFBQ0wsUUFBUSxPQUFPLFVBQVUsa0JBQWtCO0FBQUEsUUFDM0MsZUFBZSxPQUFPLGlCQUFpQixrQkFBa0I7QUFBQSxNQUMzRDtBQUFBLElBQ0YsU0FBUyxPQUFPO0FBQ2QsY0FBUSxLQUFLLG9FQUFvRSxLQUFLO0FBQ3RGLGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjs7O0FDOUJBLE1BQU0saUJBQWlCO0FBQUEsSUFDckIsU0FBUztBQUFBLElBQ1QsUUFBUSxrQkFBa0I7QUFBQSxJQUMxQixlQUFlLGtCQUFrQjtBQUFBO0FBQUEsSUFFakMsT0FBTztBQUFBLElBQ1AsbUJBQW1CO0FBQUEsRUFDckI7QUFHQSxNQUFJLFFBQVE7QUFBQSxJQUNWLHFCQUFxQjtBQUFBLElBQ3JCLG1CQUFtQjtBQUFBLElBQ25CLGVBQWU7QUFBQSxJQUNmLGtCQUFrQjtBQUFBLElBQ2xCLGNBQWMsS0FBSyxJQUFJO0FBQUEsSUFDdkIsaUJBQWlCLENBQUM7QUFBQTtBQUFBLEVBQ3BCO0FBTUEsaUJBQWUscUJBQXFCO0FBQ2xDLFFBQUk7QUFDRixZQUFNLFNBQVMsTUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLENBQUMsb0JBQW9CLENBQUM7QUFDcEUsWUFBTSxVQUFVLE9BQU87QUFFdkIsY0FBUSxJQUFJLDRDQUFxQztBQUFBLFFBQy9DLFlBQVksQ0FBQyxDQUFDO0FBQUEsUUFDZCxjQUFjLENBQUMsQ0FBQyxTQUFTO0FBQUEsUUFDekIsZ0JBQWdCLENBQUMsQ0FBQyxTQUFTLFdBQVc7QUFBQSxRQUN0QyxhQUFhLFNBQVMsV0FBVyxjQUFjLFVBQVU7QUFBQSxNQUMzRCxDQUFDO0FBRUQsVUFBSSxTQUFTLFdBQVcsY0FBYztBQUNwQyxjQUFNLFFBQVEsUUFBUSxVQUFVO0FBQ2hDLGdCQUFRLElBQUksd0NBQW1DO0FBQUEsVUFDN0MsUUFBUSxNQUFNO0FBQUEsVUFDZCxTQUFTLEdBQUcsTUFBTSxVQUFVLEdBQUcsRUFBRSxDQUFDLE1BQU0sTUFBTSxVQUFVLE1BQU0sU0FBUyxFQUFFLENBQUM7QUFBQSxRQUM1RSxDQUFDO0FBQ0QsZUFBTztBQUFBLE1BQ1Q7QUFFQSxjQUFRLEtBQUssc0RBQTRDO0FBQ3pELGFBQU87QUFBQSxJQUNULFNBQVMsT0FBTztBQUNkLGNBQVEsTUFBTSxnREFBMkMsS0FBSztBQUM5RCxhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFLQSxTQUFPLFFBQVEsWUFBWSxZQUFZLE9BQU8sWUFBWTtBQUN4RCxZQUFRLElBQUkscUNBQXFDLFFBQVEsTUFBTTtBQUcvRCxVQUFNLFNBQVMsTUFBTSxXQUFXO0FBR2hDLFVBQU0sZ0JBQWdCO0FBQUEsTUFDcEIsR0FBRztBQUFBLE1BQ0gsUUFBUSxPQUFPO0FBQUEsTUFDZixlQUFlLE9BQU87QUFBQSxJQUN4QjtBQUdBLFVBQU0sV0FBVyxNQUFNLE9BQU8sUUFBUSxNQUFNLElBQUksQ0FBQyxVQUFVLGlCQUFpQixXQUFXLFNBQVMsbUJBQW1CLENBQUM7QUFDcEgsVUFBTSxlQUFlO0FBQUEsTUFDbkIsR0FBRztBQUFBLE1BQ0gsUUFBUSxTQUFTLFVBQVUsT0FBTztBQUFBLE1BQ2xDLGVBQWUsU0FBUyxpQkFBaUIsT0FBTztBQUFBLE1BQ2hELFNBQVMsU0FBUyxZQUFZLFNBQVksU0FBUyxVQUFVLGVBQWU7QUFBQSxNQUM1RSxPQUFPLFNBQVMsVUFBVSxTQUFZLFNBQVMsUUFBUSxlQUFlO0FBQUEsTUFDdEUsbUJBQW1CLFNBQVMsc0JBQXNCLFNBQVksU0FBUyxvQkFBb0IsZUFBZTtBQUFBLElBQzVHO0FBQ0EsVUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLFlBQVk7QUFDM0MsVUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLEVBQUUsTUFBTSxDQUFDO0FBRXhDLFlBQVEsSUFBSSx3Q0FBd0M7QUFHcEQsUUFBSSxRQUFRLFdBQVcsV0FBVztBQUNoQyxZQUFNLGNBQWMsTUFBTSxXQUFXO0FBQ3JDLGFBQU8sS0FBSyxPQUFPO0FBQUEsUUFDakIsS0FBSyxZQUFZO0FBQUEsTUFDbkIsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGLENBQUM7QUFNRCxTQUFPLFFBQVEsVUFBVSxZQUFZLENBQUMsU0FBUztBQUM3QyxZQUFRLElBQUksdUNBQXVDO0FBQ25ELFNBQUssYUFBYSxZQUFZLE1BQU07QUFDbEMsY0FBUSxJQUFJLDBDQUEwQztBQUFBLElBQ3hELENBQUM7QUFBQSxFQUNILENBQUM7QUFPRCxNQUFJO0FBQ0YsUUFBSSxVQUFVLE9BQU8sUUFBUTtBQUUzQixhQUFPLE9BQU8sT0FBTyx3QkFBd0I7QUFBQSxRQUMzQyxnQkFBZ0I7QUFBQTtBQUFBLFFBQ2hCLGlCQUFpQjtBQUFBO0FBQUEsTUFDbkIsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxRQUFRO0FBQ2hCLGdCQUFRLEtBQUssbURBQW1ELEdBQUc7QUFBQSxNQUNyRSxDQUFDO0FBR0QsYUFBTyxPQUFPLFFBQVEsWUFBWSxDQUFDLFVBQVU7QUFDM0MsWUFBSSxTQUFTLE1BQU0sU0FBUyx3QkFBd0I7QUFFbEQsY0FBSTtBQUNGLG1CQUFPLFFBQVEsTUFBTSxJQUFJLENBQUMsV0FBVyxHQUFHLE1BQU07QUFDNUMsa0JBQUksT0FBTyxRQUFRLFdBQVc7QUFDNUIsd0JBQVEsSUFBSSxpQ0FBaUMsT0FBTyxRQUFRLFVBQVUsT0FBTztBQUFBLGNBQy9FO0FBQUEsWUFDRixDQUFDO0FBQUEsVUFDSCxTQUFTLEtBQUs7QUFBQSxVQUVkO0FBQUEsUUFDRjtBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGLFNBQVMsT0FBTztBQUVkLFlBQVEsS0FBSyx3REFBd0QsTUFBTSxPQUFPO0FBQUEsRUFDcEY7QUFLQSxTQUFPLFFBQVEsVUFBVSxZQUFZLENBQUMsU0FBUyxRQUFRLGlCQUFpQjtBQUN0RSxZQUFRLElBQUksa0NBQWtDLFFBQVEsVUFBVSxRQUFRLE1BQU07QUFBQSxNQUM1RSxNQUFNLFFBQVEsS0FBSyxPQUFPLFFBQVEsT0FBTztBQUFBLE1BQ3pDLFNBQVMsQ0FBQyxDQUFDLFFBQVE7QUFBQSxNQUNuQixXQUFXLENBQUMsQ0FBQyxRQUFRO0FBQUEsSUFDdkIsQ0FBQztBQUdELFdBQU8sUUFBUSxNQUFNLElBQUksQ0FBQyxXQUFXLEdBQUcsTUFBTTtBQUFBLElBRTlDLENBQUM7QUFHQyxRQUFJLFFBQVEsU0FBUyxrQkFBa0I7QUFDckMsY0FBUSxJQUFJLDJDQUEyQyxFQUFFLE9BQU8sUUFBUSxPQUFPLFNBQVMsUUFBUSxRQUFRLENBQUM7QUFDekcsbUJBQWEsRUFBRSxTQUFTLE1BQU0sVUFBVSxLQUFLLENBQUM7QUFDOUMsYUFBTztBQUFBLElBQ1Q7QUFFQSxZQUFRLFFBQVEsUUFBUTtBQUFBLE1BQ3RCLEtBQUs7QUFFSCxxQkFBYSxFQUFFLFNBQVMsTUFBTSxNQUFNLEtBQUssQ0FBQztBQUMxQyxlQUFPO0FBQUEsTUFFVCxLQUFLO0FBQ0gsK0JBQXVCLFNBQVMsTUFBTTtBQUN0QyxxQkFBYSxFQUFFLFNBQVMsS0FBSyxDQUFDO0FBQzlCO0FBQUEsTUFFRixLQUFLO0FBQ0gsaUNBQXlCLFNBQVMsTUFBTTtBQUN4QyxxQkFBYSxFQUFFLFNBQVMsS0FBSyxDQUFDO0FBQzlCO0FBQUEsTUFFRixLQUFLO0FBR0gsU0FBQyxZQUFZO0FBQ1gsY0FBSSxlQUFlO0FBQ25CLGdCQUFNLG1CQUFtQixDQUFDLGFBQWE7QUFDckMsZ0JBQUksQ0FBQyxjQUFjO0FBQ2pCLGtCQUFJO0FBQ0YsNkJBQWEsUUFBUTtBQUNyQiwrQkFBZTtBQUNmLHdCQUFRLElBQUksMkRBQXNEO0FBQUEsY0FDcEUsU0FBUyxLQUFLO0FBQ1osd0JBQVEsTUFBTSxpRUFBNEQsR0FBRztBQUM3RSwrQkFBZTtBQUFBLGNBQ2pCO0FBQUEsWUFDRjtBQUFBLFVBQ0Y7QUFFQSxjQUFJO0FBRUYsZ0JBQUksU0FBUyxRQUFRO0FBRXJCLGdCQUFJLENBQUMsUUFBUTtBQUVYLHVCQUFTLE1BQU0sbUJBQW1CO0FBQUEsWUFDcEM7QUFHQSxnQkFBSSxZQUFZO0FBQ2hCLGdCQUFJLFFBQVE7QUFDVixrQkFBSTtBQUNGLHNCQUFNLFFBQVEsT0FBTyxNQUFNLEdBQUc7QUFDOUIsb0JBQUksTUFBTSxXQUFXLEdBQUc7QUFFdEIsd0JBQU0sVUFBVSxLQUFLLE1BQU0sS0FBSyxNQUFNLENBQUMsRUFBRSxRQUFRLE1BQU0sR0FBRyxFQUFFLFFBQVEsTUFBTSxHQUFHLENBQUMsQ0FBQztBQUMvRSw4QkFBWTtBQUFBLG9CQUNWLGVBQWU7QUFBQSxvQkFDZixTQUFTO0FBQUEsc0JBQ1AsU0FBUyxRQUFRO0FBQUEsc0JBQ2pCLE9BQU8sUUFBUTtBQUFBLHNCQUNmLEtBQUssUUFBUTtBQUFBLHNCQUNiLEtBQUssUUFBUTtBQUFBLHNCQUNiLFdBQVcsUUFBUSxNQUFNLElBQUksS0FBSyxRQUFRLE1BQU0sR0FBSSxFQUFFLFlBQVksSUFBSTtBQUFBLHNCQUN0RSxXQUFXLFFBQVEsTUFBTSxRQUFRLE1BQU8sS0FBSyxJQUFJLElBQUksTUFBUTtBQUFBLG9CQUMvRDtBQUFBLGtCQUNGO0FBQUEsZ0JBQ0YsT0FBTztBQUNMLDhCQUFZLEVBQUUsZUFBZSxPQUFPLFFBQVEsb0NBQW9DO0FBQUEsZ0JBQ2xGO0FBQUEsY0FDRixTQUFTLEdBQUc7QUFDViw0QkFBWSxFQUFFLGVBQWUsT0FBTyxRQUFRLGlCQUFpQixFQUFFLE9BQU8sR0FBRztBQUFBLGNBQzNFO0FBQUEsWUFDRjtBQUdBLG9CQUFRLElBQUksd0NBQWlDO0FBQUEsY0FDM0MsVUFBVSxDQUFDLENBQUM7QUFBQSxjQUNaLGFBQWEsUUFBUSxVQUFVO0FBQUEsY0FDL0IsY0FBYyxTQUFTLEdBQUcsT0FBTyxVQUFVLEdBQUcsRUFBRSxDQUFDLE1BQU0sT0FBTyxVQUFVLE9BQU8sU0FBUyxFQUFFLENBQUMsS0FBSztBQUFBLGNBQ2hHLFFBQVEsUUFBUSxVQUFVLGtCQUFrQjtBQUFBLGNBQzVDLFFBQVEsUUFBUSxTQUFTLDRCQUE0QjtBQUFBLGNBQ3JELG1CQUFtQixRQUFRLFFBQVEsVUFBVTtBQUFBLGNBQzdDO0FBQUEsWUFDRixDQUFDO0FBR0QsZ0JBQUksUUFBUSxXQUFXLENBQUMsVUFBVSxPQUFPLFdBQVcsSUFBSTtBQUN0RCxzQkFBUSxNQUFNLG1GQUF5RTtBQUFBLFlBQ3pGO0FBR0EsZ0JBQUksVUFBVSxhQUFhLENBQUMsVUFBVSxlQUFlO0FBQ25ELHNCQUFRLE1BQU0sK0VBQXFFLFNBQVM7QUFBQSxZQUM5RjtBQUVBLGdCQUFJLENBQUMsUUFBUTtBQUNYLHNCQUFRLE1BQU0sNERBQXVEO0FBQ3JFLCtCQUFpQjtBQUFBLGdCQUNmLFNBQVM7QUFBQSxnQkFDVCxPQUFPO0FBQUEsY0FDVCxDQUFDO0FBQ0Q7QUFBQSxZQUNGO0FBR0Esa0JBQU0sZ0JBQWdCLG1CQUFtQixRQUFRLE1BQU0sUUFBUSxVQUFVLGtCQUFrQixRQUFRLFFBQVEsUUFBUSxRQUFRO0FBQzNILGtCQUFNLGlCQUFpQixJQUFJLFFBQVEsQ0FBQyxHQUFHLFdBQVc7QUFDaEQseUJBQVcsTUFBTTtBQUNmLHVCQUFPLElBQUksTUFBTSwyQ0FBMkMsQ0FBQztBQUFBLGNBQy9ELEdBQUcsR0FBSztBQUFBLFlBQ1YsQ0FBQztBQUVELG9CQUFRLElBQUksd0RBQW1EO0FBQy9ELGtCQUFNLFNBQVMsTUFBTSxRQUFRLEtBQUssQ0FBQyxlQUFlLGNBQWMsQ0FBQztBQUVqRSxvQkFBUSxJQUFJLGdFQUEyRDtBQUFBLGNBQ3JFLFNBQVMsT0FBTztBQUFBLGNBQ2hCLG1CQUFtQixDQUFDLENBQUMsT0FBTyxNQUFNO0FBQUEsWUFDcEMsQ0FBQztBQUNELDZCQUFpQixNQUFNO0FBQUEsVUFDekIsU0FBUyxPQUFPO0FBQ2Qsb0JBQVEsTUFBTSxxQ0FBZ0MsS0FBSztBQUNuRCxrQkFBTSxlQUFlLE1BQU0sV0FBVyxPQUFPLEtBQUs7QUFDbEQsNkJBQWlCO0FBQUEsY0FDZixTQUFTO0FBQUEsY0FDVCxPQUFPO0FBQUEsY0FDUCxTQUFTLGFBQWEsU0FBUyxTQUFTO0FBQUEsWUFDMUMsQ0FBQztBQUFBLFVBQ0g7QUFBQSxRQUNGLEdBQUc7QUFDSCxlQUFPO0FBQUEsTUFFVCxLQUFLO0FBRUgsU0FBQyxZQUFZO0FBQ1gsY0FBSSxlQUFlO0FBQ25CLGdCQUFNLG1CQUFtQixDQUFDLGFBQWE7QUFDckMsZ0JBQUksQ0FBQyxjQUFjO0FBQ2pCLGtCQUFJO0FBQ0YsNkJBQWEsUUFBUTtBQUNyQiwrQkFBZTtBQUFBLGNBQ2pCLFNBQVMsS0FBSztBQUNaLHdCQUFRLE1BQU0sb0RBQW9ELEdBQUc7QUFDckUsK0JBQWU7QUFBQSxjQUNqQjtBQUFBLFlBQ0Y7QUFBQSxVQUNGO0FBRUEsY0FBSTtBQUVGLGdCQUFJLFNBQVMsUUFBUSxVQUFVLE1BQU0sbUJBQW1CO0FBQ3hELGdCQUFJLENBQUMsUUFBUTtBQUNYLCtCQUFpQjtBQUFBLGdCQUNmLFNBQVM7QUFBQSxnQkFDVCxPQUFPO0FBQUEsY0FDVCxDQUFDO0FBQ0Q7QUFBQSxZQUNGO0FBQ0Esa0JBQU0sU0FBUyxNQUFNLG1CQUFtQixRQUFRLE1BQU0sUUFBUSxnQkFBZ0IsUUFBUSxRQUFRLFFBQVEsVUFBVSxrQkFBa0IsUUFBUSxNQUFNO0FBQ2hKLDZCQUFpQixNQUFNO0FBQUEsVUFDekIsU0FBUyxPQUFPO0FBQ2Qsb0JBQVEsTUFBTSxrQ0FBa0MsS0FBSztBQUNyRCw2QkFBaUIsRUFBRSxTQUFTLE9BQU8sT0FBTyxNQUFNLFdBQVcsT0FBTyxLQUFLLEVBQUUsQ0FBQztBQUFBLFVBQzVFO0FBQUEsUUFDRixHQUFHO0FBQ0gsZUFBTztBQUFBLE1BRVQsS0FBSztBQUVILFNBQUMsWUFBWTtBQUNYLGNBQUksZUFBZTtBQUNuQixnQkFBTSxtQkFBbUIsQ0FBQyxhQUFhO0FBQ3JDLGdCQUFJLENBQUMsY0FBYztBQUNqQixrQkFBSTtBQUNGLDZCQUFhLFFBQVE7QUFDckIsK0JBQWU7QUFBQSxjQUNqQixTQUFTLEtBQUs7QUFDWix3QkFBUSxNQUFNLG9EQUFvRCxHQUFHO0FBQ3JFLCtCQUFlO0FBQUEsY0FDakI7QUFBQSxZQUNGO0FBQUEsVUFDRjtBQUVBLGNBQUk7QUFFRixnQkFBSSxTQUFTLFFBQVEsVUFBVSxNQUFNLG1CQUFtQjtBQUN4RCxnQkFBSSxDQUFDLFFBQVE7QUFDWCwrQkFBaUI7QUFBQSxnQkFDZixTQUFTO0FBQUEsZ0JBQ1QsT0FBTztBQUFBLGNBQ1QsQ0FBQztBQUNEO0FBQUEsWUFDRjtBQUNBLG9CQUFRLElBQUksaURBQWlEO0FBQUEsY0FDM0QsVUFBVSxRQUFRO0FBQUEsY0FDbEIsWUFBWSxRQUFRLFVBQVU7QUFBQSxjQUM5QixXQUFXLENBQUMsQ0FBQztBQUFBLGNBQ2IsVUFBVSxRQUFRO0FBQUEsWUFDcEIsQ0FBQztBQUdELGtCQUFNLGdCQUFnQix1QkFBdUIsUUFBUSxVQUFVLFFBQVEsVUFBVSxRQUFRLFVBQVUsa0JBQWtCLFFBQVEsUUFBUSxRQUFRLFFBQVE7QUFDckosa0JBQU0saUJBQWlCLElBQUksUUFBUSxDQUFDLEdBQUcsV0FBVztBQUNoRCx5QkFBVyxNQUFNO0FBQ2YsdUJBQU8sSUFBSSxNQUFNLGdEQUFnRCxDQUFDO0FBQUEsY0FDcEUsR0FBRyxHQUFLO0FBQUEsWUFDVixDQUFDO0FBRUQsa0JBQU0sU0FBUyxNQUFNLFFBQVEsS0FBSyxDQUFDLGVBQWUsY0FBYyxDQUFDO0FBRWpFLG9CQUFRLElBQUksMkNBQTJDO0FBQUEsY0FDckQsU0FBUyxPQUFPO0FBQUEsY0FDaEIsbUJBQW1CLENBQUMsQ0FBQyxPQUFPLE1BQU07QUFBQSxZQUNwQyxDQUFDO0FBQ0QsNkJBQWlCLE1BQU07QUFBQSxVQUN6QixTQUFTLE9BQU87QUFDZCxvQkFBUSxNQUFNLGtDQUFrQyxLQUFLO0FBQ3JELGtCQUFNLGVBQWUsTUFBTSxXQUFXLE9BQU8sS0FBSztBQUNsRCw2QkFBaUI7QUFBQSxjQUNmLFNBQVM7QUFBQSxjQUNULE9BQU87QUFBQSxjQUNQLFNBQVMsYUFBYSxTQUFTLFNBQVM7QUFBQSxZQUMxQyxDQUFDO0FBQUEsVUFDSDtBQUFBLFFBQ0YsR0FBRztBQUNILGVBQU87QUFBQSxNQUVULEtBQUs7QUFDSCxlQUFPLFFBQVEsTUFBTSxJQUFJLENBQUMsVUFBVSxpQkFBaUIsV0FBVyxTQUFTLG1CQUFtQixHQUFHLENBQUMsV0FBVztBQUN6RyxjQUFJO0FBRUYsZ0JBQUksU0FBUyxPQUFPLFVBQVUsZUFBZTtBQUM3QyxnQkFBSSxnQkFBZ0IsT0FBTyxpQkFBaUIsZUFBZTtBQUUzRCxnQkFBSSxPQUFPLFNBQVMsaUJBQWlCLEtBQUssT0FBTyxTQUFTLGlCQUFpQixHQUFHO0FBQzVFLHVCQUFTLGVBQWU7QUFFeEIscUJBQU8sUUFBUSxNQUFNLElBQUksRUFBRSxPQUFPLENBQUM7QUFBQSxZQUNyQztBQUVBLGdCQUFJLGNBQWMsU0FBUyxnQkFBZ0IsS0FBSyxjQUFjLFNBQVMsZ0JBQWdCLEdBQUc7QUFDeEYsOEJBQWdCLGVBQWU7QUFFL0IscUJBQU8sUUFBUSxNQUFNLElBQUksRUFBRSxjQUFjLENBQUM7QUFBQSxZQUM1QztBQUVBLGtCQUFNLFNBQVM7QUFBQSxjQUNiLEdBQUc7QUFBQSxjQUNILEdBQUc7QUFBQSxjQUNIO0FBQUEsY0FDQTtBQUFBLFlBQ0Y7QUFDQSx5QkFBYSxFQUFFLE9BQU8sQ0FBQztBQUFBLFVBQ3pCLFNBQVMsS0FBSztBQUNaLG9CQUFRLE1BQU0sbURBQW1ELEdBQUc7QUFDcEUseUJBQWEsRUFBRSxRQUFRLGVBQWUsQ0FBQztBQUFBLFVBQ3pDO0FBQUEsUUFDRixDQUFDO0FBQ0QsZUFBTztBQUFBLE1BRVQsS0FBSztBQUNILGVBQU8sUUFBUSxNQUFNLElBQUksQ0FBQyxvQkFBb0IsR0FBRyxDQUFDLFdBQVc7QUFDM0QsY0FBSTtBQUNGLHlCQUFhLEVBQUUsb0JBQW9CLE9BQU8sc0JBQXNCLEtBQUssQ0FBQztBQUFBLFVBQ3hFLFNBQVMsS0FBSztBQUNaLG9CQUFRLE1BQU0sb0RBQW9ELEdBQUc7QUFBQSxVQUN2RTtBQUFBLFFBQ0YsQ0FBQztBQUNELGVBQU87QUFBQSxNQUVULEtBQUs7QUFDSCxlQUFPLFFBQVEsTUFBTSxJQUFJLFFBQVEsUUFBUSxNQUFNO0FBQzdDLHVCQUFhLEVBQUUsU0FBUyxLQUFLLENBQUM7QUFDOUIsZ0NBQXNCLFFBQVEsTUFBTTtBQUFBLFFBQ3RDLENBQUM7QUFDRCxlQUFPO0FBQUEsTUFFVCxLQUFLO0FBQ0gsZUFBTyxRQUFRLE1BQU0sSUFBSSxDQUFDLE9BQU8sR0FBRyxDQUFDLFdBQVc7QUFDOUMsZ0JBQU0sZUFBZSxPQUFPLFNBQVM7QUFDckMsa0JBQVEsSUFBSSxtQ0FBbUMsWUFBWTtBQUMzRCx1QkFBYSxFQUFFLE9BQU8sYUFBYSxDQUFDO0FBQUEsUUFDdEMsQ0FBQztBQUNELGVBQU87QUFBQSxNQUVULEtBQUs7QUFDSCxnQkFBUTtBQUFBLFVBQ04scUJBQXFCO0FBQUEsVUFDckIsbUJBQW1CO0FBQUEsVUFDbkIsZUFBZTtBQUFBLFVBQ2Ysa0JBQWtCO0FBQUEsVUFDbEIsY0FBYyxLQUFLLElBQUk7QUFBQSxVQUN2QixpQkFBaUIsQ0FBQztBQUFBLFFBQ3BCO0FBQ0EsZUFBTyxRQUFRLE1BQU0sSUFBSSxFQUFFLE1BQU0sR0FBRyxNQUFNO0FBQ3hDLHVCQUFhLEVBQUUsU0FBUyxNQUFNLE1BQU0sQ0FBQztBQUFBLFFBQ3ZDLENBQUM7QUFDRCxlQUFPO0FBQUEsTUFFVCxLQUFLO0FBRUgsNkJBQXFCLFFBQVEsZ0JBQWdCLFFBQVEsYUFBYTtBQUNsRSxxQkFBYSxFQUFFLFNBQVMsS0FBSyxDQUFDO0FBQzlCLGVBQU87QUFBQSxNQUVULEtBQUs7QUFDSCxTQUFDLFlBQVk7QUFDWCxjQUFJO0FBRUYsa0JBQU0sU0FBUyxNQUFNLG1CQUFtQjtBQUN4QyxnQkFBSSxDQUFDLFFBQVE7QUFDWCwyQkFBYSxFQUFFLFNBQVMsT0FBTyxPQUFPLHdEQUF3RCxDQUFDO0FBQy9GO0FBQUEsWUFDRjtBQUNBLGtCQUFNLFNBQVMsTUFBTSxlQUFlLFFBQVEsVUFBVSxrQkFBa0IsUUFBUSxNQUFNO0FBQ3RGLHlCQUFhLE1BQU07QUFBQSxVQUNyQixTQUFTLE9BQU87QUFDZCx5QkFBYSxFQUFFLFNBQVMsT0FBTyxPQUFPLE1BQU0sUUFBUSxDQUFDO0FBQUEsVUFDdkQ7QUFBQSxRQUNGLEdBQUc7QUFDSCxlQUFPO0FBQUEsTUFFVDtBQUNFLHFCQUFhLEVBQUUsT0FBTyxpQkFBaUIsQ0FBQztBQUFBLElBQzVDO0FBQUEsRUFDRixDQUFDO0FBS0gsV0FBUyx1QkFBdUIsTUFBTSxRQUFRO0FBQzVDLFlBQVEsSUFBSSxzQ0FBc0MsS0FBSyxHQUFHO0FBRzFELFFBQUksT0FBTyxLQUFLLElBQUk7QUFDbEIsYUFBTyxPQUFPLGFBQWE7QUFBQSxRQUN6QixNQUFNO0FBQUEsUUFDTixPQUFPLE9BQU8sSUFBSTtBQUFBLE1BQ3BCLENBQUM7QUFFRCxhQUFPLE9BQU8sd0JBQXdCO0FBQUEsUUFDcEMsT0FBTztBQUFBLFFBQ1AsT0FBTyxPQUFPLElBQUk7QUFBQSxNQUNwQixDQUFDO0FBQUEsSUFDSDtBQUFBLEVBQ0Y7QUFLQSxXQUFTLHlCQUF5QixNQUFNLFFBQVE7QUFFOUMsUUFBSSxLQUFLLGdCQUFnQjtBQUN2QixZQUFNLGdCQUFnQixLQUFLLE9BQU8saUJBQWlCO0FBQ25ELDJCQUFxQixLQUFLLGdCQUFnQixhQUFhO0FBQUEsSUFDekQsT0FBTztBQUVMLFlBQU0sc0JBQXVCLEtBQUssT0FBTyx1QkFBdUI7QUFDaEUsWUFBTSxvQkFBcUIsS0FBSyxPQUFPLHFCQUFxQjtBQUM1RCxZQUFNLGlCQUFpQixNQUFNLGlCQUFpQixNQUFNLEtBQUssT0FBTyxpQkFBaUI7QUFDakYsWUFBTSxvQkFBbUIsb0JBQUksS0FBSyxHQUFFLFlBQVk7QUFDaEQsYUFBTyxRQUFRLE1BQU0sSUFBSSxFQUFFLE1BQU0sQ0FBQztBQUFBLElBQ3BDO0FBRUEsWUFBUSxJQUFJLHFDQUFxQztBQUFBLE1BQy9DLFVBQVUsS0FBSztBQUFBLE1BQ2YsZ0JBQWdCLEtBQUs7QUFBQSxNQUNyQixlQUFlLEtBQUssT0FBTyxpQkFBaUI7QUFBQSxJQUM5QyxDQUFDO0FBR0QsV0FBTyxRQUFRLE1BQU0sSUFBSSxDQUFDLG1CQUFtQixHQUFHLENBQUMsV0FBVztBQUMxRCxVQUFJLE9BQU8sbUJBQW1CO0FBQzVCLHFDQUE2QixLQUFLLFVBQVUsT0FBTyxLQUFLLEVBQUU7QUFBQSxNQUM1RDtBQUFBLElBQ0YsQ0FBQztBQUFBLEVBQ0g7QUFLQSxXQUFTLHFCQUFxQixnQkFBZ0IsZ0JBQWdCLEdBQUc7QUFDL0QsUUFBSSxDQUFDO0FBQWdCO0FBR3JCLFdBQU8sUUFBUSxNQUFNLElBQUksQ0FBQyxPQUFPLEdBQUcsQ0FBQyxXQUFXO0FBQzlDLFlBQU0sZUFBZSxPQUFPLFNBQVMsRUFBRSxHQUFHLE1BQU07QUFHaEQsVUFBSSxDQUFDLGFBQWEsaUJBQWlCO0FBQ2pDLHFCQUFhLGtCQUFrQixDQUFDO0FBQUEsTUFDbEM7QUFHQSxVQUFJLENBQUMsYUFBYSxnQkFBZ0IsU0FBUyxjQUFjLEdBQUc7QUFDMUQscUJBQWEsZ0JBQWdCLEtBQUssY0FBYztBQUNoRCxxQkFBYSxzQkFBc0IsYUFBYSxnQkFBZ0I7QUFDaEUscUJBQWEsb0JBQW1CLG9CQUFJLEtBQUssR0FBRSxZQUFZO0FBQUEsTUFDekQ7QUFHQSxtQkFBYSxpQkFBaUIsYUFBYSxpQkFBaUIsTUFBTSxpQkFBaUI7QUFHbkYsY0FBUTtBQUNSLGFBQU8sUUFBUSxNQUFNLElBQUksRUFBRSxNQUFNLENBQUM7QUFFbEMsY0FBUSxJQUFJLCtCQUErQjtBQUFBLFFBQ3pDLGlCQUFpQixhQUFhLGdCQUFnQjtBQUFBLFFBQzlDLGVBQWUsYUFBYTtBQUFBLE1BQzlCLENBQUM7QUFBQSxJQUNILENBQUM7QUFBQSxFQUNIO0FBS0EsV0FBUyw2QkFBNkIsVUFBVSxPQUFPO0FBQ3JELFFBQUksQ0FBQztBQUFPO0FBR1osV0FBTyxPQUFPLGFBQWE7QUFBQSxNQUN6QixNQUFNO0FBQUEsTUFDTjtBQUFBLElBQ0YsQ0FBQztBQUVELFdBQU8sT0FBTyx3QkFBd0I7QUFBQSxNQUNwQyxPQUFPO0FBQUEsTUFDUDtBQUFBLElBQ0YsQ0FBQztBQUdELGVBQVcsTUFBTTtBQUNmLGFBQU8sT0FBTyxhQUFhO0FBQUEsUUFDekIsTUFBTTtBQUFBLFFBQ047QUFBQSxNQUNGLENBQUM7QUFFRCxhQUFPLE9BQU8sd0JBQXdCO0FBQUEsUUFDcEMsT0FBTztBQUFBLFFBQ1A7QUFBQSxNQUNGLENBQUM7QUFBQSxJQUNILEdBQUcsR0FBSTtBQUFBLEVBQ1Q7QUFLQSxXQUFTLHNCQUFzQixRQUFRO0FBQ3JDLFdBQU8sS0FBSyxNQUFNLENBQUMsR0FBRyxDQUFDLFNBQVM7QUFDOUIsV0FBSyxRQUFRLENBQUMsUUFBUTtBQUNwQixlQUFPLEtBQUssWUFBWSxJQUFJLElBQUk7QUFBQSxVQUM5QixRQUFRO0FBQUEsVUFDUjtBQUFBLFFBQ0YsQ0FBQyxFQUFFLE1BQU0sTUFBTTtBQUFBLFFBRWYsQ0FBQztBQUFBLE1BQ0gsQ0FBQztBQUFBLElBQ0gsQ0FBQztBQUFBLEVBQ0g7QUFLQSxpQkFBZSxlQUFlLFFBQVEsUUFBUTtBQUM1QyxRQUFJO0FBQ0YsWUFBTSxXQUFXLE1BQU0sTUFBTSxHQUFHLE1BQU0sV0FBVztBQUFBLFFBQy9DLFFBQVE7QUFBQSxRQUNSLFNBQVM7QUFBQSxVQUNQLGtCQUFrQjtBQUFBLFVBQ2xCLGdCQUFnQjtBQUFBLFFBQ2xCO0FBQUEsTUFDRixDQUFDO0FBRUQsVUFBSSxTQUFTLElBQUk7QUFDZixlQUFPLEVBQUUsU0FBUyxNQUFNLFNBQVMsOEJBQThCO0FBQUEsTUFDakUsT0FBTztBQUNMLGVBQU87QUFBQSxVQUNMLFNBQVM7QUFBQSxVQUNULE9BQU8sdUJBQXVCLFNBQVMsTUFBTTtBQUFBLFFBQy9DO0FBQUEsTUFDRjtBQUFBLElBQ0YsU0FBUyxPQUFPO0FBQ2QsYUFBTztBQUFBLFFBQ0wsU0FBUztBQUFBLFFBQ1QsT0FBTyxzQkFBc0IsTUFBTSxPQUFPO0FBQUEsTUFDNUM7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUtBLFNBQU8sS0FBSyxVQUFVLFlBQVksQ0FBQyxPQUFPLFlBQVksUUFBUTtBQUM1RCxRQUFJLFdBQVcsV0FBVyxjQUFjLElBQUksS0FBSztBQUMvQyxZQUFNLFlBQVksSUFBSSxJQUFJLFNBQVMsYUFBYTtBQUNoRCxZQUFNLFdBQVcsSUFBSSxJQUFJLFNBQVMsV0FBVztBQUU3QyxVQUFJLGFBQWEsVUFBVTtBQUN6QixnQkFBUSxJQUFJLHlDQUF5QyxJQUFJLEdBQUc7QUFHNUQsZUFBTyxPQUFPLGFBQWE7QUFBQSxVQUN6QixNQUFNO0FBQUEsVUFDTjtBQUFBLFFBQ0YsQ0FBQztBQUVELGVBQU8sT0FBTyx3QkFBd0I7QUFBQSxVQUNwQyxPQUFPO0FBQUEsVUFDUDtBQUFBLFFBQ0YsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGO0FBQUEsRUFDRixDQUFDO0FBS0QsU0FBTyxRQUFRLFVBQVUsWUFBWSxZQUFZO0FBQy9DLFlBQVEsSUFBSSxnQ0FBZ0M7QUFHNUMsVUFBTSxTQUFTLE1BQU0sT0FBTyxRQUFRLE1BQU0sSUFBSSxDQUFDLE9BQU8sQ0FBQztBQUN2RCxRQUFJLE9BQU8sT0FBTztBQUNoQixjQUFRLE9BQU87QUFBQSxJQUNqQjtBQUFBLEVBQ0YsQ0FBQztBQUtELFNBQU8sUUFBUSxZQUFZLFlBQVksTUFBTTtBQUMzQyxXQUFPLGFBQWEsT0FBTztBQUFBLE1BQ3pCLElBQUk7QUFBQSxNQUNKLE9BQU87QUFBQSxNQUNQLFVBQVUsQ0FBQyxNQUFNO0FBQUEsSUFDbkIsQ0FBQztBQUVELFdBQU8sYUFBYSxPQUFPO0FBQUEsTUFDekIsSUFBSTtBQUFBLE1BQ0osT0FBTztBQUFBLE1BQ1AsVUFBVSxDQUFDLE1BQU07QUFBQSxJQUNuQixDQUFDO0FBQUEsRUFDSCxDQUFDO0FBS0QsU0FBTyxhQUFhLFVBQVUsWUFBWSxDQUFDLE1BQU0sUUFBUTtBQUN2RCxZQUFRLEtBQUssWUFBWTtBQUFBLE1BQ3ZCLEtBQUs7QUFDSCx5QkFBaUI7QUFDakI7QUFBQSxNQUVGLEtBQUs7QUFDSCw4QkFBc0I7QUFDdEI7QUFBQSxJQUNKO0FBQUEsRUFDRixDQUFDO0FBS0QsaUJBQWUsbUJBQW1CO0FBQ2hDLFVBQU0sU0FBUyxNQUFNLE9BQU8sUUFBUSxNQUFNLElBQUksQ0FBQyxTQUFTLENBQUM7QUFDekQsVUFBTSxXQUFXLENBQUMsT0FBTztBQUV6QixVQUFNLE9BQU8sUUFBUSxNQUFNLElBQUksRUFBRSxTQUFTLFNBQVMsQ0FBQztBQUVwRCxVQUFNLFVBQVUsV0FBVyw4QkFBeUI7QUFFcEQsWUFBUSxJQUFJLGdCQUFnQixPQUFPO0FBR25DLDBCQUFzQixFQUFFLFNBQVMsU0FBUyxDQUFDO0FBQUEsRUFDN0M7QUFLQSxpQkFBZSx3QkFBd0I7QUFDckMsVUFBTSxTQUFTLE1BQU0sT0FBTyxRQUFRLE1BQU0sSUFBSSxDQUFDLE9BQU8sQ0FBQztBQUN2RCxVQUFNLGVBQWUsT0FBTyxTQUFTO0FBRXJDLFlBQVEsSUFBSSw0QkFBNEIsWUFBWTtBQUFBLEVBQ3REO0FBS0EsaUJBQWUsbUJBQW1CLE1BQU0sUUFBUSxRQUFRLFdBQVcsTUFBTTtBQUN2RSxRQUFJO0FBQ0YsY0FBUSxJQUFJLHdDQUF3QztBQUFBLFFBQ2xELFlBQVksTUFBTTtBQUFBLFFBQ2xCO0FBQUEsUUFDQSxXQUFXLENBQUMsQ0FBQztBQUFBLFFBQ2IsZUFBZSxTQUFTLEdBQUcsT0FBTyxVQUFVLEdBQUcsRUFBRSxDQUFDLFFBQVE7QUFBQSxRQUMxRDtBQUFBLE1BQ0YsQ0FBQztBQUVELFVBQUksQ0FBQyxNQUFNO0FBQ1QsY0FBTSxJQUFJLE1BQU0scUNBQXFDO0FBQUEsTUFDdkQ7QUFLQSxZQUFNLGFBQWEsSUFBSSxnQkFBZ0I7QUFDdkMsWUFBTSxZQUFZLFdBQVcsTUFBTSxXQUFXLE1BQU0sR0FBRyxHQUFLO0FBRTVELFVBQUk7QUFDRixjQUFNLFVBQVU7QUFBQSxVQUNkLGdCQUFnQjtBQUFBLFFBQ2xCO0FBRUEsWUFBSSxRQUFRO0FBQ1Ysa0JBQVEsZ0JBQWdCLElBQUk7QUFHNUIsY0FBSSxlQUFlO0FBQ25CLGNBQUk7QUFDRixrQkFBTSxRQUFRLE9BQU8sTUFBTSxHQUFHO0FBQzlCLGdCQUFJLE1BQU0sV0FBVyxHQUFHO0FBQ3RCLDZCQUFlLEtBQUssTUFBTSxLQUFLLE1BQU0sQ0FBQyxFQUFFLFFBQVEsTUFBTSxHQUFHLEVBQUUsUUFBUSxNQUFNLEdBQUcsQ0FBQyxDQUFDO0FBQUEsWUFDaEY7QUFBQSxVQUNGLFNBQVMsR0FBRztBQUFBLFVBRVo7QUFFQSxrQkFBUSxJQUFJLDREQUFxRDtBQUFBLFlBQy9ELGFBQWEsT0FBTztBQUFBLFlBQ3BCLGNBQWMsR0FBRyxPQUFPLFVBQVUsR0FBRyxFQUFFLENBQUMsTUFBTSxPQUFPLFVBQVUsT0FBTyxTQUFTLEVBQUUsQ0FBQztBQUFBLFlBQ2xGO0FBQUEsWUFDQSxZQUFZO0FBQUEsWUFDWixjQUFjLGVBQWU7QUFBQSxjQUMzQixTQUFTLGFBQWE7QUFBQSxjQUN0QixPQUFPLGFBQWE7QUFBQSxjQUNwQixLQUFLLGFBQWE7QUFBQSxjQUNsQixXQUFXLGFBQWEsTUFBTSxJQUFJLEtBQUssYUFBYSxNQUFNLEdBQUksRUFBRSxZQUFZLElBQUk7QUFBQSxZQUNsRixJQUFJO0FBQUEsVUFDTixDQUFDO0FBQUEsUUFDSCxPQUFPO0FBQ0wsa0JBQVEsTUFBTSwyREFBc0Q7QUFDcEUsZ0JBQU0sSUFBSSxNQUFNLHNFQUFzRTtBQUFBLFFBQ3hGO0FBRUEsZ0JBQVEsSUFBSSxvREFBNkMsR0FBRyxNQUFNLHFCQUFxQjtBQUN2RixjQUFNLFdBQVcsTUFBTSxNQUFNLEdBQUcsTUFBTSx1QkFBdUI7QUFBQSxVQUMzRCxRQUFRO0FBQUEsVUFDUjtBQUFBLFVBQ0EsTUFBTSxLQUFLLFVBQVU7QUFBQSxZQUNuQjtBQUFBLFlBQ0EsaUJBQWlCO0FBQUEsWUFDakIsVUFBVTtBQUFBLGNBQ1IsUUFBUTtBQUFBLGNBQ1IsVUFBVSxZQUFZO0FBQUEsY0FDdEIsV0FBVyxLQUFLLElBQUk7QUFBQSxZQUN0QjtBQUFBLFVBQ0YsQ0FBQztBQUFBLFVBQ0QsUUFBUSxXQUFXO0FBQUEsUUFDckIsQ0FBQztBQUVELHFCQUFhLFNBQVM7QUFFdEIsWUFBSSxDQUFDLFNBQVMsSUFBSTtBQUNoQixnQkFBTSxZQUFZLE1BQU0sU0FBUyxLQUFLO0FBQ3RDLGNBQUk7QUFDSixjQUFJO0FBQ0YsMkJBQWUsS0FBSyxNQUFNLFNBQVM7QUFBQSxVQUNyQyxRQUFRO0FBQ04sMkJBQWUsRUFBRSxLQUFLLFVBQVU7QUFBQSxVQUNsQztBQUVBLGtCQUFRLE1BQU0saUNBQWlDO0FBQUEsWUFDN0MsUUFBUSxTQUFTO0FBQUEsWUFDakIsWUFBWSxTQUFTO0FBQUEsWUFDckIsT0FBTztBQUFBLFlBQ1A7QUFBQSxZQUNBO0FBQUEsWUFDQSxXQUFXLENBQUMsQ0FBQztBQUFBLFlBQ2IsY0FBYyxRQUFRO0FBQUEsWUFDdEIsY0FBYyxTQUFTLEdBQUcsT0FBTyxVQUFVLEdBQUcsRUFBRSxDQUFDLE1BQU0sT0FBTyxVQUFVLE9BQU8sU0FBUyxFQUFFLENBQUMsS0FBSztBQUFBLFlBQ2hHLGdCQUFnQixPQUFPLEtBQUssT0FBTztBQUFBLFVBQ3JDLENBQUM7QUFHRCxjQUFJLFNBQVMsV0FBVyxLQUFLO0FBQzNCLG9CQUFRLElBQUksZ0VBQXlEO0FBR3JFLGtCQUFNLFVBQVUsTUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLENBQUMsb0JBQW9CLENBQUM7QUFDckUsZ0JBQUksUUFBUSxvQkFBb0IsV0FBVyxjQUFjO0FBQ3ZELG9CQUFNLFNBQVMsTUFBTSxXQUFXO0FBQ2hDLGtCQUFJO0FBQ0Ysc0JBQU0sa0JBQWtCLE1BQU0sTUFBTSxHQUFHLE9BQU8sTUFBTSwyQkFBMkI7QUFBQSxrQkFDN0UsUUFBUTtBQUFBLGtCQUNSLFNBQVMsRUFBRSxnQkFBZ0IsbUJBQW1CO0FBQUEsa0JBQzlDLE1BQU0sS0FBSyxVQUFVLEVBQUUsT0FBTyxRQUFRLG1CQUFtQixVQUFVLGFBQWEsQ0FBQztBQUFBLGdCQUNuRixDQUFDO0FBRUQsb0JBQUksZ0JBQWdCLElBQUk7QUFDdEIsd0JBQU0sY0FBYyxNQUFNLGdCQUFnQixLQUFLO0FBQy9DLHdCQUFNLFdBQVcsWUFBWSxNQUFNLFNBQVMsWUFBWTtBQUV4RCxzQkFBSSxVQUFVO0FBRVosNEJBQVEsbUJBQW1CLFVBQVUsZUFBZTtBQUNwRCw0QkFBUSxtQkFBbUIsVUFBVSxhQUFhLEtBQUssSUFBSSxJQUFLLFFBQVE7QUFDeEUsMEJBQU0sT0FBTyxRQUFRLE1BQU0sSUFBSSxFQUFFLG9CQUFvQixRQUFRLG1CQUFtQixDQUFDO0FBRWpGLDRCQUFRLElBQUksaUVBQTREO0FBR3hFLDBCQUFNLGVBQWU7QUFBQSxzQkFDbkIsZ0JBQWdCO0FBQUEsc0JBQ2hCLGtCQUFrQjtBQUFBLG9CQUNwQjtBQUdBLDBCQUFNLGtCQUFrQixJQUFJLGdCQUFnQjtBQUM1QywwQkFBTSxpQkFBaUIsV0FBVyxNQUFNLGdCQUFnQixNQUFNLEdBQUcsR0FBSztBQUV0RSwwQkFBTSxnQkFBZ0IsTUFBTSxNQUFNLEdBQUcsTUFBTSx1QkFBdUI7QUFBQSxzQkFDaEUsUUFBUTtBQUFBLHNCQUNSLFNBQVM7QUFBQSxzQkFDVCxNQUFNLEtBQUssVUFBVTtBQUFBLHdCQUNuQjtBQUFBLHdCQUNBLGlCQUFpQjtBQUFBLHdCQUNqQixVQUFVO0FBQUEsMEJBQ1IsUUFBUTtBQUFBLDBCQUNSLFVBQVUsWUFBWTtBQUFBLDBCQUN0QixXQUFXLEtBQUssSUFBSTtBQUFBLHdCQUN0QjtBQUFBLHNCQUNGLENBQUM7QUFBQSxzQkFDRCxRQUFRLGdCQUFnQjtBQUFBLG9CQUMxQixDQUFDO0FBRUQsaUNBQWEsY0FBYztBQUUzQix3QkFBSSxjQUFjLElBQUk7QUFDcEIsNEJBQU0sY0FBYyxNQUFNLGNBQWMsS0FBSztBQUM3Qyw4QkFBUSxJQUFJLG1FQUE4RDtBQUMxRSw2QkFBTyxFQUFFLFNBQVMsTUFBTSxNQUFNLFlBQVk7QUFBQSxvQkFDNUM7QUFBQSxrQkFDRjtBQUFBLGdCQUNGO0FBQUEsY0FDRixTQUFTLGNBQWM7QUFDckIsd0JBQVEsTUFBTSxzQ0FBc0MsWUFBWTtBQUFBLGNBQ2xFO0FBQUEsWUFDRjtBQUdBLGtCQUFNLFdBQVcsY0FBYyxXQUFXLGNBQWMsU0FBUztBQUNqRSxrQkFBTSxJQUFJLE1BQU0seUZBQXlGLFFBQVEsRUFBRTtBQUFBLFVBQ3JIO0FBRUEsZ0JBQU0sSUFBSSxNQUFNLHVCQUF1QixTQUFTLE1BQU0sS0FBSyxTQUFTLEVBQUU7QUFBQSxRQUN4RTtBQUVBLGNBQU0sU0FBUyxNQUFNLFNBQVMsS0FBSztBQUNuQyxnQkFBUSxJQUFJLDBDQUEwQztBQUFBLFVBQ3BELG1CQUFtQixDQUFDLENBQUMsT0FBTztBQUFBLFVBQzVCLHNCQUFzQixPQUFPLGlCQUFpQjtBQUFBLFFBQ2hELENBQUM7QUFDRCxlQUFPLEVBQUUsU0FBUyxNQUFNLE1BQU0sT0FBTztBQUFBLE1BQ3ZDLFNBQVMsWUFBWTtBQUNuQixxQkFBYSxTQUFTO0FBQ3RCLFlBQUksV0FBVyxTQUFTLGNBQWM7QUFDcEMsZ0JBQU0sSUFBSSxNQUFNLDJDQUEyQztBQUFBLFFBQzdEO0FBQ0EsY0FBTTtBQUFBLE1BQ1I7QUFBQSxJQUNGLFNBQVMsT0FBTztBQUNkLGNBQVEsTUFBTSxvQ0FBb0MsS0FBSztBQUN2RCxZQUFNO0FBQUEsSUFDUjtBQUFBLEVBQ0Y7QUFLQSxpQkFBZSxtQkFBbUIsTUFBTSxnQkFBZ0IsUUFBUSxRQUFRLFFBQVE7QUFDOUUsUUFBSTtBQUNGLFVBQUksQ0FBQyxRQUFRO0FBQ1gsY0FBTSxJQUFJLE1BQU0sd0NBQXdDO0FBQUEsTUFDMUQ7QUFFQSxZQUFNLFdBQVcsTUFBTSxNQUFNLEdBQUcsTUFBTSx1QkFBdUI7QUFBQSxRQUMzRCxRQUFRO0FBQUEsUUFDUixTQUFTO0FBQUEsVUFDUCxnQkFBZ0I7QUFBQSxVQUNoQixrQkFBa0I7QUFBQSxRQUNwQjtBQUFBLFFBQ0EsTUFBTSxLQUFLLFVBQVU7QUFBQSxVQUNuQjtBQUFBLFVBQ0E7QUFBQSxVQUNBLGlCQUFpQjtBQUFBLFVBQ2pCLGVBQWU7QUFBQSxZQUNiLE9BQU87QUFBQSxZQUNQLFNBQVM7QUFBQSxZQUNULE1BQU07QUFBQSxVQUNSO0FBQUEsUUFDRixDQUFDO0FBQUEsTUFDSCxDQUFDO0FBRUQsVUFBSSxDQUFDLFNBQVMsSUFBSTtBQUNoQixjQUFNLElBQUksTUFBTSx1QkFBdUIsU0FBUyxNQUFNLEVBQUU7QUFBQSxNQUMxRDtBQUVBLFlBQU0sU0FBUyxNQUFNLFNBQVMsS0FBSztBQUNuQyxhQUFPLEVBQUUsU0FBUyxNQUFNLE1BQU0sT0FBTztBQUFBLElBQ3ZDLFNBQVMsT0FBTztBQUNkLGNBQVEsTUFBTSxvQ0FBb0MsS0FBSztBQUN2RCxhQUFPLEVBQUUsU0FBUyxPQUFPLE9BQU8sTUFBTSxRQUFRO0FBQUEsSUFDaEQ7QUFBQSxFQUNGO0FBTUEsaUJBQWUsdUJBQXVCLFVBQVUsVUFBVSxRQUFRLFFBQVEsV0FBVyxNQUFNO0FBQ3pGLFFBQUk7QUFDRixVQUFJLENBQUMsVUFBVTtBQUNiLGNBQU0sSUFBSSxNQUFNLDBDQUEwQztBQUFBLE1BQzVEO0FBS0EsWUFBTSxhQUFhLElBQUksZ0JBQWdCO0FBQ3ZDLFlBQU0sWUFBWSxXQUFXLE1BQU0sV0FBVyxNQUFNLEdBQUcsR0FBSztBQUU1RCxVQUFJO0FBRUYsY0FBTSxXQUFXLE1BQU0sTUFBTSxHQUFHLE1BQU0sdUJBQXVCO0FBQUEsVUFDM0QsUUFBUTtBQUFBLFVBQ1IsU0FBUztBQUFBLFlBQ1AsZ0JBQWdCO0FBQUEsWUFDaEIsR0FBSSxTQUFTLEVBQUUsa0JBQWtCLE9BQU8sSUFBSSxDQUFDO0FBQUEsVUFDL0M7QUFBQSxVQUNBLE1BQU0sS0FBSyxVQUFVO0FBQUEsWUFDbkIsTUFBTTtBQUFBLFlBQ04saUJBQWlCO0FBQUEsWUFDakIsZUFBZTtBQUFBLFlBQ2YsVUFBVTtBQUFBLGNBQ1IsUUFBUTtBQUFBLGNBQ1IsVUFBVSxZQUFZO0FBQUEsY0FDdEI7QUFBQSxjQUNBLFdBQVcsS0FBSyxJQUFJO0FBQUEsWUFDdEI7QUFBQSxVQUNGLENBQUM7QUFBQSxVQUNELFFBQVEsV0FBVztBQUFBLFFBQ3JCLENBQUM7QUFFRCxxQkFBYSxTQUFTO0FBRXRCLFlBQUksQ0FBQyxTQUFTLElBQUk7QUFDaEIsZ0JBQU0sWUFBWSxNQUFNLFNBQVMsS0FBSztBQUN0QyxrQkFBUSxNQUFNLHNDQUFzQyxFQUFFLFFBQVEsU0FBUyxRQUFRLE9BQU8sVUFBVSxDQUFDO0FBQ2pHLGdCQUFNLElBQUksTUFBTSx1QkFBdUIsU0FBUyxNQUFNLEtBQUssU0FBUyxFQUFFO0FBQUEsUUFDeEU7QUFFQSxjQUFNLFNBQVMsTUFBTSxTQUFTLEtBQUs7QUFDbkMsZ0JBQVEsSUFBSSwrQ0FBK0M7QUFBQSxVQUN6RCxtQkFBbUIsQ0FBQyxDQUFDLE9BQU87QUFBQSxVQUM1QjtBQUFBLFFBQ0YsQ0FBQztBQUNELGVBQU8sRUFBRSxTQUFTLE1BQU0sTUFBTSxPQUFPO0FBQUEsTUFDdkMsU0FBUyxZQUFZO0FBQ25CLHFCQUFhLFNBQVM7QUFDdEIsWUFBSSxXQUFXLFNBQVMsY0FBYztBQUNwQyxnQkFBTSxJQUFJLE1BQU0sZ0RBQWdEO0FBQUEsUUFDbEU7QUFDQSxjQUFNO0FBQUEsTUFDUjtBQUFBLElBQ0YsU0FBUyxPQUFPO0FBQ2QsY0FBUSxNQUFNLHlDQUF5QyxLQUFLO0FBQzVELGFBQU8sRUFBRSxTQUFTLE9BQU8sT0FBTyxNQUFNLFdBQVcsT0FBTyxLQUFLLEVBQUU7QUFBQSxJQUNqRTtBQUFBLEVBQ0Y7QUFFQSxVQUFRLElBQUksb0RBQW9EOyIsCiAgIm5hbWVzIjogW10KfQo=
