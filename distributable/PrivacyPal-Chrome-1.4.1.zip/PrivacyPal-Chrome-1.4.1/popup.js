
        // Buffer polyfill for browser (popup context)
        if (typeof globalThis !== 'undefined' && typeof Buffer === 'undefined') {
          globalThis.Buffer = {
            from: (data, encoding) => {
              if (typeof data === 'string') {
                const encoder = new TextEncoder();
                return encoder.encode(data);
              }
              return data;
            },
            isBuffer: () => false
          };
        }
      
(() => {
  // src/config/config.js
  var DEFAULT_ENDPOINTS = {
    // API endpoint for PrivacyPal Cloud services
    // Production: https://api.privacypal.ai
    // Development: http://localhost:42026 (can be changed in settings)
    apiUrl: "https://api.privacypal.ai",
    // User Portal endpoint for account management and subscriptions
    // Production: https://portal.privacypal.ai
    // Development: http://localhost:5174 (can be changed in settings)
    userPortalUrl: "https://portal.privacypal.ai"
  };
  async function loadConfig() {
    try {
      const stored = await chrome.storage.local.get(["apiUrl", "userPortalUrl"]);
      return {
        apiUrl: stored.apiUrl || DEFAULT_ENDPOINTS.apiUrl,
        userPortalUrl: stored.userPortalUrl || DEFAULT_ENDPOINTS.userPortalUrl
      };
    } catch (error) {
      console.warn("[PrivacyPal] Failed to load config from storage, using defaults:", error);
      return DEFAULT_ENDPOINTS;
    }
  }
  async function saveConfig(config) {
    try {
      await chrome.storage.local.set({
        apiUrl: config.apiUrl,
        userPortalUrl: config.userPortalUrl
      });
      return true;
    } catch (error) {
      console.error("[PrivacyPal] Failed to save config:", error);
      return false;
    }
  }

  // src/auth/auth-service.js
  var AuthService = class {
    constructor() {
      this.jwtTokens = null;
      this.userProfile = null;
      this.tokenRefreshTimer = null;
    }
    async initialize() {
      await this.restoreSession();
    }
    async restoreSession() {
      try {
        const storage = await chrome.storage.local.get(["privacypal_session"]);
        if (storage.privacypal_session?.jwtTokens) {
          this.jwtTokens = storage.privacypal_session.jwtTokens;
          this.userProfile = storage.privacypal_session.userProfile;
          if (this.jwtTokens.expires_at > Date.now()) {
            this.setupTokenRefresh();
            return true;
          }
          const refreshed = await this.refreshTokens();
          return !!refreshed;
        }
        return false;
      } catch (error) {
        console.error("Session restore failed:", error);
        return false;
      }
    }
    async authenticate(provider, credentials) {
      if (provider === "local") {
        return await this.authenticateLocal(credentials);
      } else if (provider === "google" || provider === "microsoft") {
        return await this.authenticateOAuth(provider);
      } else {
        throw new Error(`Unsupported authentication provider: ${provider}`);
      }
    }
    async authenticateLocal(credentials) {
      try {
        const config = await loadConfig();
        const response = await fetch(`${config.apiUrl}/api/user/login`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            email: credentials.email,
            password: credentials.password
          })
        });
        const data = await response.json();
        if (response.ok && (data.data?.token || data.token)) {
          const token = data.data?.token || data.token;
          const user = data.data?.user || data.user || { email: credentials.email };
          this.jwtTokens = {
            access_token: token,
            token_type: "Bearer",
            expires_in: 28800,
            // 8 hours
            expires_at: Date.now() + 28800 * 1e3
          };
          this.userProfile = user;
          await this.persistSession();
          this.setupTokenRefresh();
          this.updateAuthBadge(true);
          return { success: true, user: this.userProfile };
        }
        return { success: false, error: data.error || data.message || "Login failed" };
      } catch (error) {
        console.error("Local authentication error:", error);
        return { success: false, error: error.message || "Network error" };
      }
    }
    async authenticateOAuth(provider) {
      try {
        const state = crypto.randomUUID();
        const redirectUri = chrome.runtime.getURL("src/auth/callback.html");
        await chrome.storage.local.set({
          authState: state,
          authProvider: provider,
          authTimestamp: Date.now()
        });
        const config = await loadConfig();
        const authUrl = `${config.apiUrl}/api/auth/${provider}?state=${state}&redirect_uri=${encodeURIComponent(redirectUri)}`;
        const popup = await chrome.windows.create({
          url: authUrl,
          type: "popup",
          width: 600,
          height: 700,
          focused: true
        });
        return await this.waitForPopupAuthCompletion(popup.id, state);
      } catch (error) {
        console.error(`${provider} authentication error:`, error);
        throw error;
      }
    }
    async waitForPopupAuthCompletion(popupId, expectedState) {
      return new Promise((resolve, reject) => {
        const timeout = setTimeout(() => {
          cleanup();
          reject(new Error("Authentication timeout"));
        }, 5 * 60 * 1e3);
        const messageListener = (message, sender, sendResponse) => {
          console.log("[AuthService] Message received:", message.type, message);
          if (message.type === "OAUTH_COMPLETE") {
            console.log("[AuthService] OAuth complete message:", {
              state: message.state,
              expectedState,
              success: message.success
            });
            if (message.state === expectedState && message.success) {
              cleanup();
              setTimeout(() => {
                chrome.storage.local.get(["privacypal_session"], async (result) => {
                  console.log("[AuthService] Retrieved session from storage:", !!result.privacypal_session);
                  if (result.privacypal_session) {
                    this.jwtTokens = result.privacypal_session.jwtTokens;
                    this.userProfile = result.privacypal_session.userProfile;
                    this.setupTokenRefresh();
                    this.updateAuthBadge(true);
                    resolve({ success: true, user: this.userProfile });
                  } else {
                    setTimeout(() => {
                      chrome.storage.local.get(["privacypal_session"], async (retryResult) => {
                        if (retryResult.privacypal_session) {
                          this.jwtTokens = retryResult.privacypal_session.jwtTokens;
                          this.userProfile = retryResult.privacypal_session.userProfile;
                          this.setupTokenRefresh();
                          this.updateAuthBadge(true);
                          resolve({ success: true, user: this.userProfile });
                        } else {
                          reject(new Error("OAuth completed but session data not found"));
                        }
                      });
                    }, 500);
                  }
                });
              }, 200);
            } else {
              cleanup();
              reject(new Error("OAuth state mismatch or failed"));
            }
          }
          return true;
        };
        const windowRemovedListener = (windowId) => {
          if (windowId === popupId) {
            console.log("[AuthService] Popup window closed:", windowId);
            setTimeout(() => {
              chrome.storage.local.get(["privacypal_session"], (result) => {
                if (!result.privacypal_session) {
                  cleanup();
                  reject(new Error("Authentication window closed"));
                }
              });
            }, 1e3);
          }
        };
        const cleanup = () => {
          clearTimeout(timeout);
          chrome.runtime.onMessage.removeListener(messageListener);
          chrome.windows.onRemoved.removeListener(windowRemovedListener);
          chrome.windows.get(popupId, () => {
            if (!chrome.runtime.lastError) {
              chrome.windows.remove(popupId).catch(() => {
              });
            }
          });
        };
        chrome.runtime.onMessage.addListener(messageListener);
        chrome.windows.onRemoved.addListener(windowRemovedListener);
      });
    }
    async getJWTToken() {
      if (this.jwtTokens && this.jwtTokens.expires_at > Date.now() + 6e4) {
        return this.jwtTokens;
      }
      const storage = await chrome.storage.local.get(["privacypal_session"]);
      if (storage.privacypal_session?.jwtTokens) {
        this.jwtTokens = storage.privacypal_session.jwtTokens;
        if (this.jwtTokens.expires_at > Date.now() + 6e4) {
          return this.jwtTokens;
        }
      }
      const refreshed = await this.refreshTokens();
      return refreshed || null;
    }
    async refreshTokens() {
      try {
        const storage = await chrome.storage.local.get(["privacypal_session"]);
        if (!storage.privacypal_session?.jwtTokens?.access_token) {
          console.warn("[AuthService] No token found for refresh");
          return null;
        }
        const oldToken = storage.privacypal_session.jwtTokens.access_token;
        const config = await loadConfig();
        const response = await fetch(`${config.apiUrl}/api/user/refresh-token`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ token: oldToken })
        });
        if (!response.ok) {
          const errorData = await response.json().catch(() => ({}));
          console.warn("[AuthService] Token refresh failed:", errorData.error || response.statusText);
          return null;
        }
        const data = await response.json();
        const newToken = data.data?.token || data.token;
        if (!newToken) {
          console.warn("[AuthService] No token in refresh response");
          return null;
        }
        this.jwtTokens = {
          access_token: newToken,
          token_type: "Bearer",
          expires_in: 28800,
          // 8 hours
          expires_at: Date.now() + 28800 * 1e3
        };
        await this.persistSession();
        this.setupTokenRefresh();
        console.log("[AuthService] Token refreshed successfully");
        return this.jwtTokens;
      } catch (error) {
        console.warn("[AuthService] Token refresh error:", error.message);
        return null;
      }
    }
    setupTokenRefresh() {
      if (this.tokenRefreshTimer) {
        clearTimeout(this.tokenRefreshTimer);
      }
      if (this.jwtTokens?.expires_in) {
        const refreshTime = (this.jwtTokens.expires_in - 900) * 1e3;
        this.tokenRefreshTimer = setTimeout(() => {
          console.log("[AuthService] Auto-refreshing token before expiration");
          this.refreshTokens().catch(console.error);
        }, refreshTime);
      }
    }
    async persistSession() {
      const sessionData = {
        jwtTokens: this.jwtTokens,
        userProfile: this.userProfile,
        sessionId: this.sessionId || crypto.randomUUID(),
        sessionStartTime: this.sessionStartTime || Date.now(),
        timestamp: Date.now()
      };
      if (!this.sessionId) {
        this.sessionId = sessionData.sessionId;
      }
      if (!this.sessionStartTime) {
        this.sessionStartTime = sessionData.sessionStartTime;
      }
      await chrome.storage.local.set({
        privacypal_session: sessionData
      });
    }
    async getAuthStatus() {
      try {
        const tokens = await this.getJWTToken();
        if (tokens && tokens.expires_at > Date.now()) {
          return {
            authenticated: true,
            user: this.userProfile
          };
        }
      } catch (error) {
        console.error("Auth status check failed:", error);
      }
      return { authenticated: false };
    }
    async logout() {
      if (this.tokenRefreshTimer) {
        clearTimeout(this.tokenRefreshTimer);
        this.tokenRefreshTimer = null;
      }
      this.jwtTokens = null;
      this.userProfile = null;
      await chrome.storage.local.remove(["privacypal_session", "authState", "authProvider", "authTimestamp"]);
      this.updateAuthBadge(false);
      return { success: true };
    }
    async isAuthenticated() {
      try {
        const tokens = await this.getJWTToken();
        return !!tokens && tokens.expires_at > Date.now();
      } catch (error) {
        return false;
      }
    }
    async getToken() {
      const tokens = await this.getJWTToken();
      return tokens?.access_token || null;
    }
    async getCurrentUser() {
      return this.userProfile;
    }
    updateAuthBadge(isAuthenticated2) {
      try {
        if (chrome.action?.setBadgeText) {
          chrome.action.setBadgeText({ text: isAuthenticated2 ? "ON" : "OFF" });
          chrome.action.setBadgeBackgroundColor({
            color: isAuthenticated2 ? "#10b981" : "#ef4444"
          });
          chrome.action.setTitle({
            title: isAuthenticated2 ? "PrivacyPal - Authenticated" : "PrivacyPal - Not Authenticated"
          });
        }
      } catch (error) {
        console.error("Failed to update badge:", error);
      }
    }
  };
  var authService = new AuthService();
  var auth_service_default = authService;

  // src/popup/popup.js
  var elements = {
    // Auth view
    authView: document.getElementById("authView"),
    mainView: document.getElementById("mainView"),
    loginTab: document.getElementById("loginTab"),
    signupTab: document.getElementById("signupTab"),
    loginForm: document.getElementById("loginForm"),
    signupForm: document.getElementById("signupForm"),
    loginEmail: document.getElementById("loginEmail"),
    loginPassword: document.getElementById("loginPassword"),
    loginBtn: document.getElementById("loginBtn"),
    signupFirstName: document.getElementById("signupFirstName"),
    signupLastName: document.getElementById("signupLastName"),
    signupEmail: document.getElementById("signupEmail"),
    signupPassword: document.getElementById("signupPassword"),
    signupBtn: document.getElementById("signupBtn"),
    googleLoginBtn: document.getElementById("googleLoginBtn"),
    microsoftLoginBtn: document.getElementById("microsoftLoginBtn"),
    googleSignupBtn: document.getElementById("googleSignupBtn"),
    microsoftSignupBtn: document.getElementById("microsoftSignupBtn"),
    authError: document.getElementById("authError"),
    logoutBtn: document.getElementById("logoutBtn"),
    // Main view
    enabledToggle: document.getElementById("enabledToggle"),
    statusIndicator: document.getElementById("statusIndicator"),
    statusDot: document.querySelector(".status-dot"),
    statusText: document.querySelector(".status-text"),
    themeToggleBtn: document.getElementById("themeToggleBtn"),
    settingsBtn: document.getElementById("settingsBtn"),
    app: document.querySelector(".app"),
    settingsOverlay: document.getElementById("settingsOverlay"),
    settingsPanel: document.getElementById("settingsPanel"),
    closeSettingsBtn: document.getElementById("closeSettingsBtn"),
    apiUrl: document.getElementById("apiUrl"),
    userPortalUrl: document.getElementById("userPortalUrl"),
    userEmail: document.getElementById("userEmail"),
    showNotifications: document.getElementById("showNotifications"),
    debugMode: document.getElementById("debugMode"),
    testConnectionBtn: document.getElementById("testConnectionBtn"),
    saveSettingsBtn: document.getElementById("saveSettingsBtn"),
    connectionStatus: document.getElementById("connectionStatus"),
    versionNumber: document.getElementById("versionNumber")
  };
  var currentConfig = {};
  var settingsPanelVisible = false;
  var isDarkMode = true;
  var isAuthenticated = false;
  async function init() {
    await auth_service_default.initialize();
    const authStatus = await auth_service_default.getAuthStatus();
    isAuthenticated = authStatus.authenticated;
    loadVersion();
    await loadTheme();
    if (isAuthenticated) {
      showMainView();
      await displayUserEmail();
      await loadConfig2();
      setupEventListeners();
      updateUI();
    } else {
      showAuthView();
      setupAuthEventListeners();
    }
  }
  function loadVersion() {
    if (elements.versionNumber) {
      try {
        const manifest = chrome.runtime.getManifest();
        elements.versionNumber.textContent = `v${manifest.version}`;
      } catch (error) {
        console.warn("[PrivacyPal] Could not load version:", error);
      }
    }
  }
  async function loadTheme() {
    return new Promise((resolve) => {
      chrome.storage.local.get(["darkMode"], (result) => {
        isDarkMode = result.darkMode !== false;
        updateTheme();
        resolve();
      });
    });
  }
  function updateTheme() {
    if (elements.app) {
      if (isDarkMode) {
        elements.app.classList.add("pp-dark-mode");
        elements.app.classList.remove("pp-light-mode");
      } else {
        elements.app.classList.add("pp-light-mode");
        elements.app.classList.remove("pp-dark-mode");
      }
    }
  }
  async function loadConfig2() {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ action: "getConfig" }, async (response) => {
        if (response?.config) {
          currentConfig = response.config;
          let apiUrl = currentConfig.apiUrl || DEFAULT_ENDPOINTS.apiUrl;
          let userPortalUrl = currentConfig.userPortalUrl || DEFAULT_ENDPOINTS.userPortalUrl;
          if (apiUrl.includes("localhost:42026") || apiUrl.includes("127.0.0.1:42026")) {
            apiUrl = DEFAULT_ENDPOINTS.apiUrl;
            await chrome.runtime.sendMessage({
              action: "updateConfig",
              config: { ...currentConfig, apiUrl }
            });
          }
          if (userPortalUrl.includes("localhost:5174") || userPortalUrl.includes("127.0.0.1:5174")) {
            userPortalUrl = DEFAULT_ENDPOINTS.userPortalUrl;
            await chrome.runtime.sendMessage({
              action: "updateConfig",
              config: { ...currentConfig, userPortalUrl }
            });
          }
          elements.enabledToggle.checked = currentConfig.enabled !== false;
          elements.apiUrl.value = apiUrl;
          if (elements.userPortalUrl) {
            elements.userPortalUrl.value = userPortalUrl;
          }
          elements.showNotifications.checked = currentConfig.showNotifications !== false;
          elements.debugMode.checked = currentConfig.debug === true;
        }
        resolve();
      });
    });
  }
  async function displayUserEmail() {
    try {
      const session = await chrome.storage.local.get(["privacypal_session"]);
      if (session.privacypal_session?.userProfile?.email && elements.userEmail) {
        elements.userEmail.textContent = session.privacypal_session.userProfile.email;
        elements.userEmail.title = session.privacypal_session.userProfile.email;
      } else if (elements.userEmail) {
        elements.userEmail.textContent = "";
        elements.userEmail.title = "";
      }
    } catch (error) {
      console.error("[PrivacyPal] Failed to display user email:", error);
    }
  }
  function showAuthView() {
    if (elements.authView)
      elements.authView.style.display = "block";
    if (elements.mainView)
      elements.mainView.style.display = "none";
  }
  function showMainView() {
    if (elements.authView)
      elements.authView.style.display = "none";
    if (elements.mainView)
      elements.mainView.style.display = "block";
  }
  function setupAuthEventListeners() {
    if (elements.loginTab) {
      elements.loginTab.addEventListener("click", () => {
        elements.loginTab.classList.add("active");
        elements.signupTab.classList.remove("active");
        elements.loginForm.style.display = "block";
        elements.signupForm.style.display = "none";
        hideAuthError();
      });
    }
    if (elements.signupTab) {
      elements.signupTab.addEventListener("click", () => {
        elements.signupTab.classList.add("active");
        elements.loginTab.classList.remove("active");
        elements.signupForm.style.display = "block";
        elements.loginForm.style.display = "none";
        hideAuthError();
      });
    }
    if (elements.loginBtn) {
      elements.loginBtn.addEventListener("click", async () => {
        await handleLogin();
      });
    }
    if (elements.signupBtn) {
      elements.signupBtn.addEventListener("click", async () => {
        await handleSignup();
      });
    }
    if (elements.googleLoginBtn) {
      elements.googleLoginBtn.addEventListener("click", () => handleOAuth("google"));
    }
    if (elements.microsoftLoginBtn) {
      elements.microsoftLoginBtn.addEventListener("click", () => handleOAuth("microsoft"));
    }
    if (elements.googleSignupBtn) {
      elements.googleSignupBtn.addEventListener("click", () => handleOAuth("google"));
    }
    if (elements.microsoftSignupBtn) {
      elements.microsoftSignupBtn.addEventListener("click", () => handleOAuth("microsoft"));
    }
    if (elements.loginPassword) {
      elements.loginPassword.addEventListener("keypress", (e) => {
        if (e.key === "Enter")
          handleLogin();
      });
    }
    if (elements.signupPassword) {
      elements.signupPassword.addEventListener("keypress", (e) => {
        if (e.key === "Enter")
          handleSignup();
      });
    }
  }
  async function handleLogin() {
    const email = elements.loginEmail?.value.trim();
    const password = elements.loginPassword?.value;
    if (!email || !password) {
      showAuthError("Please enter email and password");
      return;
    }
    elements.loginBtn.disabled = true;
    elements.loginBtn.textContent = "Signing in...";
    hideAuthError();
    try {
      const result = await auth_service_default.authenticate("local", { email, password });
      if (result.success) {
        isAuthenticated = true;
        showMainView();
        await loadConfig2();
        setupEventListeners();
        updateUI();
      } else {
        showAuthError(result.error || "Login failed");
      }
    } catch (error) {
      showAuthError(error.message || "An error occurred");
    } finally {
      elements.loginBtn.disabled = false;
      elements.loginBtn.textContent = "Sign In";
    }
  }
  async function handleSignup() {
    const firstName = elements.signupFirstName?.value.trim();
    const lastName = elements.signupLastName?.value.trim();
    const email = elements.signupEmail?.value.trim();
    const password = elements.signupPassword?.value;
    if (!firstName || !lastName || !email || !password) {
      showAuthError("Please fill in all fields");
      return;
    }
    elements.signupBtn.disabled = true;
    elements.signupBtn.textContent = "Creating account...";
    hideAuthError();
    try {
      const config = await loadConfig();
      const registerResponse = await fetch(`${config.apiUrl}/api/user/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ firstName, lastName, email, password })
      });
      const registerData = await registerResponse.json();
      if (registerResponse.ok && registerData.token) {
        const loginResult = await auth_service_default.authenticate("local", { email, password });
        if (loginResult.success) {
          isAuthenticated = true;
          showMainView();
          await displayUserEmail();
          await loadConfig2();
          setupEventListeners();
          updateUI();
        } else {
          showAuthError("Account created but login failed. Please try signing in.");
        }
      } else {
        showAuthError(registerData.error || "Registration failed");
      }
    } catch (error) {
      showAuthError(error.message || "An error occurred");
    } finally {
      elements.signupBtn.disabled = false;
      elements.signupBtn.textContent = "Create Account";
    }
  }
  async function handleOAuth(provider) {
    try {
      const btn = provider === "google" ? elements.googleLoginBtn || elements.googleSignupBtn : elements.microsoftLoginBtn || elements.microsoftSignupBtn;
      if (btn) {
        btn.disabled = true;
        btn.textContent = "Connecting...";
      }
      hideAuthError();
      const result = await auth_service_default.authenticate(provider);
      if (result.success) {
        isAuthenticated = true;
        showMainView();
        await displayUserEmail();
        await loadConfig2();
        setupEventListeners();
        updateUI();
      } else {
        showAuthError(result.error || "Authentication failed");
      }
    } catch (error) {
      showAuthError(error.message || "An error occurred");
    } finally {
      const btn = provider === "google" ? elements.googleLoginBtn || elements.googleSignupBtn : elements.microsoftLoginBtn || elements.microsoftSignupBtn;
      if (btn) {
        btn.disabled = false;
        const isLogin = elements.loginForm?.style.display !== "none";
        btn.textContent = provider === "google" ? isLogin ? "Continue with Google" : "Sign up with Google" : isLogin ? "Continue with Microsoft" : "Sign up with Microsoft";
      }
    }
  }
  function showAuthError(message) {
    if (elements.authError) {
      elements.authError.textContent = message;
      elements.authError.style.display = "block";
    }
  }
  function hideAuthError() {
    if (elements.authError) {
      elements.authError.style.display = "none";
    }
  }
  function updateUI() {
    const isEnabled = elements.enabledToggle?.checked;
    if (isEnabled && elements.statusDot) {
      elements.statusDot.classList.remove("inactive");
      if (elements.statusText)
        elements.statusText.textContent = "Protection Active";
    } else if (elements.statusDot) {
      elements.statusDot.classList.add("inactive");
      if (elements.statusText)
        elements.statusText.textContent = "Protection Disabled";
    }
  }
  function setupEventListeners() {
    if (elements.logoutBtn) {
      elements.logoutBtn.addEventListener("click", async () => {
        await auth_service_default.logout();
        isAuthenticated = false;
        if (elements.userEmail) {
          elements.userEmail.textContent = "";
          elements.userEmail.title = "";
        }
        showAuthView();
        setupAuthEventListeners();
      });
    }
    if (elements.enabledToggle) {
      elements.enabledToggle.addEventListener("change", async () => {
        const enabled = elements.enabledToggle.checked;
        await saveConfig2({ enabled });
        updateUI();
      });
    }
    elements.themeToggleBtn.addEventListener("click", () => {
      isDarkMode = !isDarkMode;
      updateTheme();
      chrome.storage.local.set({ darkMode: isDarkMode });
    });
    elements.settingsBtn.addEventListener("click", () => {
      openSettingsPanel();
    });
    elements.closeSettingsBtn.addEventListener("click", () => {
      closeSettingsPanel();
    });
    elements.settingsOverlay.addEventListener("click", (e) => {
      if (e.target === elements.settingsOverlay) {
        closeSettingsPanel();
      }
    });
    elements.testConnectionBtn.addEventListener("click", async () => {
      await testConnection();
    });
    elements.saveSettingsBtn.addEventListener("click", async () => {
      await saveSettings();
    });
  }
  async function testConnection() {
    const apiUrl = elements.apiUrl.value.trim();
    if (!apiUrl) {
      showConnectionStatus("Please enter API URL", "error");
      return;
    }
    const session = await chrome.storage.local.get(["privacypal_session"]);
    let apiKey = null;
    if (session.privacypal_session?.jwtTokens?.access_token) {
      const tokens = session.privacypal_session.jwtTokens;
      if (tokens.expires_at && tokens.expires_at > Date.now()) {
        apiKey = tokens.access_token;
      } else {
        showConnectionStatus("Token expired - please sign in again", "error");
        return;
      }
    } else {
      showConnectionStatus("Not authenticated - please sign in", "error");
      return;
    }
    elements.testConnectionBtn.textContent = "Testing...";
    elements.testConnectionBtn.disabled = true;
    try {
      const response = await new Promise((resolve) => {
        chrome.runtime.sendMessage(
          {
            action: "testConnection",
            apiUrl,
            apiKey
          },
          resolve
        );
      });
      if (response.success) {
        showConnectionStatus("\u2713 Connected to PrivacyPal API", "success");
      } else {
        showConnectionStatus(`\u2717 ${response.error}`, "error");
      }
    } catch (error) {
      showConnectionStatus(`\u2717 Connection failed: ${error.message}`, "error");
    } finally {
      elements.testConnectionBtn.textContent = "Test Connection";
      elements.testConnectionBtn.disabled = false;
    }
  }
  async function saveSettings() {
    const config = {
      apiUrl: elements.apiUrl.value.trim(),
      userPortalUrl: elements.userPortalUrl?.value.trim() || DEFAULT_ENDPOINTS.userPortalUrl,
      // Don't save apiKey - it comes from authenticated session
      showNotifications: elements.showNotifications.checked,
      debug: elements.debugMode.checked
    };
    await saveConfig({
      apiUrl: config.apiUrl,
      userPortalUrl: config.userPortalUrl
    });
    await new Promise((resolve) => {
      chrome.runtime.sendMessage({
        action: "updateConfig",
        config
      }, resolve);
    });
    showConnectionStatus("\u2713 Settings saved successfully", "success");
    setTimeout(() => {
      elements.connectionStatus.style.display = "none";
      closeSettingsPanel();
    }, 1500);
  }
  function openSettingsPanel() {
    settingsPanelVisible = true;
    elements.settingsOverlay.style.display = "block";
    setTimeout(() => {
      elements.settingsOverlay.classList.add("visible");
    }, 10);
  }
  function closeSettingsPanel() {
    settingsPanelVisible = false;
    elements.settingsOverlay.classList.remove("visible");
    setTimeout(() => {
      elements.settingsOverlay.style.display = "none";
    }, 300);
  }
  async function saveConfig2(config) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage(
        { action: "updateConfig", config },
        (response) => {
          if (response?.success) {
            currentConfig = { ...currentConfig, ...config };
          }
          resolve();
        }
      );
    });
  }
  function showConnectionStatus(message, type) {
    elements.connectionStatus.textContent = message;
    elements.connectionStatus.className = `connection-status ${type}`;
    elements.connectionStatus.style.display = "block";
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2NvbmZpZy9jb25maWcuanMiLCAiLi4vc3JjL2F1dGgvYXV0aC1zZXJ2aWNlLmpzIiwgIi4uL3NyYy9wb3B1cC9wb3B1cC5qcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiLyoqXHJcbiAqIFByaXZhY3lQYWwgQnJvd3NlciBFeHRlbnNpb24gLSBDb25maWd1cmF0aW9uXHJcbiAqIFxyXG4gKiBUaGlzIGZpbGUgY29udGFpbnMgZGVmYXVsdCBjb25maWd1cmF0aW9uIHZhbHVlcyBmb3IgdGhlIGV4dGVuc2lvbi5cclxuICogVGhlc2UgY2FuIGJlIG92ZXJyaWRkZW4gdmlhIGV4dGVuc2lvbiBzZXR0aW5ncyBpbiB0aGUgcG9wdXAgVUkuXHJcbiAqIFxyXG4gKiBGb3IgcHJvZHVjdGlvbiBkZXBsb3ltZW50cywgbW9kaWZ5IHRoZXNlIHZhbHVlcyBiZWZvcmUgYnVpbGRpbmcgdGhlIGV4dGVuc2lvbi5cclxuICovXHJcblxyXG4vLyBQcm9kdWN0aW9uIEFQSSBVUkwgLSBjYW4gYmUgb3ZlcnJpZGRlbiB2aWEgZXh0ZW5zaW9uIHNldHRpbmdzXHJcbi8vIEZvciBsb2NhbCBkZXZlbG9wbWVudCwgdXNlcnMgY2FuIGNoYW5nZSB0aGlzIGluIHRoZSBleHRlbnNpb24gc2V0dGluZ3MgVUlcclxuZXhwb3J0IGNvbnN0IERFRkFVTFRfRU5EUE9JTlRTID0ge1xyXG4gIC8vIEFQSSBlbmRwb2ludCBmb3IgUHJpdmFjeVBhbCBDbG91ZCBzZXJ2aWNlc1xyXG4gIC8vIFByb2R1Y3Rpb246IGh0dHBzOi8vYXBpLnByaXZhY3lwYWwuYWlcclxuICAvLyBEZXZlbG9wbWVudDogaHR0cDovL2xvY2FsaG9zdDo0MjAyNiAoY2FuIGJlIGNoYW5nZWQgaW4gc2V0dGluZ3MpXHJcbiAgYXBpVXJsOiAnaHR0cHM6Ly9hcGkucHJpdmFjeXBhbC5haScsXHJcbiAgXHJcbiAgLy8gVXNlciBQb3J0YWwgZW5kcG9pbnQgZm9yIGFjY291bnQgbWFuYWdlbWVudCBhbmQgc3Vic2NyaXB0aW9uc1xyXG4gIC8vIFByb2R1Y3Rpb246IGh0dHBzOi8vcG9ydGFsLnByaXZhY3lwYWwuYWlcclxuICAvLyBEZXZlbG9wbWVudDogaHR0cDovL2xvY2FsaG9zdDo1MTc0IChjYW4gYmUgY2hhbmdlZCBpbiBzZXR0aW5ncylcclxuICB1c2VyUG9ydGFsVXJsOiAnaHR0cHM6Ly9wb3J0YWwucHJpdmFjeXBhbC5haSdcclxufTtcclxuXHJcbi8qKlxyXG4gKiBMb2FkIGNvbmZpZ3VyYXRpb24gZnJvbSBzdG9yYWdlIG9yIHVzZSBkZWZhdWx0c1xyXG4gKiBUaGlzIGFsbG93cyBydW50aW1lIGNvbmZpZ3VyYXRpb24gdmlhIGV4dGVuc2lvbiBzZXR0aW5nc1xyXG4gKi9cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGxvYWRDb25maWcoKSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHN0b3JlZCA9IGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChbJ2FwaVVybCcsICd1c2VyUG9ydGFsVXJsJ10pO1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgYXBpVXJsOiBzdG9yZWQuYXBpVXJsIHx8IERFRkFVTFRfRU5EUE9JTlRTLmFwaVVybCxcclxuICAgICAgdXNlclBvcnRhbFVybDogc3RvcmVkLnVzZXJQb3J0YWxVcmwgfHwgREVGQVVMVF9FTkRQT0lOVFMudXNlclBvcnRhbFVybFxyXG4gICAgfTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS53YXJuKCdbUHJpdmFjeVBhbF0gRmFpbGVkIHRvIGxvYWQgY29uZmlnIGZyb20gc3RvcmFnZSwgdXNpbmcgZGVmYXVsdHM6JywgZXJyb3IpO1xyXG4gICAgcmV0dXJuIERFRkFVTFRfRU5EUE9JTlRTO1xyXG4gIH1cclxufVxyXG5cclxuLyoqXHJcbiAqIFNhdmUgY29uZmlndXJhdGlvbiB0byBzdG9yYWdlXHJcbiAqL1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2F2ZUNvbmZpZyhjb25maWcpIHtcclxuICB0cnkge1xyXG4gICAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHtcclxuICAgICAgYXBpVXJsOiBjb25maWcuYXBpVXJsLFxyXG4gICAgICB1c2VyUG9ydGFsVXJsOiBjb25maWcudXNlclBvcnRhbFVybFxyXG4gICAgfSk7XHJcbiAgICByZXR1cm4gdHJ1ZTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcignW1ByaXZhY3lQYWxdIEZhaWxlZCB0byBzYXZlIGNvbmZpZzonLCBlcnJvcik7XHJcbiAgICByZXR1cm4gZmFsc2U7XHJcbiAgfVxyXG59XHJcblxyXG4iLCAiLyoqXHJcbiAqIFByaXZhY3lQYWwgQnJvd3NlciBFeHRlbnNpb24gLSBBdXRoZW50aWNhdGlvbiBTZXJ2aWNlXHJcbiAqIEhhbmRsZXMgU1NPIChHb29nbGUvTWljcm9zb2Z0KSBhbmQgbG9jYWwgYXV0aGVudGljYXRpb25cclxuICovXHJcblxyXG5pbXBvcnQgeyBsb2FkQ29uZmlnIH0gZnJvbSAnLi4vY29uZmlnL2NvbmZpZy5qcyc7XHJcblxyXG5jbGFzcyBBdXRoU2VydmljZSB7XHJcbiAgY29uc3RydWN0b3IoKSB7XHJcbiAgICB0aGlzLmp3dFRva2VucyA9IG51bGw7XHJcbiAgICB0aGlzLnVzZXJQcm9maWxlID0gbnVsbDtcclxuICAgIHRoaXMudG9rZW5SZWZyZXNoVGltZXIgPSBudWxsO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgaW5pdGlhbGl6ZSgpIHtcclxuICAgIGF3YWl0IHRoaXMucmVzdG9yZVNlc3Npb24oKTtcclxuICB9XHJcblxyXG4gIGFzeW5jIHJlc3RvcmVTZXNzaW9uKCkge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3Qgc3RvcmFnZSA9IGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChbJ3ByaXZhY3lwYWxfc2Vzc2lvbiddKTtcclxuICAgICAgaWYgKHN0b3JhZ2UucHJpdmFjeXBhbF9zZXNzaW9uPy5qd3RUb2tlbnMpIHtcclxuICAgICAgICB0aGlzLmp3dFRva2VucyA9IHN0b3JhZ2UucHJpdmFjeXBhbF9zZXNzaW9uLmp3dFRva2VucztcclxuICAgICAgICB0aGlzLnVzZXJQcm9maWxlID0gc3RvcmFnZS5wcml2YWN5cGFsX3Nlc3Npb24udXNlclByb2ZpbGU7XHJcblxyXG4gICAgICAgIGlmICh0aGlzLmp3dFRva2Vucy5leHBpcmVzX2F0ID4gRGF0ZS5ub3coKSkge1xyXG4gICAgICAgICAgdGhpcy5zZXR1cFRva2VuUmVmcmVzaCgpO1xyXG4gICAgICAgICAgcmV0dXJuIHRydWU7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBjb25zdCByZWZyZXNoZWQgPSBhd2FpdCB0aGlzLnJlZnJlc2hUb2tlbnMoKTtcclxuICAgICAgICByZXR1cm4gISFyZWZyZXNoZWQ7XHJcbiAgICAgIH1cclxuICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcignU2Vzc2lvbiByZXN0b3JlIGZhaWxlZDonLCBlcnJvcik7XHJcbiAgICAgIHJldHVybiBmYWxzZTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGFzeW5jIGF1dGhlbnRpY2F0ZShwcm92aWRlciwgY3JlZGVudGlhbHMpIHtcclxuICAgIGlmIChwcm92aWRlciA9PT0gJ2xvY2FsJykge1xyXG4gICAgICByZXR1cm4gYXdhaXQgdGhpcy5hdXRoZW50aWNhdGVMb2NhbChjcmVkZW50aWFscyk7XHJcbiAgICB9IGVsc2UgaWYgKHByb3ZpZGVyID09PSAnZ29vZ2xlJyB8fCBwcm92aWRlciA9PT0gJ21pY3Jvc29mdCcpIHtcclxuICAgICAgcmV0dXJuIGF3YWl0IHRoaXMuYXV0aGVudGljYXRlT0F1dGgocHJvdmlkZXIpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgdGhyb3cgbmV3IEVycm9yKGBVbnN1cHBvcnRlZCBhdXRoZW50aWNhdGlvbiBwcm92aWRlcjogJHtwcm92aWRlcn1gKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGFzeW5jIGF1dGhlbnRpY2F0ZUxvY2FsKGNyZWRlbnRpYWxzKSB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBjb25maWcgPSBhd2FpdCBsb2FkQ29uZmlnKCk7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7Y29uZmlnLmFwaVVybH0vYXBpL3VzZXIvbG9naW5gLCB7XHJcbiAgICAgICAgbWV0aG9kOiAnUE9TVCcsXHJcbiAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0sXHJcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgICAgZW1haWw6IGNyZWRlbnRpYWxzLmVtYWlsLFxyXG4gICAgICAgICAgcGFzc3dvcmQ6IGNyZWRlbnRpYWxzLnBhc3N3b3JkXHJcbiAgICAgICAgfSlcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xyXG5cclxuICAgICAgaWYgKHJlc3BvbnNlLm9rICYmIChkYXRhLmRhdGE/LnRva2VuIHx8IGRhdGEudG9rZW4pKSB7XHJcbiAgICAgICAgY29uc3QgdG9rZW4gPSBkYXRhLmRhdGE/LnRva2VuIHx8IGRhdGEudG9rZW47XHJcbiAgICAgICAgY29uc3QgdXNlciA9IGRhdGEuZGF0YT8udXNlciB8fCBkYXRhLnVzZXIgfHwgeyBlbWFpbDogY3JlZGVudGlhbHMuZW1haWwgfTtcclxuICAgICAgICBcclxuICAgICAgICB0aGlzLmp3dFRva2VucyA9IHtcclxuICAgICAgICAgIGFjY2Vzc190b2tlbjogdG9rZW4sXHJcbiAgICAgICAgICB0b2tlbl90eXBlOiAnQmVhcmVyJyxcclxuICAgICAgICAgIGV4cGlyZXNfaW46IDI4ODAwLCAvLyA4IGhvdXJzXHJcbiAgICAgICAgICBleHBpcmVzX2F0OiBEYXRlLm5vdygpICsgKDI4ODAwICogMTAwMClcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICB0aGlzLnVzZXJQcm9maWxlID0gdXNlcjtcclxuXHJcbiAgICAgICAgYXdhaXQgdGhpcy5wZXJzaXN0U2Vzc2lvbigpO1xyXG4gICAgICAgIHRoaXMuc2V0dXBUb2tlblJlZnJlc2goKTtcclxuICAgICAgICB0aGlzLnVwZGF0ZUF1dGhCYWRnZSh0cnVlKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSwgdXNlcjogdGhpcy51c2VyUHJvZmlsZSB9O1xyXG4gICAgICB9XHJcblxyXG4gICAgICByZXR1cm4geyBzdWNjZXNzOiBmYWxzZSwgZXJyb3I6IGRhdGEuZXJyb3IgfHwgZGF0YS5tZXNzYWdlIHx8ICdMb2dpbiBmYWlsZWQnIH07XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKCdMb2NhbCBhdXRoZW50aWNhdGlvbiBlcnJvcjonLCBlcnJvcik7XHJcbiAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IGZhbHNlLCBlcnJvcjogZXJyb3IubWVzc2FnZSB8fCAnTmV0d29yayBlcnJvcicgfTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGFzeW5jIGF1dGhlbnRpY2F0ZU9BdXRoKHByb3ZpZGVyKSB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCBzdGF0ZSA9IGNyeXB0by5yYW5kb21VVUlEKCk7XHJcbiAgICAgIGNvbnN0IHJlZGlyZWN0VXJpID0gY2hyb21lLnJ1bnRpbWUuZ2V0VVJMKCdzcmMvYXV0aC9jYWxsYmFjay5odG1sJyk7XHJcblxyXG4gICAgICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoe1xyXG4gICAgICAgIGF1dGhTdGF0ZTogc3RhdGUsXHJcbiAgICAgICAgYXV0aFByb3ZpZGVyOiBwcm92aWRlcixcclxuICAgICAgICBhdXRoVGltZXN0YW1wOiBEYXRlLm5vdygpXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgY29uc3QgY29uZmlnID0gYXdhaXQgbG9hZENvbmZpZygpO1xyXG4gICAgICBjb25zdCBhdXRoVXJsID0gYCR7Y29uZmlnLmFwaVVybH0vYXBpL2F1dGgvJHtwcm92aWRlcn0/c3RhdGU9JHtzdGF0ZX0mcmVkaXJlY3RfdXJpPSR7ZW5jb2RlVVJJQ29tcG9uZW50KHJlZGlyZWN0VXJpKX1gO1xyXG5cclxuICAgICAgY29uc3QgcG9wdXAgPSBhd2FpdCBjaHJvbWUud2luZG93cy5jcmVhdGUoe1xyXG4gICAgICAgIHVybDogYXV0aFVybCxcclxuICAgICAgICB0eXBlOiAncG9wdXAnLFxyXG4gICAgICAgIHdpZHRoOiA2MDAsXHJcbiAgICAgICAgaGVpZ2h0OiA3MDAsXHJcbiAgICAgICAgZm9jdXNlZDogdHJ1ZVxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIHJldHVybiBhd2FpdCB0aGlzLndhaXRGb3JQb3B1cEF1dGhDb21wbGV0aW9uKHBvcHVwLmlkLCBzdGF0ZSk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKGAke3Byb3ZpZGVyfSBhdXRoZW50aWNhdGlvbiBlcnJvcjpgLCBlcnJvcik7XHJcbiAgICAgIHRocm93IGVycm9yO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgd2FpdEZvclBvcHVwQXV0aENvbXBsZXRpb24ocG9wdXBJZCwgZXhwZWN0ZWRTdGF0ZSkge1xyXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgY29uc3QgdGltZW91dCA9IHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgIGNsZWFudXAoKTtcclxuICAgICAgICByZWplY3QobmV3IEVycm9yKCdBdXRoZW50aWNhdGlvbiB0aW1lb3V0JykpO1xyXG4gICAgICB9LCA1ICogNjAgKiAxMDAwKTtcclxuXHJcbiAgICAgIGNvbnN0IG1lc3NhZ2VMaXN0ZW5lciA9IChtZXNzYWdlLCBzZW5kZXIsIHNlbmRSZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKCdbQXV0aFNlcnZpY2VdIE1lc3NhZ2UgcmVjZWl2ZWQ6JywgbWVzc2FnZS50eXBlLCBtZXNzYWdlKTtcclxuICAgICAgICBpZiAobWVzc2FnZS50eXBlID09PSAnT0FVVEhfQ09NUExFVEUnKSB7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZygnW0F1dGhTZXJ2aWNlXSBPQXV0aCBjb21wbGV0ZSBtZXNzYWdlOicsIHsgXHJcbiAgICAgICAgICAgIHN0YXRlOiBtZXNzYWdlLnN0YXRlLCBcclxuICAgICAgICAgICAgZXhwZWN0ZWRTdGF0ZSwgXHJcbiAgICAgICAgICAgIHN1Y2Nlc3M6IG1lc3NhZ2Uuc3VjY2VzcyBcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgaWYgKG1lc3NhZ2Uuc3RhdGUgPT09IGV4cGVjdGVkU3RhdGUgJiYgbWVzc2FnZS5zdWNjZXNzKSB7XHJcbiAgICAgICAgICAgIGNsZWFudXAoKTtcclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIC8vIFdhaXQgYSBiaXQgZm9yIHN0b3JhZ2UgdG8gYmUgd3JpdHRlblxyXG4gICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAgICAgICBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoWydwcml2YWN5cGFsX3Nlc3Npb24nXSwgYXN5bmMgKHJlc3VsdCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ1tBdXRoU2VydmljZV0gUmV0cmlldmVkIHNlc3Npb24gZnJvbSBzdG9yYWdlOicsICEhcmVzdWx0LnByaXZhY3lwYWxfc2Vzc2lvbik7XHJcbiAgICAgICAgICAgICAgICBpZiAocmVzdWx0LnByaXZhY3lwYWxfc2Vzc2lvbikge1xyXG4gICAgICAgICAgICAgICAgICB0aGlzLmp3dFRva2VucyA9IHJlc3VsdC5wcml2YWN5cGFsX3Nlc3Npb24uand0VG9rZW5zO1xyXG4gICAgICAgICAgICAgICAgICB0aGlzLnVzZXJQcm9maWxlID0gcmVzdWx0LnByaXZhY3lwYWxfc2Vzc2lvbi51c2VyUHJvZmlsZTtcclxuICAgICAgICAgICAgICAgICAgdGhpcy5zZXR1cFRva2VuUmVmcmVzaCgpO1xyXG4gICAgICAgICAgICAgICAgICB0aGlzLnVwZGF0ZUF1dGhCYWRnZSh0cnVlKTtcclxuICAgICAgICAgICAgICAgICAgcmVzb2x2ZSh7IHN1Y2Nlc3M6IHRydWUsIHVzZXI6IHRoaXMudXNlclByb2ZpbGUgfSk7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgICAvLyBSZXRyeSBvbmNlIGFmdGVyIGEgc2hvcnQgZGVsYXlcclxuICAgICAgICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KFsncHJpdmFjeXBhbF9zZXNzaW9uJ10sIGFzeW5jIChyZXRyeVJlc3VsdCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgaWYgKHJldHJ5UmVzdWx0LnByaXZhY3lwYWxfc2Vzc2lvbikge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmp3dFRva2VucyA9IHJldHJ5UmVzdWx0LnByaXZhY3lwYWxfc2Vzc2lvbi5qd3RUb2tlbnM7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMudXNlclByb2ZpbGUgPSByZXRyeVJlc3VsdC5wcml2YWN5cGFsX3Nlc3Npb24udXNlclByb2ZpbGU7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc2V0dXBUb2tlblJlZnJlc2goKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy51cGRhdGVBdXRoQmFkZ2UodHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUoeyBzdWNjZXNzOiB0cnVlLCB1c2VyOiB0aGlzLnVzZXJQcm9maWxlIH0pO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmVqZWN0KG5ldyBFcnJvcignT0F1dGggY29tcGxldGVkIGJ1dCBzZXNzaW9uIGRhdGEgbm90IGZvdW5kJykpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgICB9LCA1MDApO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9LCAyMDApO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgY2xlYW51cCgpO1xyXG4gICAgICAgICAgICByZWplY3QobmV3IEVycm9yKCdPQXV0aCBzdGF0ZSBtaXNtYXRjaCBvciBmYWlsZWQnKSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB0cnVlOyAvLyBLZWVwIGNoYW5uZWwgb3BlbiBmb3IgYXN5bmMgcmVzcG9uc2VcclxuICAgICAgfTtcclxuXHJcbiAgICAgIGNvbnN0IHdpbmRvd1JlbW92ZWRMaXN0ZW5lciA9ICh3aW5kb3dJZCkgPT4ge1xyXG4gICAgICAgIGlmICh3aW5kb3dJZCA9PT0gcG9wdXBJZCkge1xyXG4gICAgICAgICAgY29uc29sZS5sb2coJ1tBdXRoU2VydmljZV0gUG9wdXAgd2luZG93IGNsb3NlZDonLCB3aW5kb3dJZCk7XHJcbiAgICAgICAgICAvLyBEb24ndCBpbW1lZGlhdGVseSByZWplY3QgLSBnaXZlIHRpbWUgZm9yIG1lc3NhZ2UgdG8gYXJyaXZlXHJcbiAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICAgICAgLy8gQ2hlY2sgaWYgd2UgYWxyZWFkeSByZXNvbHZlZFxyXG4gICAgICAgICAgICBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoWydwcml2YWN5cGFsX3Nlc3Npb24nXSwgKHJlc3VsdCkgPT4ge1xyXG4gICAgICAgICAgICAgIGlmICghcmVzdWx0LnByaXZhY3lwYWxfc2Vzc2lvbikge1xyXG4gICAgICAgICAgICAgICAgY2xlYW51cCgpO1xyXG4gICAgICAgICAgICAgICAgcmVqZWN0KG5ldyBFcnJvcignQXV0aGVudGljYXRpb24gd2luZG93IGNsb3NlZCcpKTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgfSwgMTAwMCk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9O1xyXG5cclxuICAgICAgY29uc3QgY2xlYW51cCA9ICgpID0+IHtcclxuICAgICAgICBjbGVhclRpbWVvdXQodGltZW91dCk7XHJcbiAgICAgICAgY2hyb21lLnJ1bnRpbWUub25NZXNzYWdlLnJlbW92ZUxpc3RlbmVyKG1lc3NhZ2VMaXN0ZW5lcik7XHJcbiAgICAgICAgY2hyb21lLndpbmRvd3Mub25SZW1vdmVkLnJlbW92ZUxpc3RlbmVyKHdpbmRvd1JlbW92ZWRMaXN0ZW5lcik7XHJcbiAgICAgICAgXHJcbiAgICAgICAgY2hyb21lLndpbmRvd3MuZ2V0KHBvcHVwSWQsICgpID0+IHtcclxuICAgICAgICAgIGlmICghY2hyb21lLnJ1bnRpbWUubGFzdEVycm9yKSB7XHJcbiAgICAgICAgICAgIGNocm9tZS53aW5kb3dzLnJlbW92ZShwb3B1cElkKS5jYXRjaCgoKSA9PiB7fSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH07XHJcblxyXG4gICAgICBjaHJvbWUucnVudGltZS5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIobWVzc2FnZUxpc3RlbmVyKTtcclxuICAgICAgY2hyb21lLndpbmRvd3Mub25SZW1vdmVkLmFkZExpc3RlbmVyKHdpbmRvd1JlbW92ZWRMaXN0ZW5lcik7XHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldEpXVFRva2VuKCkge1xyXG4gICAgaWYgKHRoaXMuand0VG9rZW5zICYmIHRoaXMuand0VG9rZW5zLmV4cGlyZXNfYXQgPiBEYXRlLm5vdygpICsgNjAwMDApIHtcclxuICAgICAgcmV0dXJuIHRoaXMuand0VG9rZW5zO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IHN0b3JhZ2UgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoWydwcml2YWN5cGFsX3Nlc3Npb24nXSk7XHJcbiAgICBpZiAoc3RvcmFnZS5wcml2YWN5cGFsX3Nlc3Npb24/Lmp3dFRva2Vucykge1xyXG4gICAgICB0aGlzLmp3dFRva2VucyA9IHN0b3JhZ2UucHJpdmFjeXBhbF9zZXNzaW9uLmp3dFRva2VucztcclxuICAgICAgaWYgKHRoaXMuand0VG9rZW5zLmV4cGlyZXNfYXQgPiBEYXRlLm5vdygpICsgNjAwMDApIHtcclxuICAgICAgICByZXR1cm4gdGhpcy5qd3RUb2tlbnM7XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBjb25zdCByZWZyZXNoZWQgPSBhd2FpdCB0aGlzLnJlZnJlc2hUb2tlbnMoKTtcclxuICAgIHJldHVybiByZWZyZXNoZWQgfHwgbnVsbDtcclxuICB9XHJcblxyXG4gIGFzeW5jIHJlZnJlc2hUb2tlbnMoKSB7XHJcbiAgICB0cnkge1xyXG4gICAgICAvLyBHZXQgdGhlIGN1cnJlbnQgKHBvc3NpYmx5IGV4cGlyZWQpIHRva2VuXHJcbiAgICAgIGNvbnN0IHN0b3JhZ2UgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoWydwcml2YWN5cGFsX3Nlc3Npb24nXSk7XHJcbiAgICAgIGlmICghc3RvcmFnZS5wcml2YWN5cGFsX3Nlc3Npb24/Lmp3dFRva2Vucz8uYWNjZXNzX3Rva2VuKSB7XHJcbiAgICAgICAgY29uc29sZS53YXJuKCdbQXV0aFNlcnZpY2VdIE5vIHRva2VuIGZvdW5kIGZvciByZWZyZXNoJyk7XHJcbiAgICAgICAgcmV0dXJuIG51bGw7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGNvbnN0IG9sZFRva2VuID0gc3RvcmFnZS5wcml2YWN5cGFsX3Nlc3Npb24uand0VG9rZW5zLmFjY2Vzc190b2tlbjtcclxuICAgICAgY29uc3QgY29uZmlnID0gYXdhaXQgbG9hZENvbmZpZygpO1xyXG5cclxuICAgICAgLy8gQ2FsbCByZWZyZXNoIGVuZHBvaW50XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7Y29uZmlnLmFwaVVybH0vYXBpL3VzZXIvcmVmcmVzaC10b2tlbmAsIHtcclxuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicgfSxcclxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IHRva2VuOiBvbGRUb2tlbiB9KVxyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGlmICghcmVzcG9uc2Uub2spIHtcclxuICAgICAgICBjb25zdCBlcnJvckRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCkuY2F0Y2goKCkgPT4gKHt9KSk7XHJcbiAgICAgICAgY29uc29sZS53YXJuKCdbQXV0aFNlcnZpY2VdIFRva2VuIHJlZnJlc2ggZmFpbGVkOicsIGVycm9yRGF0YS5lcnJvciB8fCByZXNwb25zZS5zdGF0dXNUZXh0KTtcclxuICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgfVxyXG5cclxuICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcclxuICAgICAgY29uc3QgbmV3VG9rZW4gPSBkYXRhLmRhdGE/LnRva2VuIHx8IGRhdGEudG9rZW47XHJcblxyXG4gICAgICBpZiAoIW5ld1Rva2VuKSB7XHJcbiAgICAgICAgY29uc29sZS53YXJuKCdbQXV0aFNlcnZpY2VdIE5vIHRva2VuIGluIHJlZnJlc2ggcmVzcG9uc2UnKTtcclxuICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgICAgfVxyXG5cclxuICAgICAgLy8gVXBkYXRlIHRva2Vuc1xyXG4gICAgICB0aGlzLmp3dFRva2VucyA9IHtcclxuICAgICAgICBhY2Nlc3NfdG9rZW46IG5ld1Rva2VuLFxyXG4gICAgICAgIHRva2VuX3R5cGU6ICdCZWFyZXInLFxyXG4gICAgICAgIGV4cGlyZXNfaW46IDI4ODAwLCAvLyA4IGhvdXJzXHJcbiAgICAgICAgZXhwaXJlc19hdDogRGF0ZS5ub3coKSArICgyODgwMCAqIDEwMDApXHJcbiAgICAgIH07XHJcblxyXG4gICAgICAvLyBQZXJzaXN0IHVwZGF0ZWQgc2Vzc2lvblxyXG4gICAgICBhd2FpdCB0aGlzLnBlcnNpc3RTZXNzaW9uKCk7XHJcbiAgICAgIHRoaXMuc2V0dXBUb2tlblJlZnJlc2goKTtcclxuXHJcbiAgICAgIGNvbnNvbGUubG9nKCdbQXV0aFNlcnZpY2VdIFRva2VuIHJlZnJlc2hlZCBzdWNjZXNzZnVsbHknKTtcclxuICAgICAgcmV0dXJuIHRoaXMuand0VG9rZW5zO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS53YXJuKCdbQXV0aFNlcnZpY2VdIFRva2VuIHJlZnJlc2ggZXJyb3I6JywgZXJyb3IubWVzc2FnZSk7XHJcbiAgICAgIC8vIERvbid0IGxvZ291dCBvbiByZWZyZXNoIGZhaWx1cmUgLSBsZXQgdXNlciBjb250aW51ZSB3aXRoIGV4cGlyZWQgdG9rZW4gdW50aWwgdGhleSB0cnkgdG8gdXNlIGl0XHJcbiAgICAgIHJldHVybiBudWxsO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgc2V0dXBUb2tlblJlZnJlc2goKSB7XHJcbiAgICBpZiAodGhpcy50b2tlblJlZnJlc2hUaW1lcikge1xyXG4gICAgICBjbGVhclRpbWVvdXQodGhpcy50b2tlblJlZnJlc2hUaW1lcik7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKHRoaXMuand0VG9rZW5zPy5leHBpcmVzX2luKSB7XHJcbiAgICAgIC8vIFJlZnJlc2ggMTUgbWludXRlcyBiZWZvcmUgZXhwaXJhdGlvbiAoNyBob3VycyA0NSBtaW51dGVzKVxyXG4gICAgICBjb25zdCByZWZyZXNoVGltZSA9ICh0aGlzLmp3dFRva2Vucy5leHBpcmVzX2luIC0gOTAwKSAqIDEwMDA7XHJcbiAgICAgIHRoaXMudG9rZW5SZWZyZXNoVGltZXIgPSBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICBjb25zb2xlLmxvZygnW0F1dGhTZXJ2aWNlXSBBdXRvLXJlZnJlc2hpbmcgdG9rZW4gYmVmb3JlIGV4cGlyYXRpb24nKTtcclxuICAgICAgICB0aGlzLnJlZnJlc2hUb2tlbnMoKS5jYXRjaChjb25zb2xlLmVycm9yKTtcclxuICAgICAgfSwgcmVmcmVzaFRpbWUpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgcGVyc2lzdFNlc3Npb24oKSB7XHJcbiAgICBjb25zdCBzZXNzaW9uRGF0YSA9IHtcclxuICAgICAgand0VG9rZW5zOiB0aGlzLmp3dFRva2VucyxcclxuICAgICAgdXNlclByb2ZpbGU6IHRoaXMudXNlclByb2ZpbGUsXHJcbiAgICAgIHNlc3Npb25JZDogdGhpcy5zZXNzaW9uSWQgfHwgY3J5cHRvLnJhbmRvbVVVSUQoKSxcclxuICAgICAgc2Vzc2lvblN0YXJ0VGltZTogdGhpcy5zZXNzaW9uU3RhcnRUaW1lIHx8IERhdGUubm93KCksXHJcbiAgICAgIHRpbWVzdGFtcDogRGF0ZS5ub3coKVxyXG4gICAgfTtcclxuXHJcbiAgICBpZiAoIXRoaXMuc2Vzc2lvbklkKSB7XHJcbiAgICAgIHRoaXMuc2Vzc2lvbklkID0gc2Vzc2lvbkRhdGEuc2Vzc2lvbklkO1xyXG4gICAgfVxyXG4gICAgaWYgKCF0aGlzLnNlc3Npb25TdGFydFRpbWUpIHtcclxuICAgICAgdGhpcy5zZXNzaW9uU3RhcnRUaW1lID0gc2Vzc2lvbkRhdGEuc2Vzc2lvblN0YXJ0VGltZTtcclxuICAgIH1cclxuXHJcbiAgICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoe1xyXG4gICAgICBwcml2YWN5cGFsX3Nlc3Npb246IHNlc3Npb25EYXRhXHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldEF1dGhTdGF0dXMoKSB7XHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCB0b2tlbnMgPSBhd2FpdCB0aGlzLmdldEpXVFRva2VuKCk7XHJcbiAgICAgIGlmICh0b2tlbnMgJiYgdG9rZW5zLmV4cGlyZXNfYXQgPiBEYXRlLm5vdygpKSB7XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgIGF1dGhlbnRpY2F0ZWQ6IHRydWUsXHJcbiAgICAgICAgICB1c2VyOiB0aGlzLnVzZXJQcm9maWxlXHJcbiAgICAgICAgfTtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgY29uc29sZS5lcnJvcignQXV0aCBzdGF0dXMgY2hlY2sgZmFpbGVkOicsIGVycm9yKTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4geyBhdXRoZW50aWNhdGVkOiBmYWxzZSB9O1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgbG9nb3V0KCkge1xyXG4gICAgaWYgKHRoaXMudG9rZW5SZWZyZXNoVGltZXIpIHtcclxuICAgICAgY2xlYXJUaW1lb3V0KHRoaXMudG9rZW5SZWZyZXNoVGltZXIpO1xyXG4gICAgICB0aGlzLnRva2VuUmVmcmVzaFRpbWVyID0gbnVsbDtcclxuICAgIH1cclxuXHJcbiAgICB0aGlzLmp3dFRva2VucyA9IG51bGw7XHJcbiAgICB0aGlzLnVzZXJQcm9maWxlID0gbnVsbDtcclxuXHJcbiAgICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5yZW1vdmUoWydwcml2YWN5cGFsX3Nlc3Npb24nLCAnYXV0aFN0YXRlJywgJ2F1dGhQcm92aWRlcicsICdhdXRoVGltZXN0YW1wJ10pO1xyXG4gICAgXHJcbiAgICB0aGlzLnVwZGF0ZUF1dGhCYWRnZShmYWxzZSk7XHJcblxyXG4gICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9O1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgaXNBdXRoZW50aWNhdGVkKCkge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgdG9rZW5zID0gYXdhaXQgdGhpcy5nZXRKV1RUb2tlbigpO1xyXG4gICAgICByZXR1cm4gISF0b2tlbnMgJiYgdG9rZW5zLmV4cGlyZXNfYXQgPiBEYXRlLm5vdygpO1xyXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0VG9rZW4oKSB7XHJcbiAgICBjb25zdCB0b2tlbnMgPSBhd2FpdCB0aGlzLmdldEpXVFRva2VuKCk7XHJcbiAgICByZXR1cm4gdG9rZW5zPy5hY2Nlc3NfdG9rZW4gfHwgbnVsbDtcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldEN1cnJlbnRVc2VyKCkge1xyXG4gICAgcmV0dXJuIHRoaXMudXNlclByb2ZpbGU7XHJcbiAgfVxyXG5cclxuICB1cGRhdGVBdXRoQmFkZ2UoaXNBdXRoZW50aWNhdGVkKSB7XHJcbiAgICB0cnkge1xyXG4gICAgICBpZiAoY2hyb21lLmFjdGlvbj8uc2V0QmFkZ2VUZXh0KSB7XHJcbiAgICAgICAgY2hyb21lLmFjdGlvbi5zZXRCYWRnZVRleHQoeyB0ZXh0OiBpc0F1dGhlbnRpY2F0ZWQgPyAnT04nIDogJ09GRicgfSk7XHJcbiAgICAgICAgY2hyb21lLmFjdGlvbi5zZXRCYWRnZUJhY2tncm91bmRDb2xvcih7IFxyXG4gICAgICAgICAgY29sb3I6IGlzQXV0aGVudGljYXRlZCA/ICcjMTBiOTgxJyA6ICcjZWY0NDQ0JyBcclxuICAgICAgICB9KTtcclxuICAgICAgICBjaHJvbWUuYWN0aW9uLnNldFRpdGxlKHsgXHJcbiAgICAgICAgICB0aXRsZTogaXNBdXRoZW50aWNhdGVkID8gJ1ByaXZhY3lQYWwgLSBBdXRoZW50aWNhdGVkJyA6ICdQcml2YWN5UGFsIC0gTm90IEF1dGhlbnRpY2F0ZWQnIFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmVycm9yKCdGYWlsZWQgdG8gdXBkYXRlIGJhZGdlOicsIGVycm9yKTtcclxuICAgIH1cclxuICB9XHJcbn1cclxuXHJcbmNvbnN0IGF1dGhTZXJ2aWNlID0gbmV3IEF1dGhTZXJ2aWNlKCk7XHJcbmV4cG9ydCBkZWZhdWx0IGF1dGhTZXJ2aWNlO1xyXG5cclxuIiwgIi8qKlxyXG4gKiBQcml2YWN5UGFsIEJyb3dzZXIgRXh0ZW5zaW9uIC0gUG9wdXAgVUkgQ29udHJvbGxlclxyXG4gKiBIYW5kbGVzIHVzZXIgaW50ZXJhY3Rpb25zIGFuZCBkaXNwbGF5cyBleHRlbnNpb24gc3RhdHVzXHJcbiAqL1xyXG5cclxuaW1wb3J0IGF1dGhTZXJ2aWNlIGZyb20gJy4uL2F1dGgvYXV0aC1zZXJ2aWNlLmpzJztcclxuaW1wb3J0IHsgbG9hZENvbmZpZyBhcyBsb2FkRW5kcG9pbnRDb25maWcsIHNhdmVDb25maWcgYXMgc2F2ZUVuZHBvaW50Q29uZmlnLCBERUZBVUxUX0VORFBPSU5UUyB9IGZyb20gJy4uL2NvbmZpZy9jb25maWcuanMnO1xyXG5cclxuLy8gRE9NIEVsZW1lbnRzXHJcbmNvbnN0IGVsZW1lbnRzID0ge1xyXG4gIC8vIEF1dGggdmlld1xyXG4gIGF1dGhWaWV3OiBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnYXV0aFZpZXcnKSxcclxuICBtYWluVmlldzogZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ21haW5WaWV3JyksXHJcbiAgbG9naW5UYWI6IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdsb2dpblRhYicpLFxyXG4gIHNpZ251cFRhYjogZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3NpZ251cFRhYicpLFxyXG4gIGxvZ2luRm9ybTogZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2xvZ2luRm9ybScpLFxyXG4gIHNpZ251cEZvcm06IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdzaWdudXBGb3JtJyksXHJcbiAgbG9naW5FbWFpbDogZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2xvZ2luRW1haWwnKSxcclxuICBsb2dpblBhc3N3b3JkOiBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnbG9naW5QYXNzd29yZCcpLFxyXG4gIGxvZ2luQnRuOiBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnbG9naW5CdG4nKSxcclxuICBzaWdudXBGaXJzdE5hbWU6IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdzaWdudXBGaXJzdE5hbWUnKSxcclxuICBzaWdudXBMYXN0TmFtZTogZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3NpZ251cExhc3ROYW1lJyksXHJcbiAgc2lnbnVwRW1haWw6IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdzaWdudXBFbWFpbCcpLFxyXG4gIHNpZ251cFBhc3N3b3JkOiBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnc2lnbnVwUGFzc3dvcmQnKSxcclxuICBzaWdudXBCdG46IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdzaWdudXBCdG4nKSxcclxuICBnb29nbGVMb2dpbkJ0bjogZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2dvb2dsZUxvZ2luQnRuJyksXHJcbiAgbWljcm9zb2Z0TG9naW5CdG46IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdtaWNyb3NvZnRMb2dpbkJ0bicpLFxyXG4gIGdvb2dsZVNpZ251cEJ0bjogZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2dvb2dsZVNpZ251cEJ0bicpLFxyXG4gIG1pY3Jvc29mdFNpZ251cEJ0bjogZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ21pY3Jvc29mdFNpZ251cEJ0bicpLFxyXG4gIGF1dGhFcnJvcjogZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2F1dGhFcnJvcicpLFxyXG4gIGxvZ291dEJ0bjogZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2xvZ291dEJ0bicpLFxyXG4gIFxyXG4gIC8vIE1haW4gdmlld1xyXG4gIGVuYWJsZWRUb2dnbGU6IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdlbmFibGVkVG9nZ2xlJyksXHJcbiAgc3RhdHVzSW5kaWNhdG9yOiBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnc3RhdHVzSW5kaWNhdG9yJyksXHJcbiAgc3RhdHVzRG90OiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcuc3RhdHVzLWRvdCcpLFxyXG4gIHN0YXR1c1RleHQ6IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJy5zdGF0dXMtdGV4dCcpLFxyXG4gIHRoZW1lVG9nZ2xlQnRuOiBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgndGhlbWVUb2dnbGVCdG4nKSxcclxuICBzZXR0aW5nc0J0bjogZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3NldHRpbmdzQnRuJyksXHJcbiAgYXBwOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcuYXBwJyksXHJcbiAgc2V0dGluZ3NPdmVybGF5OiBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnc2V0dGluZ3NPdmVybGF5JyksXHJcbiAgc2V0dGluZ3NQYW5lbDogZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3NldHRpbmdzUGFuZWwnKSxcclxuICBjbG9zZVNldHRpbmdzQnRuOiBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnY2xvc2VTZXR0aW5nc0J0bicpLFxyXG4gIGFwaVVybDogZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2FwaVVybCcpLFxyXG4gIHVzZXJQb3J0YWxVcmw6IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd1c2VyUG9ydGFsVXJsJyksXHJcbiAgdXNlckVtYWlsOiBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgndXNlckVtYWlsJyksXHJcbiAgc2hvd05vdGlmaWNhdGlvbnM6IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdzaG93Tm90aWZpY2F0aW9ucycpLFxyXG4gIGRlYnVnTW9kZTogZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2RlYnVnTW9kZScpLFxyXG4gIHRlc3RDb25uZWN0aW9uQnRuOiBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgndGVzdENvbm5lY3Rpb25CdG4nKSxcclxuICBzYXZlU2V0dGluZ3NCdG46IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdzYXZlU2V0dGluZ3NCdG4nKSxcclxuICBjb25uZWN0aW9uU3RhdHVzOiBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnY29ubmVjdGlvblN0YXR1cycpLFxyXG4gIHZlcnNpb25OdW1iZXI6IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCd2ZXJzaW9uTnVtYmVyJylcclxufTtcclxuXHJcbi8vIFN0YXRlXHJcbmxldCBjdXJyZW50Q29uZmlnID0ge307XHJcbmxldCBzZXR0aW5nc1BhbmVsVmlzaWJsZSA9IGZhbHNlO1xyXG5sZXQgaXNEYXJrTW9kZSA9IHRydWU7IC8vIERlZmF1bHQgdG8gZGFyayBtb2RlIGxpa2UgcHJvdGVjdGlvbiBwYW5lbFxyXG5sZXQgaXNBdXRoZW50aWNhdGVkID0gZmFsc2U7XHJcblxyXG4vKipcclxuICogSW5pdGlhbGl6ZSBwb3B1cFxyXG4gKi9cclxuYXN5bmMgZnVuY3Rpb24gaW5pdCgpIHtcclxuICAvLyBJbml0aWFsaXplIGF1dGggc2VydmljZVxyXG4gIGF3YWl0IGF1dGhTZXJ2aWNlLmluaXRpYWxpemUoKTtcclxuICBcclxuICAvLyBDaGVjayBhdXRoZW50aWNhdGlvbiBzdGF0dXNcclxuICBjb25zdCBhdXRoU3RhdHVzID0gYXdhaXQgYXV0aFNlcnZpY2UuZ2V0QXV0aFN0YXR1cygpO1xyXG4gIGlzQXV0aGVudGljYXRlZCA9IGF1dGhTdGF0dXMuYXV0aGVudGljYXRlZDtcclxuICBcclxuICAvLyBMb2FkIHZlcnNpb24gZnJvbSBtYW5pZmVzdFxyXG4gIGxvYWRWZXJzaW9uKCk7XHJcbiAgXHJcbiAgLy8gTG9hZCB0aGVtZSBwcmVmZXJlbmNlXHJcbiAgYXdhaXQgbG9hZFRoZW1lKCk7XHJcbiAgXHJcbiAgaWYgKGlzQXV0aGVudGljYXRlZCkge1xyXG4gICAgLy8gU2hvdyBtYWluIHZpZXdcclxuICAgIHNob3dNYWluVmlldygpO1xyXG4gICAgLy8gRGlzcGxheSB1c2VyIGVtYWlsXHJcbiAgICBhd2FpdCBkaXNwbGF5VXNlckVtYWlsKCk7XHJcbiAgICAvLyBMb2FkIGNvbmZpZ3VyYXRpb25cclxuICAgIGF3YWl0IGxvYWRDb25maWcoKTtcclxuICAgIC8vIFNldCB1cCBldmVudCBsaXN0ZW5lcnNcclxuICAgIHNldHVwRXZlbnRMaXN0ZW5lcnMoKTtcclxuICAgIC8vIFVwZGF0ZSBVSVxyXG4gICAgdXBkYXRlVUkoKTtcclxuICB9IGVsc2Uge1xyXG4gICAgLy8gU2hvdyBhdXRoIHZpZXdcclxuICAgIHNob3dBdXRoVmlldygpO1xyXG4gICAgLy8gU2V0IHVwIGF1dGggZXZlbnQgbGlzdGVuZXJzXHJcbiAgICBzZXR1cEF1dGhFdmVudExpc3RlbmVycygpO1xyXG4gIH1cclxufVxyXG5cclxuLyoqXHJcbiAqIExvYWQgdmVyc2lvbiBudW1iZXIgZnJvbSBtYW5pZmVzdFxyXG4gKi9cclxuZnVuY3Rpb24gbG9hZFZlcnNpb24oKSB7XHJcbiAgaWYgKGVsZW1lbnRzLnZlcnNpb25OdW1iZXIpIHtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IG1hbmlmZXN0ID0gY2hyb21lLnJ1bnRpbWUuZ2V0TWFuaWZlc3QoKTtcclxuICAgICAgZWxlbWVudHMudmVyc2lvbk51bWJlci50ZXh0Q29udGVudCA9IGB2JHttYW5pZmVzdC52ZXJzaW9ufWA7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLndhcm4oJ1tQcml2YWN5UGFsXSBDb3VsZCBub3QgbG9hZCB2ZXJzaW9uOicsIGVycm9yKTtcclxuICAgIH1cclxuICB9XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBMb2FkIHRoZW1lIHByZWZlcmVuY2UgZnJvbSBzdG9yYWdlXHJcbiAqL1xyXG5hc3luYyBmdW5jdGlvbiBsb2FkVGhlbWUoKSB7XHJcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XHJcbiAgICBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoWydkYXJrTW9kZSddLCAocmVzdWx0KSA9PiB7XHJcbiAgICAgIGlzRGFya01vZGUgPSByZXN1bHQuZGFya01vZGUgIT09IGZhbHNlOyAvLyBEZWZhdWx0IHRvIGRhcmsgbW9kZVxyXG4gICAgICB1cGRhdGVUaGVtZSgpO1xyXG4gICAgICByZXNvbHZlKCk7XHJcbiAgICB9KTtcclxuICB9KTtcclxufVxyXG5cclxuLyoqXHJcbiAqIFVwZGF0ZSB0aGVtZVxyXG4gKi9cclxuZnVuY3Rpb24gdXBkYXRlVGhlbWUoKSB7XHJcbiAgaWYgKGVsZW1lbnRzLmFwcCkge1xyXG4gICAgaWYgKGlzRGFya01vZGUpIHtcclxuICAgICAgZWxlbWVudHMuYXBwLmNsYXNzTGlzdC5hZGQoJ3BwLWRhcmstbW9kZScpO1xyXG4gICAgICBlbGVtZW50cy5hcHAuY2xhc3NMaXN0LnJlbW92ZSgncHAtbGlnaHQtbW9kZScpO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgZWxlbWVudHMuYXBwLmNsYXNzTGlzdC5hZGQoJ3BwLWxpZ2h0LW1vZGUnKTtcclxuICAgICAgZWxlbWVudHMuYXBwLmNsYXNzTGlzdC5yZW1vdmUoJ3BwLWRhcmstbW9kZScpO1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG5cclxuLyoqXHJcbiAqIExvYWQgY29uZmlndXJhdGlvbiBmcm9tIHN0b3JhZ2VcclxuICovXHJcbmFzeW5jIGZ1bmN0aW9uIGxvYWRDb25maWcoKSB7XHJcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XHJcbiAgICBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZSh7IGFjdGlvbjogJ2dldENvbmZpZycgfSwgYXN5bmMgKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgIGlmIChyZXNwb25zZT8uY29uZmlnKSB7XHJcbiAgICAgICAgY3VycmVudENvbmZpZyA9IHJlc3BvbnNlLmNvbmZpZztcclxuICAgICAgICBcclxuICAgICAgICAvLyBGb3JjZSBwcm9kdWN0aW9uIFVSTHMgaWYgbG9jYWxob3N0IHZhbHVlcyBhcmUgZGV0ZWN0ZWRcclxuICAgICAgICBsZXQgYXBpVXJsID0gY3VycmVudENvbmZpZy5hcGlVcmwgfHwgREVGQVVMVF9FTkRQT0lOVFMuYXBpVXJsO1xyXG4gICAgICAgIGxldCB1c2VyUG9ydGFsVXJsID0gY3VycmVudENvbmZpZy51c2VyUG9ydGFsVXJsIHx8IERFRkFVTFRfRU5EUE9JTlRTLnVzZXJQb3J0YWxVcmw7XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy8gTWlncmF0ZSBmcm9tIGxvY2FsaG9zdCB0byBwcm9kdWN0aW9uIFVSTHNcclxuICAgICAgICBpZiAoYXBpVXJsLmluY2x1ZGVzKCdsb2NhbGhvc3Q6NDIwMjYnKSB8fCBhcGlVcmwuaW5jbHVkZXMoJzEyNy4wLjAuMTo0MjAyNicpKSB7XHJcbiAgICAgICAgICBhcGlVcmwgPSBERUZBVUxUX0VORFBPSU5UUy5hcGlVcmw7XHJcbiAgICAgICAgICAvLyBVcGRhdGUgc3RvcmVkIGNvbmZpZ1xyXG4gICAgICAgICAgYXdhaXQgY2hyb21lLnJ1bnRpbWUuc2VuZE1lc3NhZ2Uoe1xyXG4gICAgICAgICAgICBhY3Rpb246ICd1cGRhdGVDb25maWcnLFxyXG4gICAgICAgICAgICBjb25maWc6IHsgLi4uY3VycmVudENvbmZpZywgYXBpVXJsIH1cclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgICAgICBpZiAodXNlclBvcnRhbFVybC5pbmNsdWRlcygnbG9jYWxob3N0OjUxNzQnKSB8fCB1c2VyUG9ydGFsVXJsLmluY2x1ZGVzKCcxMjcuMC4wLjE6NTE3NCcpKSB7XHJcbiAgICAgICAgICB1c2VyUG9ydGFsVXJsID0gREVGQVVMVF9FTkRQT0lOVFMudXNlclBvcnRhbFVybDtcclxuICAgICAgICAgIC8vIFVwZGF0ZSBzdG9yZWQgY29uZmlnXHJcbiAgICAgICAgICBhd2FpdCBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZSh7XHJcbiAgICAgICAgICAgIGFjdGlvbjogJ3VwZGF0ZUNvbmZpZycsXHJcbiAgICAgICAgICAgIGNvbmZpZzogeyAuLi5jdXJyZW50Q29uZmlnLCB1c2VyUG9ydGFsVXJsIH1cclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgICAgICAvLyBVcGRhdGUgZm9ybSBmaWVsZHNcclxuICAgICAgICBlbGVtZW50cy5lbmFibGVkVG9nZ2xlLmNoZWNrZWQgPSBjdXJyZW50Q29uZmlnLmVuYWJsZWQgIT09IGZhbHNlO1xyXG4gICAgICAgIGVsZW1lbnRzLmFwaVVybC52YWx1ZSA9IGFwaVVybDtcclxuICAgICAgICBpZiAoZWxlbWVudHMudXNlclBvcnRhbFVybCkge1xyXG4gICAgICAgICAgZWxlbWVudHMudXNlclBvcnRhbFVybC52YWx1ZSA9IHVzZXJQb3J0YWxVcmw7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgICAgIC8vIEpXVCB0b2tlbiBpcyBoYW5kbGVkIGF1dG9tYXRpY2FsbHkgdmlhIGF1dGhlbnRpY2F0ZWQgc2Vzc2lvbiAtIG5vIG1hbnVhbCBlbnRyeSBuZWVkZWRcclxuICAgICAgICBcclxuICAgICAgICBlbGVtZW50cy5zaG93Tm90aWZpY2F0aW9ucy5jaGVja2VkID0gY3VycmVudENvbmZpZy5zaG93Tm90aWZpY2F0aW9ucyAhPT0gZmFsc2U7XHJcbiAgICAgICAgZWxlbWVudHMuZGVidWdNb2RlLmNoZWNrZWQgPSBjdXJyZW50Q29uZmlnLmRlYnVnID09PSB0cnVlO1xyXG4gICAgICB9XHJcbiAgICAgIHJlc29sdmUoKTtcclxuICAgIH0pO1xyXG4gIH0pO1xyXG59XHJcblxyXG4vKipcclxuICogRGlzcGxheSB1c2VyIGVtYWlsIGluIHRoZSBoZWFkZXJcclxuICovXHJcbmFzeW5jIGZ1bmN0aW9uIGRpc3BsYXlVc2VyRW1haWwoKSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHNlc3Npb24gPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoWydwcml2YWN5cGFsX3Nlc3Npb24nXSk7XHJcbiAgICBpZiAoc2Vzc2lvbi5wcml2YWN5cGFsX3Nlc3Npb24/LnVzZXJQcm9maWxlPy5lbWFpbCAmJiBlbGVtZW50cy51c2VyRW1haWwpIHtcclxuICAgICAgZWxlbWVudHMudXNlckVtYWlsLnRleHRDb250ZW50ID0gc2Vzc2lvbi5wcml2YWN5cGFsX3Nlc3Npb24udXNlclByb2ZpbGUuZW1haWw7XHJcbiAgICAgIGVsZW1lbnRzLnVzZXJFbWFpbC50aXRsZSA9IHNlc3Npb24ucHJpdmFjeXBhbF9zZXNzaW9uLnVzZXJQcm9maWxlLmVtYWlsO1xyXG4gICAgfSBlbHNlIGlmIChlbGVtZW50cy51c2VyRW1haWwpIHtcclxuICAgICAgZWxlbWVudHMudXNlckVtYWlsLnRleHRDb250ZW50ID0gJyc7XHJcbiAgICAgIGVsZW1lbnRzLnVzZXJFbWFpbC50aXRsZSA9ICcnO1xyXG4gICAgfVxyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKCdbUHJpdmFjeVBhbF0gRmFpbGVkIHRvIGRpc3BsYXkgdXNlciBlbWFpbDonLCBlcnJvcik7XHJcbiAgfVxyXG59XHJcblxyXG5cclxuLyoqXHJcbiAqIFNob3cgYXV0aGVudGljYXRpb24gdmlld1xyXG4gKi9cclxuZnVuY3Rpb24gc2hvd0F1dGhWaWV3KCkge1xyXG4gIGlmIChlbGVtZW50cy5hdXRoVmlldykgZWxlbWVudHMuYXV0aFZpZXcuc3R5bGUuZGlzcGxheSA9ICdibG9jayc7XHJcbiAgaWYgKGVsZW1lbnRzLm1haW5WaWV3KSBlbGVtZW50cy5tYWluVmlldy5zdHlsZS5kaXNwbGF5ID0gJ25vbmUnO1xyXG59XHJcblxyXG4vKipcclxuICogU2hvdyBtYWluIHZpZXdcclxuICovXHJcbmZ1bmN0aW9uIHNob3dNYWluVmlldygpIHtcclxuICBpZiAoZWxlbWVudHMuYXV0aFZpZXcpIGVsZW1lbnRzLmF1dGhWaWV3LnN0eWxlLmRpc3BsYXkgPSAnbm9uZSc7XHJcbiAgaWYgKGVsZW1lbnRzLm1haW5WaWV3KSBlbGVtZW50cy5tYWluVmlldy5zdHlsZS5kaXNwbGF5ID0gJ2Jsb2NrJztcclxufVxyXG5cclxuLyoqXHJcbiAqIFNldHVwIGF1dGhlbnRpY2F0aW9uIGV2ZW50IGxpc3RlbmVyc1xyXG4gKi9cclxuZnVuY3Rpb24gc2V0dXBBdXRoRXZlbnRMaXN0ZW5lcnMoKSB7XHJcbiAgLy8gVGFiIHN3aXRjaGluZ1xyXG4gIGlmIChlbGVtZW50cy5sb2dpblRhYikge1xyXG4gICAgZWxlbWVudHMubG9naW5UYWIuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XHJcbiAgICAgIGVsZW1lbnRzLmxvZ2luVGFiLmNsYXNzTGlzdC5hZGQoJ2FjdGl2ZScpO1xyXG4gICAgICBlbGVtZW50cy5zaWdudXBUYWIuY2xhc3NMaXN0LnJlbW92ZSgnYWN0aXZlJyk7XHJcbiAgICAgIGVsZW1lbnRzLmxvZ2luRm9ybS5zdHlsZS5kaXNwbGF5ID0gJ2Jsb2NrJztcclxuICAgICAgZWxlbWVudHMuc2lnbnVwRm9ybS5zdHlsZS5kaXNwbGF5ID0gJ25vbmUnO1xyXG4gICAgICBoaWRlQXV0aEVycm9yKCk7XHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIGlmIChlbGVtZW50cy5zaWdudXBUYWIpIHtcclxuICAgIGVsZW1lbnRzLnNpZ251cFRhYi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcclxuICAgICAgZWxlbWVudHMuc2lnbnVwVGFiLmNsYXNzTGlzdC5hZGQoJ2FjdGl2ZScpO1xyXG4gICAgICBlbGVtZW50cy5sb2dpblRhYi5jbGFzc0xpc3QucmVtb3ZlKCdhY3RpdmUnKTtcclxuICAgICAgZWxlbWVudHMuc2lnbnVwRm9ybS5zdHlsZS5kaXNwbGF5ID0gJ2Jsb2NrJztcclxuICAgICAgZWxlbWVudHMubG9naW5Gb3JtLnN0eWxlLmRpc3BsYXkgPSAnbm9uZSc7XHJcbiAgICAgIGhpZGVBdXRoRXJyb3IoKTtcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgLy8gTG9naW4gYnV0dG9uXHJcbiAgaWYgKGVsZW1lbnRzLmxvZ2luQnRuKSB7XHJcbiAgICBlbGVtZW50cy5sb2dpbkJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcclxuICAgICAgYXdhaXQgaGFuZGxlTG9naW4oKTtcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgLy8gU2lnbnVwIGJ1dHRvblxyXG4gIGlmIChlbGVtZW50cy5zaWdudXBCdG4pIHtcclxuICAgIGVsZW1lbnRzLnNpZ251cEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcclxuICAgICAgYXdhaXQgaGFuZGxlU2lnbnVwKCk7XHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIC8vIE9BdXRoIGJ1dHRvbnNcclxuICBpZiAoZWxlbWVudHMuZ29vZ2xlTG9naW5CdG4pIHtcclxuICAgIGVsZW1lbnRzLmdvb2dsZUxvZ2luQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4gaGFuZGxlT0F1dGgoJ2dvb2dsZScpKTtcclxuICB9XHJcbiAgaWYgKGVsZW1lbnRzLm1pY3Jvc29mdExvZ2luQnRuKSB7XHJcbiAgICBlbGVtZW50cy5taWNyb3NvZnRMb2dpbkJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IGhhbmRsZU9BdXRoKCdtaWNyb3NvZnQnKSk7XHJcbiAgfVxyXG4gIGlmIChlbGVtZW50cy5nb29nbGVTaWdudXBCdG4pIHtcclxuICAgIGVsZW1lbnRzLmdvb2dsZVNpZ251cEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IGhhbmRsZU9BdXRoKCdnb29nbGUnKSk7XHJcbiAgfVxyXG4gIGlmIChlbGVtZW50cy5taWNyb3NvZnRTaWdudXBCdG4pIHtcclxuICAgIGVsZW1lbnRzLm1pY3Jvc29mdFNpZ251cEJ0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IGhhbmRsZU9BdXRoKCdtaWNyb3NvZnQnKSk7XHJcbiAgfVxyXG5cclxuICAvLyBFbnRlciBrZXkgaGFuZGxlcnNcclxuICBpZiAoZWxlbWVudHMubG9naW5QYXNzd29yZCkge1xyXG4gICAgZWxlbWVudHMubG9naW5QYXNzd29yZC5hZGRFdmVudExpc3RlbmVyKCdrZXlwcmVzcycsIChlKSA9PiB7XHJcbiAgICAgIGlmIChlLmtleSA9PT0gJ0VudGVyJykgaGFuZGxlTG9naW4oKTtcclxuICAgIH0pO1xyXG4gIH1cclxuICBpZiAoZWxlbWVudHMuc2lnbnVwUGFzc3dvcmQpIHtcclxuICAgIGVsZW1lbnRzLnNpZ251cFBhc3N3b3JkLmFkZEV2ZW50TGlzdGVuZXIoJ2tleXByZXNzJywgKGUpID0+IHtcclxuICAgICAgaWYgKGUua2V5ID09PSAnRW50ZXInKSBoYW5kbGVTaWdudXAoKTtcclxuICAgIH0pO1xyXG4gIH1cclxufVxyXG5cclxuLyoqXHJcbiAqIEhhbmRsZSBsb2dpblxyXG4gKi9cclxuYXN5bmMgZnVuY3Rpb24gaGFuZGxlTG9naW4oKSB7XHJcbiAgY29uc3QgZW1haWwgPSBlbGVtZW50cy5sb2dpbkVtYWlsPy52YWx1ZS50cmltKCk7XHJcbiAgY29uc3QgcGFzc3dvcmQgPSBlbGVtZW50cy5sb2dpblBhc3N3b3JkPy52YWx1ZTtcclxuXHJcbiAgaWYgKCFlbWFpbCB8fCAhcGFzc3dvcmQpIHtcclxuICAgIHNob3dBdXRoRXJyb3IoJ1BsZWFzZSBlbnRlciBlbWFpbCBhbmQgcGFzc3dvcmQnKTtcclxuICAgIHJldHVybjtcclxuICB9XHJcblxyXG4gIGVsZW1lbnRzLmxvZ2luQnRuLmRpc2FibGVkID0gdHJ1ZTtcclxuICBlbGVtZW50cy5sb2dpbkJ0bi50ZXh0Q29udGVudCA9ICdTaWduaW5nIGluLi4uJztcclxuICBoaWRlQXV0aEVycm9yKCk7XHJcblxyXG4gIHRyeSB7XHJcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBhdXRoU2VydmljZS5hdXRoZW50aWNhdGUoJ2xvY2FsJywgeyBlbWFpbCwgcGFzc3dvcmQgfSk7XHJcbiAgICBcclxuICAgIGlmIChyZXN1bHQuc3VjY2Vzcykge1xyXG4gICAgICBpc0F1dGhlbnRpY2F0ZWQgPSB0cnVlO1xyXG4gICAgICBzaG93TWFpblZpZXcoKTtcclxuICAgICAgYXdhaXQgbG9hZENvbmZpZygpO1xyXG4gICAgICBzZXR1cEV2ZW50TGlzdGVuZXJzKCk7XHJcbiAgICAgIHVwZGF0ZVVJKCk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzaG93QXV0aEVycm9yKHJlc3VsdC5lcnJvciB8fCAnTG9naW4gZmFpbGVkJyk7XHJcbiAgICB9XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIHNob3dBdXRoRXJyb3IoZXJyb3IubWVzc2FnZSB8fCAnQW4gZXJyb3Igb2NjdXJyZWQnKTtcclxuICB9IGZpbmFsbHkge1xyXG4gICAgZWxlbWVudHMubG9naW5CdG4uZGlzYWJsZWQgPSBmYWxzZTtcclxuICAgIGVsZW1lbnRzLmxvZ2luQnRuLnRleHRDb250ZW50ID0gJ1NpZ24gSW4nO1xyXG4gIH1cclxufVxyXG5cclxuLyoqXHJcbiAqIEhhbmRsZSBzaWdudXBcclxuICovXHJcbmFzeW5jIGZ1bmN0aW9uIGhhbmRsZVNpZ251cCgpIHtcclxuICBjb25zdCBmaXJzdE5hbWUgPSBlbGVtZW50cy5zaWdudXBGaXJzdE5hbWU/LnZhbHVlLnRyaW0oKTtcclxuICBjb25zdCBsYXN0TmFtZSA9IGVsZW1lbnRzLnNpZ251cExhc3ROYW1lPy52YWx1ZS50cmltKCk7XHJcbiAgY29uc3QgZW1haWwgPSBlbGVtZW50cy5zaWdudXBFbWFpbD8udmFsdWUudHJpbSgpO1xyXG4gIGNvbnN0IHBhc3N3b3JkID0gZWxlbWVudHMuc2lnbnVwUGFzc3dvcmQ/LnZhbHVlO1xyXG5cclxuICBpZiAoIWZpcnN0TmFtZSB8fCAhbGFzdE5hbWUgfHwgIWVtYWlsIHx8ICFwYXNzd29yZCkge1xyXG4gICAgc2hvd0F1dGhFcnJvcignUGxlYXNlIGZpbGwgaW4gYWxsIGZpZWxkcycpO1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuXHJcbiAgZWxlbWVudHMuc2lnbnVwQnRuLmRpc2FibGVkID0gdHJ1ZTtcclxuICBlbGVtZW50cy5zaWdudXBCdG4udGV4dENvbnRlbnQgPSAnQ3JlYXRpbmcgYWNjb3VudC4uLic7XHJcbiAgaGlkZUF1dGhFcnJvcigpO1xyXG5cclxuICB0cnkge1xyXG4gICAgLy8gUmVnaXN0ZXIgZmlyc3RcclxuICAgIGNvbnN0IGNvbmZpZyA9IGF3YWl0IGxvYWRFbmRwb2ludENvbmZpZygpO1xyXG4gICAgY29uc3QgcmVnaXN0ZXJSZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke2NvbmZpZy5hcGlVcmx9L2FwaS91c2VyL3JlZ2lzdGVyYCwge1xyXG4gICAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0sXHJcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHsgZmlyc3ROYW1lLCBsYXN0TmFtZSwgZW1haWwsIHBhc3N3b3JkIH0pXHJcbiAgICB9KTtcclxuXHJcbiAgICBjb25zdCByZWdpc3RlckRhdGEgPSBhd2FpdCByZWdpc3RlclJlc3BvbnNlLmpzb24oKTtcclxuXHJcbiAgICBpZiAocmVnaXN0ZXJSZXNwb25zZS5vayAmJiByZWdpc3RlckRhdGEudG9rZW4pIHtcclxuICAgICAgLy8gUmVnaXN0cmF0aW9uIHN1Y2Nlc3NmdWwsIG5vdyBsb2dpblxyXG4gICAgICBjb25zdCBsb2dpblJlc3VsdCA9IGF3YWl0IGF1dGhTZXJ2aWNlLmF1dGhlbnRpY2F0ZSgnbG9jYWwnLCB7IGVtYWlsLCBwYXNzd29yZCB9KTtcclxuICAgICAgXHJcbiAgICAgIGlmIChsb2dpblJlc3VsdC5zdWNjZXNzKSB7XHJcbiAgICAgICAgaXNBdXRoZW50aWNhdGVkID0gdHJ1ZTtcclxuICAgICAgICBzaG93TWFpblZpZXcoKTtcclxuICAgICAgICBhd2FpdCBkaXNwbGF5VXNlckVtYWlsKCk7XHJcbiAgICAgICAgYXdhaXQgbG9hZENvbmZpZygpO1xyXG4gICAgICAgIHNldHVwRXZlbnRMaXN0ZW5lcnMoKTtcclxuICAgICAgICB1cGRhdGVVSSgpO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHNob3dBdXRoRXJyb3IoJ0FjY291bnQgY3JlYXRlZCBidXQgbG9naW4gZmFpbGVkLiBQbGVhc2UgdHJ5IHNpZ25pbmcgaW4uJyk7XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNob3dBdXRoRXJyb3IocmVnaXN0ZXJEYXRhLmVycm9yIHx8ICdSZWdpc3RyYXRpb24gZmFpbGVkJyk7XHJcbiAgICB9XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIHNob3dBdXRoRXJyb3IoZXJyb3IubWVzc2FnZSB8fCAnQW4gZXJyb3Igb2NjdXJyZWQnKTtcclxuICB9IGZpbmFsbHkge1xyXG4gICAgZWxlbWVudHMuc2lnbnVwQnRuLmRpc2FibGVkID0gZmFsc2U7XHJcbiAgICBlbGVtZW50cy5zaWdudXBCdG4udGV4dENvbnRlbnQgPSAnQ3JlYXRlIEFjY291bnQnO1xyXG4gIH1cclxufVxyXG5cclxuLyoqXHJcbiAqIEhhbmRsZSBPQXV0aFxyXG4gKi9cclxuYXN5bmMgZnVuY3Rpb24gaGFuZGxlT0F1dGgocHJvdmlkZXIpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgYnRuID0gcHJvdmlkZXIgPT09ICdnb29nbGUnIFxyXG4gICAgICA/IChlbGVtZW50cy5nb29nbGVMb2dpbkJ0biB8fCBlbGVtZW50cy5nb29nbGVTaWdudXBCdG4pXHJcbiAgICAgIDogKGVsZW1lbnRzLm1pY3Jvc29mdExvZ2luQnRuIHx8IGVsZW1lbnRzLm1pY3Jvc29mdFNpZ251cEJ0bik7XHJcbiAgICBcclxuICAgIGlmIChidG4pIHtcclxuICAgICAgYnRuLmRpc2FibGVkID0gdHJ1ZTtcclxuICAgICAgYnRuLnRleHRDb250ZW50ID0gJ0Nvbm5lY3RpbmcuLi4nO1xyXG4gICAgfVxyXG4gICAgaGlkZUF1dGhFcnJvcigpO1xyXG5cclxuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGF1dGhTZXJ2aWNlLmF1dGhlbnRpY2F0ZShwcm92aWRlcik7XHJcbiAgICBcclxuICAgIGlmIChyZXN1bHQuc3VjY2Vzcykge1xyXG4gICAgICBpc0F1dGhlbnRpY2F0ZWQgPSB0cnVlO1xyXG4gICAgICBzaG93TWFpblZpZXcoKTtcclxuICAgICAgYXdhaXQgZGlzcGxheVVzZXJFbWFpbCgpO1xyXG4gICAgICBhd2FpdCBsb2FkQ29uZmlnKCk7XHJcbiAgICAgIHNldHVwRXZlbnRMaXN0ZW5lcnMoKTtcclxuICAgICAgdXBkYXRlVUkoKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNob3dBdXRoRXJyb3IocmVzdWx0LmVycm9yIHx8ICdBdXRoZW50aWNhdGlvbiBmYWlsZWQnKTtcclxuICAgIH1cclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgc2hvd0F1dGhFcnJvcihlcnJvci5tZXNzYWdlIHx8ICdBbiBlcnJvciBvY2N1cnJlZCcpO1xyXG4gIH0gZmluYWxseSB7XHJcbiAgICBjb25zdCBidG4gPSBwcm92aWRlciA9PT0gJ2dvb2dsZScgXHJcbiAgICAgID8gKGVsZW1lbnRzLmdvb2dsZUxvZ2luQnRuIHx8IGVsZW1lbnRzLmdvb2dsZVNpZ251cEJ0bilcclxuICAgICAgOiAoZWxlbWVudHMubWljcm9zb2Z0TG9naW5CdG4gfHwgZWxlbWVudHMubWljcm9zb2Z0U2lnbnVwQnRuKTtcclxuICAgIGlmIChidG4pIHtcclxuICAgICAgYnRuLmRpc2FibGVkID0gZmFsc2U7XHJcbiAgICAgIGNvbnN0IGlzTG9naW4gPSBlbGVtZW50cy5sb2dpbkZvcm0/LnN0eWxlLmRpc3BsYXkgIT09ICdub25lJztcclxuICAgICAgYnRuLnRleHRDb250ZW50ID0gcHJvdmlkZXIgPT09ICdnb29nbGUnIFxyXG4gICAgICAgID8gKGlzTG9naW4gPyAnQ29udGludWUgd2l0aCBHb29nbGUnIDogJ1NpZ24gdXAgd2l0aCBHb29nbGUnKVxyXG4gICAgICAgIDogKGlzTG9naW4gPyAnQ29udGludWUgd2l0aCBNaWNyb3NvZnQnIDogJ1NpZ24gdXAgd2l0aCBNaWNyb3NvZnQnKTtcclxuICAgIH1cclxuICB9XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBTaG93IGF1dGggZXJyb3JcclxuICovXHJcbmZ1bmN0aW9uIHNob3dBdXRoRXJyb3IobWVzc2FnZSkge1xyXG4gIGlmIChlbGVtZW50cy5hdXRoRXJyb3IpIHtcclxuICAgIGVsZW1lbnRzLmF1dGhFcnJvci50ZXh0Q29udGVudCA9IG1lc3NhZ2U7XHJcbiAgICBlbGVtZW50cy5hdXRoRXJyb3Iuc3R5bGUuZGlzcGxheSA9ICdibG9jayc7XHJcbiAgfVxyXG59XHJcblxyXG4vKipcclxuICogSGlkZSBhdXRoIGVycm9yXHJcbiAqL1xyXG5mdW5jdGlvbiBoaWRlQXV0aEVycm9yKCkge1xyXG4gIGlmIChlbGVtZW50cy5hdXRoRXJyb3IpIHtcclxuICAgIGVsZW1lbnRzLmF1dGhFcnJvci5zdHlsZS5kaXNwbGF5ID0gJ25vbmUnO1xyXG4gIH1cclxufVxyXG5cclxuLyoqXHJcbiAqIFVwZGF0ZSBVSSBiYXNlZCBvbiBjdXJyZW50IHN0YXRlXHJcbiAqL1xyXG5mdW5jdGlvbiB1cGRhdGVVSSgpIHtcclxuICBjb25zdCBpc0VuYWJsZWQgPSBlbGVtZW50cy5lbmFibGVkVG9nZ2xlPy5jaGVja2VkO1xyXG4gIFxyXG4gIC8vIFVwZGF0ZSBzdGF0dXMgaW5kaWNhdG9yXHJcbiAgaWYgKGlzRW5hYmxlZCAmJiBlbGVtZW50cy5zdGF0dXNEb3QpIHtcclxuICAgIGVsZW1lbnRzLnN0YXR1c0RvdC5jbGFzc0xpc3QucmVtb3ZlKCdpbmFjdGl2ZScpO1xyXG4gICAgaWYgKGVsZW1lbnRzLnN0YXR1c1RleHQpIGVsZW1lbnRzLnN0YXR1c1RleHQudGV4dENvbnRlbnQgPSAnUHJvdGVjdGlvbiBBY3RpdmUnO1xyXG4gIH0gZWxzZSBpZiAoZWxlbWVudHMuc3RhdHVzRG90KSB7XHJcbiAgICBlbGVtZW50cy5zdGF0dXNEb3QuY2xhc3NMaXN0LmFkZCgnaW5hY3RpdmUnKTtcclxuICAgIGlmIChlbGVtZW50cy5zdGF0dXNUZXh0KSBlbGVtZW50cy5zdGF0dXNUZXh0LnRleHRDb250ZW50ID0gJ1Byb3RlY3Rpb24gRGlzYWJsZWQnO1xyXG4gIH1cclxufVxyXG5cclxuLyoqXHJcbiAqIFNldHVwIGV2ZW50IGxpc3RlbmVyc1xyXG4gKi9cclxuZnVuY3Rpb24gc2V0dXBFdmVudExpc3RlbmVycygpIHtcclxuICAvLyBMb2dvdXQgYnV0dG9uXHJcbiAgaWYgKGVsZW1lbnRzLmxvZ291dEJ0bikge1xyXG4gICAgZWxlbWVudHMubG9nb3V0QnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgYXN5bmMgKCkgPT4ge1xyXG4gICAgICBhd2FpdCBhdXRoU2VydmljZS5sb2dvdXQoKTtcclxuICAgICAgaXNBdXRoZW50aWNhdGVkID0gZmFsc2U7XHJcbiAgICAgIC8vIENsZWFyIGVtYWlsIGRpc3BsYXlcclxuICAgICAgaWYgKGVsZW1lbnRzLnVzZXJFbWFpbCkge1xyXG4gICAgICAgIGVsZW1lbnRzLnVzZXJFbWFpbC50ZXh0Q29udGVudCA9ICcnO1xyXG4gICAgICAgIGVsZW1lbnRzLnVzZXJFbWFpbC50aXRsZSA9ICcnO1xyXG4gICAgICB9XHJcbiAgICAgIHNob3dBdXRoVmlldygpO1xyXG4gICAgICBzZXR1cEF1dGhFdmVudExpc3RlbmVycygpO1xyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICAvLyBFbmFibGUvRGlzYWJsZSB0b2dnbGUgKGZ1bmN0aW9uYWwgLSBjb250cm9scyBDT05GSUcuZW5hYmxlZCBpbiBpbnRlcmNlcHRvcilcclxuICBpZiAoZWxlbWVudHMuZW5hYmxlZFRvZ2dsZSkge1xyXG4gICAgZWxlbWVudHMuZW5hYmxlZFRvZ2dsZS5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCBhc3luYyAoKSA9PiB7XHJcbiAgICAgIGNvbnN0IGVuYWJsZWQgPSBlbGVtZW50cy5lbmFibGVkVG9nZ2xlLmNoZWNrZWQ7XHJcbiAgICAgIFxyXG4gICAgICBhd2FpdCBzYXZlQ29uZmlnKHsgZW5hYmxlZCB9KTtcclxuICAgICAgdXBkYXRlVUkoKTtcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgLy8gVGhlbWUgdG9nZ2xlIGJ1dHRvblxyXG4gIGVsZW1lbnRzLnRoZW1lVG9nZ2xlQnRuLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xyXG4gICAgaXNEYXJrTW9kZSA9ICFpc0RhcmtNb2RlO1xyXG4gICAgdXBkYXRlVGhlbWUoKTtcclxuICAgIC8vIFNhdmUgcHJlZmVyZW5jZVxyXG4gICAgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgZGFya01vZGU6IGlzRGFya01vZGUgfSk7XHJcbiAgfSk7XHJcblxyXG4gIC8vIFNldHRpbmdzIGJ1dHRvbiAtIHNsaWRlIGRvd24gcGFuZWwgZnJvbSBoZWFkZXJcclxuICBlbGVtZW50cy5zZXR0aW5nc0J0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcclxuICAgIG9wZW5TZXR0aW5nc1BhbmVsKCk7XHJcbiAgfSk7XHJcblxyXG4gIC8vIENsb3NlIHNldHRpbmdzIGJ1dHRvblxyXG4gIGVsZW1lbnRzLmNsb3NlU2V0dGluZ3NCdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XHJcbiAgICBjbG9zZVNldHRpbmdzUGFuZWwoKTtcclxuICB9KTtcclxuXHJcbiAgLy8gQ2xvc2Ugc2V0dGluZ3Mgd2hlbiBjbGlja2luZyBvdmVybGF5XHJcbiAgZWxlbWVudHMuc2V0dGluZ3NPdmVybGF5LmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKGUpID0+IHtcclxuICAgIGlmIChlLnRhcmdldCA9PT0gZWxlbWVudHMuc2V0dGluZ3NPdmVybGF5KSB7XHJcbiAgICAgIGNsb3NlU2V0dGluZ3NQYW5lbCgpO1xyXG4gICAgfVxyXG4gIH0pO1xyXG5cclxuICAvLyBUZXN0IGNvbm5lY3Rpb24gYnV0dG9uXHJcbiAgZWxlbWVudHMudGVzdENvbm5lY3Rpb25CdG4uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBhc3luYyAoKSA9PiB7XHJcbiAgICBhd2FpdCB0ZXN0Q29ubmVjdGlvbigpO1xyXG4gIH0pO1xyXG5cclxuICAvLyBTYXZlIHNldHRpbmdzIGJ1dHRvblxyXG4gIGVsZW1lbnRzLnNhdmVTZXR0aW5nc0J0bi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIGFzeW5jICgpID0+IHtcclxuICAgIGF3YWl0IHNhdmVTZXR0aW5ncygpO1xyXG4gIH0pO1xyXG59XHJcblxyXG4vKipcclxuICogVGVzdCBjb25uZWN0aW9uIHRvIFByaXZhY3lQYWwgQVBJXHJcbiAqL1xyXG5hc3luYyBmdW5jdGlvbiB0ZXN0Q29ubmVjdGlvbigpIHtcclxuICBjb25zdCBhcGlVcmwgPSBlbGVtZW50cy5hcGlVcmwudmFsdWUudHJpbSgpO1xyXG4gIFxyXG4gIGlmICghYXBpVXJsKSB7XHJcbiAgICBzaG93Q29ubmVjdGlvblN0YXR1cygnUGxlYXNlIGVudGVyIEFQSSBVUkwnLCAnZXJyb3InKTtcclxuICAgIHJldHVybjtcclxuICB9XHJcblxyXG4gIC8vIEdldCBKV1QgdG9rZW4gZnJvbSBhdXRoZW50aWNhdGVkIHNlc3Npb25cclxuICBjb25zdCBzZXNzaW9uID0gYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KFsncHJpdmFjeXBhbF9zZXNzaW9uJ10pO1xyXG4gIGxldCBhcGlLZXkgPSBudWxsO1xyXG4gIFxyXG4gIGlmIChzZXNzaW9uLnByaXZhY3lwYWxfc2Vzc2lvbj8uand0VG9rZW5zPy5hY2Nlc3NfdG9rZW4pIHtcclxuICAgIGNvbnN0IHRva2VucyA9IHNlc3Npb24ucHJpdmFjeXBhbF9zZXNzaW9uLmp3dFRva2VucztcclxuICAgIGlmICh0b2tlbnMuZXhwaXJlc19hdCAmJiB0b2tlbnMuZXhwaXJlc19hdCA+IERhdGUubm93KCkpIHtcclxuICAgICAgYXBpS2V5ID0gdG9rZW5zLmFjY2Vzc190b2tlbjtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNob3dDb25uZWN0aW9uU3RhdHVzKCdUb2tlbiBleHBpcmVkIC0gcGxlYXNlIHNpZ24gaW4gYWdhaW4nLCAnZXJyb3InKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gIH0gZWxzZSB7XHJcbiAgICBzaG93Q29ubmVjdGlvblN0YXR1cygnTm90IGF1dGhlbnRpY2F0ZWQgLSBwbGVhc2Ugc2lnbiBpbicsICdlcnJvcicpO1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuXHJcbiAgZWxlbWVudHMudGVzdENvbm5lY3Rpb25CdG4udGV4dENvbnRlbnQgPSAnVGVzdGluZy4uLic7XHJcbiAgZWxlbWVudHMudGVzdENvbm5lY3Rpb25CdG4uZGlzYWJsZWQgPSB0cnVlO1xyXG5cclxuICB0cnkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xyXG4gICAgICBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZShcclxuICAgICAgICB7IFxyXG4gICAgICAgICAgYWN0aW9uOiAndGVzdENvbm5lY3Rpb24nLCBcclxuICAgICAgICAgIGFwaVVybCwgXHJcbiAgICAgICAgICBhcGlLZXkgXHJcbiAgICAgICAgfSxcclxuICAgICAgICByZXNvbHZlXHJcbiAgICAgICk7XHJcbiAgICB9KTtcclxuXHJcbiAgICBpZiAocmVzcG9uc2Uuc3VjY2Vzcykge1xyXG4gICAgICBzaG93Q29ubmVjdGlvblN0YXR1cygnXHUyNzEzIENvbm5lY3RlZCB0byBQcml2YWN5UGFsIEFQSScsICdzdWNjZXNzJyk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzaG93Q29ubmVjdGlvblN0YXR1cyhgXHUyNzE3ICR7cmVzcG9uc2UuZXJyb3J9YCwgJ2Vycm9yJyk7XHJcbiAgICB9XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIHNob3dDb25uZWN0aW9uU3RhdHVzKGBcdTI3MTcgQ29ubmVjdGlvbiBmYWlsZWQ6ICR7ZXJyb3IubWVzc2FnZX1gLCAnZXJyb3InKTtcclxuICB9IGZpbmFsbHkge1xyXG4gICAgZWxlbWVudHMudGVzdENvbm5lY3Rpb25CdG4udGV4dENvbnRlbnQgPSAnVGVzdCBDb25uZWN0aW9uJztcclxuICAgIGVsZW1lbnRzLnRlc3RDb25uZWN0aW9uQnRuLmRpc2FibGVkID0gZmFsc2U7XHJcbiAgfVxyXG59XHJcblxyXG4vKipcclxuICogU2F2ZSBzZXR0aW5nc1xyXG4gKi9cclxuYXN5bmMgZnVuY3Rpb24gc2F2ZVNldHRpbmdzKCkge1xyXG4gIGNvbnN0IGNvbmZpZyA9IHtcclxuICAgIGFwaVVybDogZWxlbWVudHMuYXBpVXJsLnZhbHVlLnRyaW0oKSxcclxuICAgIHVzZXJQb3J0YWxVcmw6IGVsZW1lbnRzLnVzZXJQb3J0YWxVcmw/LnZhbHVlLnRyaW0oKSB8fCBERUZBVUxUX0VORFBPSU5UUy51c2VyUG9ydGFsVXJsLFxyXG4gICAgLy8gRG9uJ3Qgc2F2ZSBhcGlLZXkgLSBpdCBjb21lcyBmcm9tIGF1dGhlbnRpY2F0ZWQgc2Vzc2lvblxyXG4gICAgc2hvd05vdGlmaWNhdGlvbnM6IGVsZW1lbnRzLnNob3dOb3RpZmljYXRpb25zLmNoZWNrZWQsXHJcbiAgICBkZWJ1ZzogZWxlbWVudHMuZGVidWdNb2RlLmNoZWNrZWRcclxuICB9O1xyXG4gIFxyXG4gIC8vIFNhdmUgdG8gY29uZmlnIHN5c3RlbSAoZW5kcG9pbnRzKVxyXG4gIGF3YWl0IHNhdmVFbmRwb2ludENvbmZpZyh7XHJcbiAgICBhcGlVcmw6IGNvbmZpZy5hcGlVcmwsXHJcbiAgICB1c2VyUG9ydGFsVXJsOiBjb25maWcudXNlclBvcnRhbFVybFxyXG4gIH0pO1xyXG5cclxuICAvLyBTYXZlIGZ1bGwgY29uZmlnIHRvIHN0b3JhZ2UgKGV4Y2x1ZGVzIGFwaUtleSAtIGl0J3MgZnJvbSBhdXRoZW50aWNhdGlvbilcclxuICBhd2FpdCBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xyXG4gICAgY2hyb21lLnJ1bnRpbWUuc2VuZE1lc3NhZ2Uoe1xyXG4gICAgICBhY3Rpb246ICd1cGRhdGVDb25maWcnLFxyXG4gICAgICBjb25maWc6IGNvbmZpZ1xyXG4gICAgfSwgcmVzb2x2ZSk7XHJcbiAgfSk7XHJcbiAgc2hvd0Nvbm5lY3Rpb25TdGF0dXMoJ1x1MjcxMyBTZXR0aW5ncyBzYXZlZCBzdWNjZXNzZnVsbHknLCAnc3VjY2VzcycpO1xyXG4gIFxyXG4gIC8vIENsb3NlIHNldHRpbmdzIHBhbmVsIGFmdGVyIGEgYnJpZWYgZGVsYXlcclxuICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgIGVsZW1lbnRzLmNvbm5lY3Rpb25TdGF0dXMuc3R5bGUuZGlzcGxheSA9ICdub25lJztcclxuICAgIGNsb3NlU2V0dGluZ3NQYW5lbCgpO1xyXG4gIH0sIDE1MDApO1xyXG59XHJcblxyXG4vKipcclxuICogT3BlbiBzZXR0aW5ncyBwYW5lbFxyXG4gKi9cclxuZnVuY3Rpb24gb3BlblNldHRpbmdzUGFuZWwoKSB7XHJcbiAgc2V0dGluZ3NQYW5lbFZpc2libGUgPSB0cnVlO1xyXG4gIGVsZW1lbnRzLnNldHRpbmdzT3ZlcmxheS5zdHlsZS5kaXNwbGF5ID0gJ2Jsb2NrJztcclxuICAvLyBUcmlnZ2VyIHNsaWRlIGRvd24gYW5pbWF0aW9uXHJcbiAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICBlbGVtZW50cy5zZXR0aW5nc092ZXJsYXkuY2xhc3NMaXN0LmFkZCgndmlzaWJsZScpO1xyXG4gIH0sIDEwKTtcclxufVxyXG5cclxuLyoqXHJcbiAqIENsb3NlIHNldHRpbmdzIHBhbmVsXHJcbiAqL1xyXG5mdW5jdGlvbiBjbG9zZVNldHRpbmdzUGFuZWwoKSB7XHJcbiAgc2V0dGluZ3NQYW5lbFZpc2libGUgPSBmYWxzZTtcclxuICBlbGVtZW50cy5zZXR0aW5nc092ZXJsYXkuY2xhc3NMaXN0LnJlbW92ZSgndmlzaWJsZScpO1xyXG4gIC8vIEhpZGUgYWZ0ZXIgYW5pbWF0aW9uXHJcbiAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICBlbGVtZW50cy5zZXR0aW5nc092ZXJsYXkuc3R5bGUuZGlzcGxheSA9ICdub25lJztcclxuICB9LCAzMDApO1xyXG59XHJcblxyXG4vKipcclxuICogU2F2ZSBjb25maWd1cmF0aW9uIHRvIHN0b3JhZ2VcclxuICovXHJcbmFzeW5jIGZ1bmN0aW9uIHNhdmVDb25maWcoY29uZmlnKSB7XHJcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XHJcbiAgICBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZShcclxuICAgICAgeyBhY3Rpb246ICd1cGRhdGVDb25maWcnLCBjb25maWcgfSxcclxuICAgICAgKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgaWYgKHJlc3BvbnNlPy5zdWNjZXNzKSB7XHJcbiAgICAgICAgICBjdXJyZW50Q29uZmlnID0geyAuLi5jdXJyZW50Q29uZmlnLCAuLi5jb25maWcgfTtcclxuICAgICAgICB9XHJcbiAgICAgICAgcmVzb2x2ZSgpO1xyXG4gICAgICB9XHJcbiAgICApO1xyXG4gIH0pO1xyXG59XHJcblxyXG5cclxuLyoqXHJcbiAqIFNob3cgY29ubmVjdGlvbiBzdGF0dXNcclxuICovXHJcbmZ1bmN0aW9uIHNob3dDb25uZWN0aW9uU3RhdHVzKG1lc3NhZ2UsIHR5cGUpIHtcclxuICBlbGVtZW50cy5jb25uZWN0aW9uU3RhdHVzLnRleHRDb250ZW50ID0gbWVzc2FnZTtcclxuICBlbGVtZW50cy5jb25uZWN0aW9uU3RhdHVzLmNsYXNzTmFtZSA9IGBjb25uZWN0aW9uLXN0YXR1cyAke3R5cGV9YDtcclxuICBlbGVtZW50cy5jb25uZWN0aW9uU3RhdHVzLnN0eWxlLmRpc3BsYXkgPSAnYmxvY2snO1xyXG59XHJcblxyXG4vLyBJbml0aWFsaXplIHBvcHVwIHdoZW4gRE9NIGlzIHJlYWR5XHJcbmlmIChkb2N1bWVudC5yZWFkeVN0YXRlID09PSAnbG9hZGluZycpIHtcclxuICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdET01Db250ZW50TG9hZGVkJywgaW5pdCk7XHJcbn0gZWxzZSB7XHJcbiAgaW5pdCgpO1xyXG59XHJcbiJdLAogICJtYXBwaW5ncyI6ICI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBV08sTUFBTSxvQkFBb0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUkvQixRQUFRO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFLUixlQUFlO0FBQUEsRUFDakI7QUFNQSxpQkFBc0IsYUFBYTtBQUNqQyxRQUFJO0FBQ0YsWUFBTSxTQUFTLE1BQU0sT0FBTyxRQUFRLE1BQU0sSUFBSSxDQUFDLFVBQVUsZUFBZSxDQUFDO0FBQ3pFLGFBQU87QUFBQSxRQUNMLFFBQVEsT0FBTyxVQUFVLGtCQUFrQjtBQUFBLFFBQzNDLGVBQWUsT0FBTyxpQkFBaUIsa0JBQWtCO0FBQUEsTUFDM0Q7QUFBQSxJQUNGLFNBQVMsT0FBTztBQUNkLGNBQVEsS0FBSyxvRUFBb0UsS0FBSztBQUN0RixhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0Y7QUFLQSxpQkFBc0IsV0FBVyxRQUFRO0FBQ3ZDLFFBQUk7QUFDRixZQUFNLE9BQU8sUUFBUSxNQUFNLElBQUk7QUFBQSxRQUM3QixRQUFRLE9BQU87QUFBQSxRQUNmLGVBQWUsT0FBTztBQUFBLE1BQ3hCLENBQUM7QUFDRCxhQUFPO0FBQUEsSUFDVCxTQUFTLE9BQU87QUFDZCxjQUFRLE1BQU0sdUNBQXVDLEtBQUs7QUFDMUQsYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGOzs7QUMvQ0EsTUFBTSxjQUFOLE1BQWtCO0FBQUEsSUFDaEIsY0FBYztBQUNaLFdBQUssWUFBWTtBQUNqQixXQUFLLGNBQWM7QUFDbkIsV0FBSyxvQkFBb0I7QUFBQSxJQUMzQjtBQUFBLElBRUEsTUFBTSxhQUFhO0FBQ2pCLFlBQU0sS0FBSyxlQUFlO0FBQUEsSUFDNUI7QUFBQSxJQUVBLE1BQU0saUJBQWlCO0FBQ3JCLFVBQUk7QUFDRixjQUFNLFVBQVUsTUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLENBQUMsb0JBQW9CLENBQUM7QUFDckUsWUFBSSxRQUFRLG9CQUFvQixXQUFXO0FBQ3pDLGVBQUssWUFBWSxRQUFRLG1CQUFtQjtBQUM1QyxlQUFLLGNBQWMsUUFBUSxtQkFBbUI7QUFFOUMsY0FBSSxLQUFLLFVBQVUsYUFBYSxLQUFLLElBQUksR0FBRztBQUMxQyxpQkFBSyxrQkFBa0I7QUFDdkIsbUJBQU87QUFBQSxVQUNUO0FBRUEsZ0JBQU0sWUFBWSxNQUFNLEtBQUssY0FBYztBQUMzQyxpQkFBTyxDQUFDLENBQUM7QUFBQSxRQUNYO0FBQ0EsZUFBTztBQUFBLE1BQ1QsU0FBUyxPQUFPO0FBQ2QsZ0JBQVEsTUFBTSwyQkFBMkIsS0FBSztBQUM5QyxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFBQSxJQUVBLE1BQU0sYUFBYSxVQUFVLGFBQWE7QUFDeEMsVUFBSSxhQUFhLFNBQVM7QUFDeEIsZUFBTyxNQUFNLEtBQUssa0JBQWtCLFdBQVc7QUFBQSxNQUNqRCxXQUFXLGFBQWEsWUFBWSxhQUFhLGFBQWE7QUFDNUQsZUFBTyxNQUFNLEtBQUssa0JBQWtCLFFBQVE7QUFBQSxNQUM5QyxPQUFPO0FBQ0wsY0FBTSxJQUFJLE1BQU0sd0NBQXdDLFFBQVEsRUFBRTtBQUFBLE1BQ3BFO0FBQUEsSUFDRjtBQUFBLElBRUEsTUFBTSxrQkFBa0IsYUFBYTtBQUNuQyxVQUFJO0FBQ0YsY0FBTSxTQUFTLE1BQU0sV0FBVztBQUNoQyxjQUFNLFdBQVcsTUFBTSxNQUFNLEdBQUcsT0FBTyxNQUFNLG1CQUFtQjtBQUFBLFVBQzlELFFBQVE7QUFBQSxVQUNSLFNBQVMsRUFBRSxnQkFBZ0IsbUJBQW1CO0FBQUEsVUFDOUMsTUFBTSxLQUFLLFVBQVU7QUFBQSxZQUNuQixPQUFPLFlBQVk7QUFBQSxZQUNuQixVQUFVLFlBQVk7QUFBQSxVQUN4QixDQUFDO0FBQUEsUUFDSCxDQUFDO0FBRUQsY0FBTSxPQUFPLE1BQU0sU0FBUyxLQUFLO0FBRWpDLFlBQUksU0FBUyxPQUFPLEtBQUssTUFBTSxTQUFTLEtBQUssUUFBUTtBQUNuRCxnQkFBTSxRQUFRLEtBQUssTUFBTSxTQUFTLEtBQUs7QUFDdkMsZ0JBQU0sT0FBTyxLQUFLLE1BQU0sUUFBUSxLQUFLLFFBQVEsRUFBRSxPQUFPLFlBQVksTUFBTTtBQUV4RSxlQUFLLFlBQVk7QUFBQSxZQUNmLGNBQWM7QUFBQSxZQUNkLFlBQVk7QUFBQSxZQUNaLFlBQVk7QUFBQTtBQUFBLFlBQ1osWUFBWSxLQUFLLElBQUksSUFBSyxRQUFRO0FBQUEsVUFDcEM7QUFFQSxlQUFLLGNBQWM7QUFFbkIsZ0JBQU0sS0FBSyxlQUFlO0FBQzFCLGVBQUssa0JBQWtCO0FBQ3ZCLGVBQUssZ0JBQWdCLElBQUk7QUFFekIsaUJBQU8sRUFBRSxTQUFTLE1BQU0sTUFBTSxLQUFLLFlBQVk7QUFBQSxRQUNqRDtBQUVBLGVBQU8sRUFBRSxTQUFTLE9BQU8sT0FBTyxLQUFLLFNBQVMsS0FBSyxXQUFXLGVBQWU7QUFBQSxNQUMvRSxTQUFTLE9BQU87QUFDZCxnQkFBUSxNQUFNLCtCQUErQixLQUFLO0FBQ2xELGVBQU8sRUFBRSxTQUFTLE9BQU8sT0FBTyxNQUFNLFdBQVcsZ0JBQWdCO0FBQUEsTUFDbkU7QUFBQSxJQUNGO0FBQUEsSUFFQSxNQUFNLGtCQUFrQixVQUFVO0FBQ2hDLFVBQUk7QUFDRixjQUFNLFFBQVEsT0FBTyxXQUFXO0FBQ2hDLGNBQU0sY0FBYyxPQUFPLFFBQVEsT0FBTyx3QkFBd0I7QUFFbEUsY0FBTSxPQUFPLFFBQVEsTUFBTSxJQUFJO0FBQUEsVUFDN0IsV0FBVztBQUFBLFVBQ1gsY0FBYztBQUFBLFVBQ2QsZUFBZSxLQUFLLElBQUk7QUFBQSxRQUMxQixDQUFDO0FBRUQsY0FBTSxTQUFTLE1BQU0sV0FBVztBQUNoQyxjQUFNLFVBQVUsR0FBRyxPQUFPLE1BQU0sYUFBYSxRQUFRLFVBQVUsS0FBSyxpQkFBaUIsbUJBQW1CLFdBQVcsQ0FBQztBQUVwSCxjQUFNLFFBQVEsTUFBTSxPQUFPLFFBQVEsT0FBTztBQUFBLFVBQ3hDLEtBQUs7QUFBQSxVQUNMLE1BQU07QUFBQSxVQUNOLE9BQU87QUFBQSxVQUNQLFFBQVE7QUFBQSxVQUNSLFNBQVM7QUFBQSxRQUNYLENBQUM7QUFFRCxlQUFPLE1BQU0sS0FBSywyQkFBMkIsTUFBTSxJQUFJLEtBQUs7QUFBQSxNQUM5RCxTQUFTLE9BQU87QUFDZCxnQkFBUSxNQUFNLEdBQUcsUUFBUSwwQkFBMEIsS0FBSztBQUN4RCxjQUFNO0FBQUEsTUFDUjtBQUFBLElBQ0Y7QUFBQSxJQUVBLE1BQU0sMkJBQTJCLFNBQVMsZUFBZTtBQUN2RCxhQUFPLElBQUksUUFBUSxDQUFDLFNBQVMsV0FBVztBQUN0QyxjQUFNLFVBQVUsV0FBVyxNQUFNO0FBQy9CLGtCQUFRO0FBQ1IsaUJBQU8sSUFBSSxNQUFNLHdCQUF3QixDQUFDO0FBQUEsUUFDNUMsR0FBRyxJQUFJLEtBQUssR0FBSTtBQUVoQixjQUFNLGtCQUFrQixDQUFDLFNBQVMsUUFBUSxpQkFBaUI7QUFDekQsa0JBQVEsSUFBSSxtQ0FBbUMsUUFBUSxNQUFNLE9BQU87QUFDcEUsY0FBSSxRQUFRLFNBQVMsa0JBQWtCO0FBQ3JDLG9CQUFRLElBQUkseUNBQXlDO0FBQUEsY0FDbkQsT0FBTyxRQUFRO0FBQUEsY0FDZjtBQUFBLGNBQ0EsU0FBUyxRQUFRO0FBQUEsWUFDbkIsQ0FBQztBQUNELGdCQUFJLFFBQVEsVUFBVSxpQkFBaUIsUUFBUSxTQUFTO0FBQ3RELHNCQUFRO0FBR1IseUJBQVcsTUFBTTtBQUNmLHVCQUFPLFFBQVEsTUFBTSxJQUFJLENBQUMsb0JBQW9CLEdBQUcsT0FBTyxXQUFXO0FBQ2pFLDBCQUFRLElBQUksaURBQWlELENBQUMsQ0FBQyxPQUFPLGtCQUFrQjtBQUN4RixzQkFBSSxPQUFPLG9CQUFvQjtBQUM3Qix5QkFBSyxZQUFZLE9BQU8sbUJBQW1CO0FBQzNDLHlCQUFLLGNBQWMsT0FBTyxtQkFBbUI7QUFDN0MseUJBQUssa0JBQWtCO0FBQ3ZCLHlCQUFLLGdCQUFnQixJQUFJO0FBQ3pCLDRCQUFRLEVBQUUsU0FBUyxNQUFNLE1BQU0sS0FBSyxZQUFZLENBQUM7QUFBQSxrQkFDbkQsT0FBTztBQUVMLCtCQUFXLE1BQU07QUFDZiw2QkFBTyxRQUFRLE1BQU0sSUFBSSxDQUFDLG9CQUFvQixHQUFHLE9BQU8sZ0JBQWdCO0FBQ3RFLDRCQUFJLFlBQVksb0JBQW9CO0FBQ2xDLCtCQUFLLFlBQVksWUFBWSxtQkFBbUI7QUFDaEQsK0JBQUssY0FBYyxZQUFZLG1CQUFtQjtBQUNsRCwrQkFBSyxrQkFBa0I7QUFDdkIsK0JBQUssZ0JBQWdCLElBQUk7QUFDekIsa0NBQVEsRUFBRSxTQUFTLE1BQU0sTUFBTSxLQUFLLFlBQVksQ0FBQztBQUFBLHdCQUNuRCxPQUFPO0FBQ0wsaUNBQU8sSUFBSSxNQUFNLDRDQUE0QyxDQUFDO0FBQUEsd0JBQ2hFO0FBQUEsc0JBQ0YsQ0FBQztBQUFBLG9CQUNILEdBQUcsR0FBRztBQUFBLGtCQUNSO0FBQUEsZ0JBQ0YsQ0FBQztBQUFBLGNBQ0gsR0FBRyxHQUFHO0FBQUEsWUFDUixPQUFPO0FBQ0wsc0JBQVE7QUFDUixxQkFBTyxJQUFJLE1BQU0sZ0NBQWdDLENBQUM7QUFBQSxZQUNwRDtBQUFBLFVBQ0Y7QUFDQSxpQkFBTztBQUFBLFFBQ1Q7QUFFQSxjQUFNLHdCQUF3QixDQUFDLGFBQWE7QUFDMUMsY0FBSSxhQUFhLFNBQVM7QUFDeEIsb0JBQVEsSUFBSSxzQ0FBc0MsUUFBUTtBQUUxRCx1QkFBVyxNQUFNO0FBRWYscUJBQU8sUUFBUSxNQUFNLElBQUksQ0FBQyxvQkFBb0IsR0FBRyxDQUFDLFdBQVc7QUFDM0Qsb0JBQUksQ0FBQyxPQUFPLG9CQUFvQjtBQUM5QiwwQkFBUTtBQUNSLHlCQUFPLElBQUksTUFBTSw4QkFBOEIsQ0FBQztBQUFBLGdCQUNsRDtBQUFBLGNBQ0YsQ0FBQztBQUFBLFlBQ0gsR0FBRyxHQUFJO0FBQUEsVUFDVDtBQUFBLFFBQ0Y7QUFFQSxjQUFNLFVBQVUsTUFBTTtBQUNwQix1QkFBYSxPQUFPO0FBQ3BCLGlCQUFPLFFBQVEsVUFBVSxlQUFlLGVBQWU7QUFDdkQsaUJBQU8sUUFBUSxVQUFVLGVBQWUscUJBQXFCO0FBRTdELGlCQUFPLFFBQVEsSUFBSSxTQUFTLE1BQU07QUFDaEMsZ0JBQUksQ0FBQyxPQUFPLFFBQVEsV0FBVztBQUM3QixxQkFBTyxRQUFRLE9BQU8sT0FBTyxFQUFFLE1BQU0sTUFBTTtBQUFBLGNBQUMsQ0FBQztBQUFBLFlBQy9DO0FBQUEsVUFDRixDQUFDO0FBQUEsUUFDSDtBQUVBLGVBQU8sUUFBUSxVQUFVLFlBQVksZUFBZTtBQUNwRCxlQUFPLFFBQVEsVUFBVSxZQUFZLHFCQUFxQjtBQUFBLE1BQzVELENBQUM7QUFBQSxJQUNIO0FBQUEsSUFFQSxNQUFNLGNBQWM7QUFDbEIsVUFBSSxLQUFLLGFBQWEsS0FBSyxVQUFVLGFBQWEsS0FBSyxJQUFJLElBQUksS0FBTztBQUNwRSxlQUFPLEtBQUs7QUFBQSxNQUNkO0FBRUEsWUFBTSxVQUFVLE1BQU0sT0FBTyxRQUFRLE1BQU0sSUFBSSxDQUFDLG9CQUFvQixDQUFDO0FBQ3JFLFVBQUksUUFBUSxvQkFBb0IsV0FBVztBQUN6QyxhQUFLLFlBQVksUUFBUSxtQkFBbUI7QUFDNUMsWUFBSSxLQUFLLFVBQVUsYUFBYSxLQUFLLElBQUksSUFBSSxLQUFPO0FBQ2xELGlCQUFPLEtBQUs7QUFBQSxRQUNkO0FBQUEsTUFDRjtBQUVBLFlBQU0sWUFBWSxNQUFNLEtBQUssY0FBYztBQUMzQyxhQUFPLGFBQWE7QUFBQSxJQUN0QjtBQUFBLElBRUEsTUFBTSxnQkFBZ0I7QUFDcEIsVUFBSTtBQUVGLGNBQU0sVUFBVSxNQUFNLE9BQU8sUUFBUSxNQUFNLElBQUksQ0FBQyxvQkFBb0IsQ0FBQztBQUNyRSxZQUFJLENBQUMsUUFBUSxvQkFBb0IsV0FBVyxjQUFjO0FBQ3hELGtCQUFRLEtBQUssMENBQTBDO0FBQ3ZELGlCQUFPO0FBQUEsUUFDVDtBQUVBLGNBQU0sV0FBVyxRQUFRLG1CQUFtQixVQUFVO0FBQ3RELGNBQU0sU0FBUyxNQUFNLFdBQVc7QUFHaEMsY0FBTSxXQUFXLE1BQU0sTUFBTSxHQUFHLE9BQU8sTUFBTSwyQkFBMkI7QUFBQSxVQUN0RSxRQUFRO0FBQUEsVUFDUixTQUFTLEVBQUUsZ0JBQWdCLG1CQUFtQjtBQUFBLFVBQzlDLE1BQU0sS0FBSyxVQUFVLEVBQUUsT0FBTyxTQUFTLENBQUM7QUFBQSxRQUMxQyxDQUFDO0FBRUQsWUFBSSxDQUFDLFNBQVMsSUFBSTtBQUNoQixnQkFBTSxZQUFZLE1BQU0sU0FBUyxLQUFLLEVBQUUsTUFBTSxPQUFPLENBQUMsRUFBRTtBQUN4RCxrQkFBUSxLQUFLLHVDQUF1QyxVQUFVLFNBQVMsU0FBUyxVQUFVO0FBQzFGLGlCQUFPO0FBQUEsUUFDVDtBQUVBLGNBQU0sT0FBTyxNQUFNLFNBQVMsS0FBSztBQUNqQyxjQUFNLFdBQVcsS0FBSyxNQUFNLFNBQVMsS0FBSztBQUUxQyxZQUFJLENBQUMsVUFBVTtBQUNiLGtCQUFRLEtBQUssNENBQTRDO0FBQ3pELGlCQUFPO0FBQUEsUUFDVDtBQUdBLGFBQUssWUFBWTtBQUFBLFVBQ2YsY0FBYztBQUFBLFVBQ2QsWUFBWTtBQUFBLFVBQ1osWUFBWTtBQUFBO0FBQUEsVUFDWixZQUFZLEtBQUssSUFBSSxJQUFLLFFBQVE7QUFBQSxRQUNwQztBQUdBLGNBQU0sS0FBSyxlQUFlO0FBQzFCLGFBQUssa0JBQWtCO0FBRXZCLGdCQUFRLElBQUksNENBQTRDO0FBQ3hELGVBQU8sS0FBSztBQUFBLE1BQ2QsU0FBUyxPQUFPO0FBQ2QsZ0JBQVEsS0FBSyxzQ0FBc0MsTUFBTSxPQUFPO0FBRWhFLGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRjtBQUFBLElBRUEsb0JBQW9CO0FBQ2xCLFVBQUksS0FBSyxtQkFBbUI7QUFDMUIscUJBQWEsS0FBSyxpQkFBaUI7QUFBQSxNQUNyQztBQUVBLFVBQUksS0FBSyxXQUFXLFlBQVk7QUFFOUIsY0FBTSxlQUFlLEtBQUssVUFBVSxhQUFhLE9BQU87QUFDeEQsYUFBSyxvQkFBb0IsV0FBVyxNQUFNO0FBQ3hDLGtCQUFRLElBQUksdURBQXVEO0FBQ25FLGVBQUssY0FBYyxFQUFFLE1BQU0sUUFBUSxLQUFLO0FBQUEsUUFDMUMsR0FBRyxXQUFXO0FBQUEsTUFDaEI7QUFBQSxJQUNGO0FBQUEsSUFFQSxNQUFNLGlCQUFpQjtBQUNyQixZQUFNLGNBQWM7QUFBQSxRQUNsQixXQUFXLEtBQUs7QUFBQSxRQUNoQixhQUFhLEtBQUs7QUFBQSxRQUNsQixXQUFXLEtBQUssYUFBYSxPQUFPLFdBQVc7QUFBQSxRQUMvQyxrQkFBa0IsS0FBSyxvQkFBb0IsS0FBSyxJQUFJO0FBQUEsUUFDcEQsV0FBVyxLQUFLLElBQUk7QUFBQSxNQUN0QjtBQUVBLFVBQUksQ0FBQyxLQUFLLFdBQVc7QUFDbkIsYUFBSyxZQUFZLFlBQVk7QUFBQSxNQUMvQjtBQUNBLFVBQUksQ0FBQyxLQUFLLGtCQUFrQjtBQUMxQixhQUFLLG1CQUFtQixZQUFZO0FBQUEsTUFDdEM7QUFFQSxZQUFNLE9BQU8sUUFBUSxNQUFNLElBQUk7QUFBQSxRQUM3QixvQkFBb0I7QUFBQSxNQUN0QixDQUFDO0FBQUEsSUFDSDtBQUFBLElBRUEsTUFBTSxnQkFBZ0I7QUFDcEIsVUFBSTtBQUNGLGNBQU0sU0FBUyxNQUFNLEtBQUssWUFBWTtBQUN0QyxZQUFJLFVBQVUsT0FBTyxhQUFhLEtBQUssSUFBSSxHQUFHO0FBQzVDLGlCQUFPO0FBQUEsWUFDTCxlQUFlO0FBQUEsWUFDZixNQUFNLEtBQUs7QUFBQSxVQUNiO0FBQUEsUUFDRjtBQUFBLE1BQ0YsU0FBUyxPQUFPO0FBQ2QsZ0JBQVEsTUFBTSw2QkFBNkIsS0FBSztBQUFBLE1BQ2xEO0FBRUEsYUFBTyxFQUFFLGVBQWUsTUFBTTtBQUFBLElBQ2hDO0FBQUEsSUFFQSxNQUFNLFNBQVM7QUFDYixVQUFJLEtBQUssbUJBQW1CO0FBQzFCLHFCQUFhLEtBQUssaUJBQWlCO0FBQ25DLGFBQUssb0JBQW9CO0FBQUEsTUFDM0I7QUFFQSxXQUFLLFlBQVk7QUFDakIsV0FBSyxjQUFjO0FBRW5CLFlBQU0sT0FBTyxRQUFRLE1BQU0sT0FBTyxDQUFDLHNCQUFzQixhQUFhLGdCQUFnQixlQUFlLENBQUM7QUFFdEcsV0FBSyxnQkFBZ0IsS0FBSztBQUUxQixhQUFPLEVBQUUsU0FBUyxLQUFLO0FBQUEsSUFDekI7QUFBQSxJQUVBLE1BQU0sa0JBQWtCO0FBQ3RCLFVBQUk7QUFDRixjQUFNLFNBQVMsTUFBTSxLQUFLLFlBQVk7QUFDdEMsZUFBTyxDQUFDLENBQUMsVUFBVSxPQUFPLGFBQWEsS0FBSyxJQUFJO0FBQUEsTUFDbEQsU0FBUyxPQUFPO0FBQ2QsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBQUEsSUFFQSxNQUFNLFdBQVc7QUFDZixZQUFNLFNBQVMsTUFBTSxLQUFLLFlBQVk7QUFDdEMsYUFBTyxRQUFRLGdCQUFnQjtBQUFBLElBQ2pDO0FBQUEsSUFFQSxNQUFNLGlCQUFpQjtBQUNyQixhQUFPLEtBQUs7QUFBQSxJQUNkO0FBQUEsSUFFQSxnQkFBZ0JBLGtCQUFpQjtBQUMvQixVQUFJO0FBQ0YsWUFBSSxPQUFPLFFBQVEsY0FBYztBQUMvQixpQkFBTyxPQUFPLGFBQWEsRUFBRSxNQUFNQSxtQkFBa0IsT0FBTyxNQUFNLENBQUM7QUFDbkUsaUJBQU8sT0FBTyx3QkFBd0I7QUFBQSxZQUNwQyxPQUFPQSxtQkFBa0IsWUFBWTtBQUFBLFVBQ3ZDLENBQUM7QUFDRCxpQkFBTyxPQUFPLFNBQVM7QUFBQSxZQUNyQixPQUFPQSxtQkFBa0IsK0JBQStCO0FBQUEsVUFDMUQsQ0FBQztBQUFBLFFBQ0g7QUFBQSxNQUNGLFNBQVMsT0FBTztBQUNkLGdCQUFRLE1BQU0sMkJBQTJCLEtBQUs7QUFBQSxNQUNoRDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBRUEsTUFBTSxjQUFjLElBQUksWUFBWTtBQUNwQyxNQUFPLHVCQUFROzs7QUNyWGYsTUFBTSxXQUFXO0FBQUE7QUFBQSxJQUVmLFVBQVUsU0FBUyxlQUFlLFVBQVU7QUFBQSxJQUM1QyxVQUFVLFNBQVMsZUFBZSxVQUFVO0FBQUEsSUFDNUMsVUFBVSxTQUFTLGVBQWUsVUFBVTtBQUFBLElBQzVDLFdBQVcsU0FBUyxlQUFlLFdBQVc7QUFBQSxJQUM5QyxXQUFXLFNBQVMsZUFBZSxXQUFXO0FBQUEsSUFDOUMsWUFBWSxTQUFTLGVBQWUsWUFBWTtBQUFBLElBQ2hELFlBQVksU0FBUyxlQUFlLFlBQVk7QUFBQSxJQUNoRCxlQUFlLFNBQVMsZUFBZSxlQUFlO0FBQUEsSUFDdEQsVUFBVSxTQUFTLGVBQWUsVUFBVTtBQUFBLElBQzVDLGlCQUFpQixTQUFTLGVBQWUsaUJBQWlCO0FBQUEsSUFDMUQsZ0JBQWdCLFNBQVMsZUFBZSxnQkFBZ0I7QUFBQSxJQUN4RCxhQUFhLFNBQVMsZUFBZSxhQUFhO0FBQUEsSUFDbEQsZ0JBQWdCLFNBQVMsZUFBZSxnQkFBZ0I7QUFBQSxJQUN4RCxXQUFXLFNBQVMsZUFBZSxXQUFXO0FBQUEsSUFDOUMsZ0JBQWdCLFNBQVMsZUFBZSxnQkFBZ0I7QUFBQSxJQUN4RCxtQkFBbUIsU0FBUyxlQUFlLG1CQUFtQjtBQUFBLElBQzlELGlCQUFpQixTQUFTLGVBQWUsaUJBQWlCO0FBQUEsSUFDMUQsb0JBQW9CLFNBQVMsZUFBZSxvQkFBb0I7QUFBQSxJQUNoRSxXQUFXLFNBQVMsZUFBZSxXQUFXO0FBQUEsSUFDOUMsV0FBVyxTQUFTLGVBQWUsV0FBVztBQUFBO0FBQUEsSUFHOUMsZUFBZSxTQUFTLGVBQWUsZUFBZTtBQUFBLElBQ3RELGlCQUFpQixTQUFTLGVBQWUsaUJBQWlCO0FBQUEsSUFDMUQsV0FBVyxTQUFTLGNBQWMsYUFBYTtBQUFBLElBQy9DLFlBQVksU0FBUyxjQUFjLGNBQWM7QUFBQSxJQUNqRCxnQkFBZ0IsU0FBUyxlQUFlLGdCQUFnQjtBQUFBLElBQ3hELGFBQWEsU0FBUyxlQUFlLGFBQWE7QUFBQSxJQUNsRCxLQUFLLFNBQVMsY0FBYyxNQUFNO0FBQUEsSUFDbEMsaUJBQWlCLFNBQVMsZUFBZSxpQkFBaUI7QUFBQSxJQUMxRCxlQUFlLFNBQVMsZUFBZSxlQUFlO0FBQUEsSUFDdEQsa0JBQWtCLFNBQVMsZUFBZSxrQkFBa0I7QUFBQSxJQUM1RCxRQUFRLFNBQVMsZUFBZSxRQUFRO0FBQUEsSUFDeEMsZUFBZSxTQUFTLGVBQWUsZUFBZTtBQUFBLElBQ3RELFdBQVcsU0FBUyxlQUFlLFdBQVc7QUFBQSxJQUM5QyxtQkFBbUIsU0FBUyxlQUFlLG1CQUFtQjtBQUFBLElBQzlELFdBQVcsU0FBUyxlQUFlLFdBQVc7QUFBQSxJQUM5QyxtQkFBbUIsU0FBUyxlQUFlLG1CQUFtQjtBQUFBLElBQzlELGlCQUFpQixTQUFTLGVBQWUsaUJBQWlCO0FBQUEsSUFDMUQsa0JBQWtCLFNBQVMsZUFBZSxrQkFBa0I7QUFBQSxJQUM1RCxlQUFlLFNBQVMsZUFBZSxlQUFlO0FBQUEsRUFDeEQ7QUFHQSxNQUFJLGdCQUFnQixDQUFDO0FBQ3JCLE1BQUksdUJBQXVCO0FBQzNCLE1BQUksYUFBYTtBQUNqQixNQUFJLGtCQUFrQjtBQUt0QixpQkFBZSxPQUFPO0FBRXBCLFVBQU0scUJBQVksV0FBVztBQUc3QixVQUFNLGFBQWEsTUFBTSxxQkFBWSxjQUFjO0FBQ25ELHNCQUFrQixXQUFXO0FBRzdCLGdCQUFZO0FBR1osVUFBTSxVQUFVO0FBRWhCLFFBQUksaUJBQWlCO0FBRW5CLG1CQUFhO0FBRWIsWUFBTSxpQkFBaUI7QUFFdkIsWUFBTUMsWUFBVztBQUVqQiwwQkFBb0I7QUFFcEIsZUFBUztBQUFBLElBQ1gsT0FBTztBQUVMLG1CQUFhO0FBRWIsOEJBQXdCO0FBQUEsSUFDMUI7QUFBQSxFQUNGO0FBS0EsV0FBUyxjQUFjO0FBQ3JCLFFBQUksU0FBUyxlQUFlO0FBQzFCLFVBQUk7QUFDRixjQUFNLFdBQVcsT0FBTyxRQUFRLFlBQVk7QUFDNUMsaUJBQVMsY0FBYyxjQUFjLElBQUksU0FBUyxPQUFPO0FBQUEsTUFDM0QsU0FBUyxPQUFPO0FBQ2QsZ0JBQVEsS0FBSyx3Q0FBd0MsS0FBSztBQUFBLE1BQzVEO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFLQSxpQkFBZSxZQUFZO0FBQ3pCLFdBQU8sSUFBSSxRQUFRLENBQUMsWUFBWTtBQUM5QixhQUFPLFFBQVEsTUFBTSxJQUFJLENBQUMsVUFBVSxHQUFHLENBQUMsV0FBVztBQUNqRCxxQkFBYSxPQUFPLGFBQWE7QUFDakMsb0JBQVk7QUFDWixnQkFBUTtBQUFBLE1BQ1YsQ0FBQztBQUFBLElBQ0gsQ0FBQztBQUFBLEVBQ0g7QUFLQSxXQUFTLGNBQWM7QUFDckIsUUFBSSxTQUFTLEtBQUs7QUFDaEIsVUFBSSxZQUFZO0FBQ2QsaUJBQVMsSUFBSSxVQUFVLElBQUksY0FBYztBQUN6QyxpQkFBUyxJQUFJLFVBQVUsT0FBTyxlQUFlO0FBQUEsTUFDL0MsT0FBTztBQUNMLGlCQUFTLElBQUksVUFBVSxJQUFJLGVBQWU7QUFDMUMsaUJBQVMsSUFBSSxVQUFVLE9BQU8sY0FBYztBQUFBLE1BQzlDO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFLQSxpQkFBZUEsY0FBYTtBQUMxQixXQUFPLElBQUksUUFBUSxDQUFDLFlBQVk7QUFDOUIsYUFBTyxRQUFRLFlBQVksRUFBRSxRQUFRLFlBQVksR0FBRyxPQUFPLGFBQWE7QUFDdEUsWUFBSSxVQUFVLFFBQVE7QUFDcEIsMEJBQWdCLFNBQVM7QUFHekIsY0FBSSxTQUFTLGNBQWMsVUFBVSxrQkFBa0I7QUFDdkQsY0FBSSxnQkFBZ0IsY0FBYyxpQkFBaUIsa0JBQWtCO0FBR3JFLGNBQUksT0FBTyxTQUFTLGlCQUFpQixLQUFLLE9BQU8sU0FBUyxpQkFBaUIsR0FBRztBQUM1RSxxQkFBUyxrQkFBa0I7QUFFM0Isa0JBQU0sT0FBTyxRQUFRLFlBQVk7QUFBQSxjQUMvQixRQUFRO0FBQUEsY0FDUixRQUFRLEVBQUUsR0FBRyxlQUFlLE9BQU87QUFBQSxZQUNyQyxDQUFDO0FBQUEsVUFDSDtBQUVBLGNBQUksY0FBYyxTQUFTLGdCQUFnQixLQUFLLGNBQWMsU0FBUyxnQkFBZ0IsR0FBRztBQUN4Riw0QkFBZ0Isa0JBQWtCO0FBRWxDLGtCQUFNLE9BQU8sUUFBUSxZQUFZO0FBQUEsY0FDL0IsUUFBUTtBQUFBLGNBQ1IsUUFBUSxFQUFFLEdBQUcsZUFBZSxjQUFjO0FBQUEsWUFDNUMsQ0FBQztBQUFBLFVBQ0g7QUFHQSxtQkFBUyxjQUFjLFVBQVUsY0FBYyxZQUFZO0FBQzNELG1CQUFTLE9BQU8sUUFBUTtBQUN4QixjQUFJLFNBQVMsZUFBZTtBQUMxQixxQkFBUyxjQUFjLFFBQVE7QUFBQSxVQUNqQztBQUlBLG1CQUFTLGtCQUFrQixVQUFVLGNBQWMsc0JBQXNCO0FBQ3pFLG1CQUFTLFVBQVUsVUFBVSxjQUFjLFVBQVU7QUFBQSxRQUN2RDtBQUNBLGdCQUFRO0FBQUEsTUFDVixDQUFDO0FBQUEsSUFDSCxDQUFDO0FBQUEsRUFDSDtBQUtBLGlCQUFlLG1CQUFtQjtBQUNoQyxRQUFJO0FBQ0YsWUFBTSxVQUFVLE1BQU0sT0FBTyxRQUFRLE1BQU0sSUFBSSxDQUFDLG9CQUFvQixDQUFDO0FBQ3JFLFVBQUksUUFBUSxvQkFBb0IsYUFBYSxTQUFTLFNBQVMsV0FBVztBQUN4RSxpQkFBUyxVQUFVLGNBQWMsUUFBUSxtQkFBbUIsWUFBWTtBQUN4RSxpQkFBUyxVQUFVLFFBQVEsUUFBUSxtQkFBbUIsWUFBWTtBQUFBLE1BQ3BFLFdBQVcsU0FBUyxXQUFXO0FBQzdCLGlCQUFTLFVBQVUsY0FBYztBQUNqQyxpQkFBUyxVQUFVLFFBQVE7QUFBQSxNQUM3QjtBQUFBLElBQ0YsU0FBUyxPQUFPO0FBQ2QsY0FBUSxNQUFNLDhDQUE4QyxLQUFLO0FBQUEsSUFDbkU7QUFBQSxFQUNGO0FBTUEsV0FBUyxlQUFlO0FBQ3RCLFFBQUksU0FBUztBQUFVLGVBQVMsU0FBUyxNQUFNLFVBQVU7QUFDekQsUUFBSSxTQUFTO0FBQVUsZUFBUyxTQUFTLE1BQU0sVUFBVTtBQUFBLEVBQzNEO0FBS0EsV0FBUyxlQUFlO0FBQ3RCLFFBQUksU0FBUztBQUFVLGVBQVMsU0FBUyxNQUFNLFVBQVU7QUFDekQsUUFBSSxTQUFTO0FBQVUsZUFBUyxTQUFTLE1BQU0sVUFBVTtBQUFBLEVBQzNEO0FBS0EsV0FBUywwQkFBMEI7QUFFakMsUUFBSSxTQUFTLFVBQVU7QUFDckIsZUFBUyxTQUFTLGlCQUFpQixTQUFTLE1BQU07QUFDaEQsaUJBQVMsU0FBUyxVQUFVLElBQUksUUFBUTtBQUN4QyxpQkFBUyxVQUFVLFVBQVUsT0FBTyxRQUFRO0FBQzVDLGlCQUFTLFVBQVUsTUFBTSxVQUFVO0FBQ25DLGlCQUFTLFdBQVcsTUFBTSxVQUFVO0FBQ3BDLHNCQUFjO0FBQUEsTUFDaEIsQ0FBQztBQUFBLElBQ0g7QUFFQSxRQUFJLFNBQVMsV0FBVztBQUN0QixlQUFTLFVBQVUsaUJBQWlCLFNBQVMsTUFBTTtBQUNqRCxpQkFBUyxVQUFVLFVBQVUsSUFBSSxRQUFRO0FBQ3pDLGlCQUFTLFNBQVMsVUFBVSxPQUFPLFFBQVE7QUFDM0MsaUJBQVMsV0FBVyxNQUFNLFVBQVU7QUFDcEMsaUJBQVMsVUFBVSxNQUFNLFVBQVU7QUFDbkMsc0JBQWM7QUFBQSxNQUNoQixDQUFDO0FBQUEsSUFDSDtBQUdBLFFBQUksU0FBUyxVQUFVO0FBQ3JCLGVBQVMsU0FBUyxpQkFBaUIsU0FBUyxZQUFZO0FBQ3RELGNBQU0sWUFBWTtBQUFBLE1BQ3BCLENBQUM7QUFBQSxJQUNIO0FBR0EsUUFBSSxTQUFTLFdBQVc7QUFDdEIsZUFBUyxVQUFVLGlCQUFpQixTQUFTLFlBQVk7QUFDdkQsY0FBTSxhQUFhO0FBQUEsTUFDckIsQ0FBQztBQUFBLElBQ0g7QUFHQSxRQUFJLFNBQVMsZ0JBQWdCO0FBQzNCLGVBQVMsZUFBZSxpQkFBaUIsU0FBUyxNQUFNLFlBQVksUUFBUSxDQUFDO0FBQUEsSUFDL0U7QUFDQSxRQUFJLFNBQVMsbUJBQW1CO0FBQzlCLGVBQVMsa0JBQWtCLGlCQUFpQixTQUFTLE1BQU0sWUFBWSxXQUFXLENBQUM7QUFBQSxJQUNyRjtBQUNBLFFBQUksU0FBUyxpQkFBaUI7QUFDNUIsZUFBUyxnQkFBZ0IsaUJBQWlCLFNBQVMsTUFBTSxZQUFZLFFBQVEsQ0FBQztBQUFBLElBQ2hGO0FBQ0EsUUFBSSxTQUFTLG9CQUFvQjtBQUMvQixlQUFTLG1CQUFtQixpQkFBaUIsU0FBUyxNQUFNLFlBQVksV0FBVyxDQUFDO0FBQUEsSUFDdEY7QUFHQSxRQUFJLFNBQVMsZUFBZTtBQUMxQixlQUFTLGNBQWMsaUJBQWlCLFlBQVksQ0FBQyxNQUFNO0FBQ3pELFlBQUksRUFBRSxRQUFRO0FBQVMsc0JBQVk7QUFBQSxNQUNyQyxDQUFDO0FBQUEsSUFDSDtBQUNBLFFBQUksU0FBUyxnQkFBZ0I7QUFDM0IsZUFBUyxlQUFlLGlCQUFpQixZQUFZLENBQUMsTUFBTTtBQUMxRCxZQUFJLEVBQUUsUUFBUTtBQUFTLHVCQUFhO0FBQUEsTUFDdEMsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGO0FBS0EsaUJBQWUsY0FBYztBQUMzQixVQUFNLFFBQVEsU0FBUyxZQUFZLE1BQU0sS0FBSztBQUM5QyxVQUFNLFdBQVcsU0FBUyxlQUFlO0FBRXpDLFFBQUksQ0FBQyxTQUFTLENBQUMsVUFBVTtBQUN2QixvQkFBYyxpQ0FBaUM7QUFDL0M7QUFBQSxJQUNGO0FBRUEsYUFBUyxTQUFTLFdBQVc7QUFDN0IsYUFBUyxTQUFTLGNBQWM7QUFDaEMsa0JBQWM7QUFFZCxRQUFJO0FBQ0YsWUFBTSxTQUFTLE1BQU0scUJBQVksYUFBYSxTQUFTLEVBQUUsT0FBTyxTQUFTLENBQUM7QUFFMUUsVUFBSSxPQUFPLFNBQVM7QUFDbEIsMEJBQWtCO0FBQ2xCLHFCQUFhO0FBQ2IsY0FBTUEsWUFBVztBQUNqQiw0QkFBb0I7QUFDcEIsaUJBQVM7QUFBQSxNQUNYLE9BQU87QUFDTCxzQkFBYyxPQUFPLFNBQVMsY0FBYztBQUFBLE1BQzlDO0FBQUEsSUFDRixTQUFTLE9BQU87QUFDZCxvQkFBYyxNQUFNLFdBQVcsbUJBQW1CO0FBQUEsSUFDcEQsVUFBRTtBQUNBLGVBQVMsU0FBUyxXQUFXO0FBQzdCLGVBQVMsU0FBUyxjQUFjO0FBQUEsSUFDbEM7QUFBQSxFQUNGO0FBS0EsaUJBQWUsZUFBZTtBQUM1QixVQUFNLFlBQVksU0FBUyxpQkFBaUIsTUFBTSxLQUFLO0FBQ3ZELFVBQU0sV0FBVyxTQUFTLGdCQUFnQixNQUFNLEtBQUs7QUFDckQsVUFBTSxRQUFRLFNBQVMsYUFBYSxNQUFNLEtBQUs7QUFDL0MsVUFBTSxXQUFXLFNBQVMsZ0JBQWdCO0FBRTFDLFFBQUksQ0FBQyxhQUFhLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxVQUFVO0FBQ2xELG9CQUFjLDJCQUEyQjtBQUN6QztBQUFBLElBQ0Y7QUFFQSxhQUFTLFVBQVUsV0FBVztBQUM5QixhQUFTLFVBQVUsY0FBYztBQUNqQyxrQkFBYztBQUVkLFFBQUk7QUFFRixZQUFNLFNBQVMsTUFBTSxXQUFtQjtBQUN4QyxZQUFNLG1CQUFtQixNQUFNLE1BQU0sR0FBRyxPQUFPLE1BQU0sc0JBQXNCO0FBQUEsUUFDekUsUUFBUTtBQUFBLFFBQ1IsU0FBUyxFQUFFLGdCQUFnQixtQkFBbUI7QUFBQSxRQUM5QyxNQUFNLEtBQUssVUFBVSxFQUFFLFdBQVcsVUFBVSxPQUFPLFNBQVMsQ0FBQztBQUFBLE1BQy9ELENBQUM7QUFFRCxZQUFNLGVBQWUsTUFBTSxpQkFBaUIsS0FBSztBQUVqRCxVQUFJLGlCQUFpQixNQUFNLGFBQWEsT0FBTztBQUU3QyxjQUFNLGNBQWMsTUFBTSxxQkFBWSxhQUFhLFNBQVMsRUFBRSxPQUFPLFNBQVMsQ0FBQztBQUUvRSxZQUFJLFlBQVksU0FBUztBQUN2Qiw0QkFBa0I7QUFDbEIsdUJBQWE7QUFDYixnQkFBTSxpQkFBaUI7QUFDdkIsZ0JBQU1BLFlBQVc7QUFDakIsOEJBQW9CO0FBQ3BCLG1CQUFTO0FBQUEsUUFDWCxPQUFPO0FBQ0wsd0JBQWMsMERBQTBEO0FBQUEsUUFDMUU7QUFBQSxNQUNGLE9BQU87QUFDTCxzQkFBYyxhQUFhLFNBQVMscUJBQXFCO0FBQUEsTUFDM0Q7QUFBQSxJQUNGLFNBQVMsT0FBTztBQUNkLG9CQUFjLE1BQU0sV0FBVyxtQkFBbUI7QUFBQSxJQUNwRCxVQUFFO0FBQ0EsZUFBUyxVQUFVLFdBQVc7QUFDOUIsZUFBUyxVQUFVLGNBQWM7QUFBQSxJQUNuQztBQUFBLEVBQ0Y7QUFLQSxpQkFBZSxZQUFZLFVBQVU7QUFDbkMsUUFBSTtBQUNGLFlBQU0sTUFBTSxhQUFhLFdBQ3BCLFNBQVMsa0JBQWtCLFNBQVMsa0JBQ3BDLFNBQVMscUJBQXFCLFNBQVM7QUFFNUMsVUFBSSxLQUFLO0FBQ1AsWUFBSSxXQUFXO0FBQ2YsWUFBSSxjQUFjO0FBQUEsTUFDcEI7QUFDQSxvQkFBYztBQUVkLFlBQU0sU0FBUyxNQUFNLHFCQUFZLGFBQWEsUUFBUTtBQUV0RCxVQUFJLE9BQU8sU0FBUztBQUNsQiwwQkFBa0I7QUFDbEIscUJBQWE7QUFDYixjQUFNLGlCQUFpQjtBQUN2QixjQUFNQSxZQUFXO0FBQ2pCLDRCQUFvQjtBQUNwQixpQkFBUztBQUFBLE1BQ1gsT0FBTztBQUNMLHNCQUFjLE9BQU8sU0FBUyx1QkFBdUI7QUFBQSxNQUN2RDtBQUFBLElBQ0YsU0FBUyxPQUFPO0FBQ2Qsb0JBQWMsTUFBTSxXQUFXLG1CQUFtQjtBQUFBLElBQ3BELFVBQUU7QUFDQSxZQUFNLE1BQU0sYUFBYSxXQUNwQixTQUFTLGtCQUFrQixTQUFTLGtCQUNwQyxTQUFTLHFCQUFxQixTQUFTO0FBQzVDLFVBQUksS0FBSztBQUNQLFlBQUksV0FBVztBQUNmLGNBQU0sVUFBVSxTQUFTLFdBQVcsTUFBTSxZQUFZO0FBQ3RELFlBQUksY0FBYyxhQUFhLFdBQzFCLFVBQVUseUJBQXlCLHdCQUNuQyxVQUFVLDRCQUE0QjtBQUFBLE1BQzdDO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFLQSxXQUFTLGNBQWMsU0FBUztBQUM5QixRQUFJLFNBQVMsV0FBVztBQUN0QixlQUFTLFVBQVUsY0FBYztBQUNqQyxlQUFTLFVBQVUsTUFBTSxVQUFVO0FBQUEsSUFDckM7QUFBQSxFQUNGO0FBS0EsV0FBUyxnQkFBZ0I7QUFDdkIsUUFBSSxTQUFTLFdBQVc7QUFDdEIsZUFBUyxVQUFVLE1BQU0sVUFBVTtBQUFBLElBQ3JDO0FBQUEsRUFDRjtBQUtBLFdBQVMsV0FBVztBQUNsQixVQUFNLFlBQVksU0FBUyxlQUFlO0FBRzFDLFFBQUksYUFBYSxTQUFTLFdBQVc7QUFDbkMsZUFBUyxVQUFVLFVBQVUsT0FBTyxVQUFVO0FBQzlDLFVBQUksU0FBUztBQUFZLGlCQUFTLFdBQVcsY0FBYztBQUFBLElBQzdELFdBQVcsU0FBUyxXQUFXO0FBQzdCLGVBQVMsVUFBVSxVQUFVLElBQUksVUFBVTtBQUMzQyxVQUFJLFNBQVM7QUFBWSxpQkFBUyxXQUFXLGNBQWM7QUFBQSxJQUM3RDtBQUFBLEVBQ0Y7QUFLQSxXQUFTLHNCQUFzQjtBQUU3QixRQUFJLFNBQVMsV0FBVztBQUN0QixlQUFTLFVBQVUsaUJBQWlCLFNBQVMsWUFBWTtBQUN2RCxjQUFNLHFCQUFZLE9BQU87QUFDekIsMEJBQWtCO0FBRWxCLFlBQUksU0FBUyxXQUFXO0FBQ3RCLG1CQUFTLFVBQVUsY0FBYztBQUNqQyxtQkFBUyxVQUFVLFFBQVE7QUFBQSxRQUM3QjtBQUNBLHFCQUFhO0FBQ2IsZ0NBQXdCO0FBQUEsTUFDMUIsQ0FBQztBQUFBLElBQ0g7QUFHQSxRQUFJLFNBQVMsZUFBZTtBQUMxQixlQUFTLGNBQWMsaUJBQWlCLFVBQVUsWUFBWTtBQUM1RCxjQUFNLFVBQVUsU0FBUyxjQUFjO0FBRXZDLGNBQU1DLFlBQVcsRUFBRSxRQUFRLENBQUM7QUFDNUIsaUJBQVM7QUFBQSxNQUNYLENBQUM7QUFBQSxJQUNIO0FBR0EsYUFBUyxlQUFlLGlCQUFpQixTQUFTLE1BQU07QUFDdEQsbUJBQWEsQ0FBQztBQUNkLGtCQUFZO0FBRVosYUFBTyxRQUFRLE1BQU0sSUFBSSxFQUFFLFVBQVUsV0FBVyxDQUFDO0FBQUEsSUFDbkQsQ0FBQztBQUdELGFBQVMsWUFBWSxpQkFBaUIsU0FBUyxNQUFNO0FBQ25ELHdCQUFrQjtBQUFBLElBQ3BCLENBQUM7QUFHRCxhQUFTLGlCQUFpQixpQkFBaUIsU0FBUyxNQUFNO0FBQ3hELHlCQUFtQjtBQUFBLElBQ3JCLENBQUM7QUFHRCxhQUFTLGdCQUFnQixpQkFBaUIsU0FBUyxDQUFDLE1BQU07QUFDeEQsVUFBSSxFQUFFLFdBQVcsU0FBUyxpQkFBaUI7QUFDekMsMkJBQW1CO0FBQUEsTUFDckI7QUFBQSxJQUNGLENBQUM7QUFHRCxhQUFTLGtCQUFrQixpQkFBaUIsU0FBUyxZQUFZO0FBQy9ELFlBQU0sZUFBZTtBQUFBLElBQ3ZCLENBQUM7QUFHRCxhQUFTLGdCQUFnQixpQkFBaUIsU0FBUyxZQUFZO0FBQzdELFlBQU0sYUFBYTtBQUFBLElBQ3JCLENBQUM7QUFBQSxFQUNIO0FBS0EsaUJBQWUsaUJBQWlCO0FBQzlCLFVBQU0sU0FBUyxTQUFTLE9BQU8sTUFBTSxLQUFLO0FBRTFDLFFBQUksQ0FBQyxRQUFRO0FBQ1gsMkJBQXFCLHdCQUF3QixPQUFPO0FBQ3BEO0FBQUEsSUFDRjtBQUdBLFVBQU0sVUFBVSxNQUFNLE9BQU8sUUFBUSxNQUFNLElBQUksQ0FBQyxvQkFBb0IsQ0FBQztBQUNyRSxRQUFJLFNBQVM7QUFFYixRQUFJLFFBQVEsb0JBQW9CLFdBQVcsY0FBYztBQUN2RCxZQUFNLFNBQVMsUUFBUSxtQkFBbUI7QUFDMUMsVUFBSSxPQUFPLGNBQWMsT0FBTyxhQUFhLEtBQUssSUFBSSxHQUFHO0FBQ3ZELGlCQUFTLE9BQU87QUFBQSxNQUNsQixPQUFPO0FBQ0wsNkJBQXFCLHdDQUF3QyxPQUFPO0FBQ3BFO0FBQUEsTUFDRjtBQUFBLElBQ0YsT0FBTztBQUNMLDJCQUFxQixzQ0FBc0MsT0FBTztBQUNsRTtBQUFBLElBQ0Y7QUFFQSxhQUFTLGtCQUFrQixjQUFjO0FBQ3pDLGFBQVMsa0JBQWtCLFdBQVc7QUFFdEMsUUFBSTtBQUNGLFlBQU0sV0FBVyxNQUFNLElBQUksUUFBUSxDQUFDLFlBQVk7QUFDOUMsZUFBTyxRQUFRO0FBQUEsVUFDYjtBQUFBLFlBQ0UsUUFBUTtBQUFBLFlBQ1I7QUFBQSxZQUNBO0FBQUEsVUFDRjtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQUEsTUFDRixDQUFDO0FBRUQsVUFBSSxTQUFTLFNBQVM7QUFDcEIsNkJBQXFCLHNDQUFpQyxTQUFTO0FBQUEsTUFDakUsT0FBTztBQUNMLDZCQUFxQixVQUFLLFNBQVMsS0FBSyxJQUFJLE9BQU87QUFBQSxNQUNyRDtBQUFBLElBQ0YsU0FBUyxPQUFPO0FBQ2QsMkJBQXFCLDZCQUF3QixNQUFNLE9BQU8sSUFBSSxPQUFPO0FBQUEsSUFDdkUsVUFBRTtBQUNBLGVBQVMsa0JBQWtCLGNBQWM7QUFDekMsZUFBUyxrQkFBa0IsV0FBVztBQUFBLElBQ3hDO0FBQUEsRUFDRjtBQUtBLGlCQUFlLGVBQWU7QUFDNUIsVUFBTSxTQUFTO0FBQUEsTUFDYixRQUFRLFNBQVMsT0FBTyxNQUFNLEtBQUs7QUFBQSxNQUNuQyxlQUFlLFNBQVMsZUFBZSxNQUFNLEtBQUssS0FBSyxrQkFBa0I7QUFBQTtBQUFBLE1BRXpFLG1CQUFtQixTQUFTLGtCQUFrQjtBQUFBLE1BQzlDLE9BQU8sU0FBUyxVQUFVO0FBQUEsSUFDNUI7QUFHQSxVQUFNLFdBQW1CO0FBQUEsTUFDdkIsUUFBUSxPQUFPO0FBQUEsTUFDZixlQUFlLE9BQU87QUFBQSxJQUN4QixDQUFDO0FBR0QsVUFBTSxJQUFJLFFBQVEsQ0FBQyxZQUFZO0FBQzdCLGFBQU8sUUFBUSxZQUFZO0FBQUEsUUFDekIsUUFBUTtBQUFBLFFBQ1I7QUFBQSxNQUNGLEdBQUcsT0FBTztBQUFBLElBQ1osQ0FBQztBQUNELHlCQUFxQixzQ0FBaUMsU0FBUztBQUcvRCxlQUFXLE1BQU07QUFDZixlQUFTLGlCQUFpQixNQUFNLFVBQVU7QUFDMUMseUJBQW1CO0FBQUEsSUFDckIsR0FBRyxJQUFJO0FBQUEsRUFDVDtBQUtBLFdBQVMsb0JBQW9CO0FBQzNCLDJCQUF1QjtBQUN2QixhQUFTLGdCQUFnQixNQUFNLFVBQVU7QUFFekMsZUFBVyxNQUFNO0FBQ2YsZUFBUyxnQkFBZ0IsVUFBVSxJQUFJLFNBQVM7QUFBQSxJQUNsRCxHQUFHLEVBQUU7QUFBQSxFQUNQO0FBS0EsV0FBUyxxQkFBcUI7QUFDNUIsMkJBQXVCO0FBQ3ZCLGFBQVMsZ0JBQWdCLFVBQVUsT0FBTyxTQUFTO0FBRW5ELGVBQVcsTUFBTTtBQUNmLGVBQVMsZ0JBQWdCLE1BQU0sVUFBVTtBQUFBLElBQzNDLEdBQUcsR0FBRztBQUFBLEVBQ1I7QUFLQSxpQkFBZUEsWUFBVyxRQUFRO0FBQ2hDLFdBQU8sSUFBSSxRQUFRLENBQUMsWUFBWTtBQUM5QixhQUFPLFFBQVE7QUFBQSxRQUNiLEVBQUUsUUFBUSxnQkFBZ0IsT0FBTztBQUFBLFFBQ2pDLENBQUMsYUFBYTtBQUNaLGNBQUksVUFBVSxTQUFTO0FBQ3JCLDRCQUFnQixFQUFFLEdBQUcsZUFBZSxHQUFHLE9BQU87QUFBQSxVQUNoRDtBQUNBLGtCQUFRO0FBQUEsUUFDVjtBQUFBLE1BQ0Y7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBTUEsV0FBUyxxQkFBcUIsU0FBUyxNQUFNO0FBQzNDLGFBQVMsaUJBQWlCLGNBQWM7QUFDeEMsYUFBUyxpQkFBaUIsWUFBWSxxQkFBcUIsSUFBSTtBQUMvRCxhQUFTLGlCQUFpQixNQUFNLFVBQVU7QUFBQSxFQUM1QztBQUdBLE1BQUksU0FBUyxlQUFlLFdBQVc7QUFDckMsYUFBUyxpQkFBaUIsb0JBQW9CLElBQUk7QUFBQSxFQUNwRCxPQUFPO0FBQ0wsU0FBSztBQUFBLEVBQ1A7IiwKICAibmFtZXMiOiBbImlzQXV0aGVudGljYXRlZCIsICJsb2FkQ29uZmlnIiwgInNhdmVDb25maWciXQp9Cg==
