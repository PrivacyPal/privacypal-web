// OAuth callback handler for browser extension
const urlParams = new URLSearchParams(window.location.search);
const success = urlParams.get('success');
const error = urlParams.get('error');
const state = urlParams.get('state');
const dataParam = urlParams.get('data');

console.log('Callback loaded:', { success, error, state, hasData: !!dataParam });

if (error) {
  document.getElementById('status').textContent = 'Authentication Failed';
  document.getElementById('message').textContent = error || 'An error occurred during authentication.';
  document.getElementById('message').classList.add('error');
  document.querySelector('.spinner').style.display = 'none';
} else if (success && dataParam) {
  try {
    const authData = JSON.parse(atob(dataParam.replace(/-/g, '+').replace(/_/g, '/')));
    console.log('Auth data parsed:', { hasUser: !!authData.user, hasTokens: !!authData.tokens });
    
    const cleanUrl = window.location.origin + window.location.pathname + '?success=true&state=' + state;
    window.history.replaceState({}, '', cleanUrl);
    
    const normalizedTokens = {
      access_token: authData.tokens.accessToken,
      token_type: authData.tokens.tokenType || 'Bearer',
      expires_in: authData.tokens.expiresIn,
      expires_at: Date.now() + (authData.tokens.expiresIn * 1000),
      sessionId: crypto.randomUUID()
    };
    
    const sessionData = {
      jwtTokens: normalizedTokens,
      userProfile: authData.user,
      sessionId: normalizedTokens.sessionId,
      sessionStartTime: Date.now(),
      timestamp: Date.now()
    };
    
    console.log('Storing session data in chrome.storage...');
    chrome.storage.local.set({ 
      privacypal_session: sessionData
    }, () => {
      console.log('Session stored, sending message to background...');
      // Send message to background script
      chrome.runtime.sendMessage({
        type: 'OAUTH_COMPLETE',
        state: state,
        success: true
      }, (response) => {
        console.log('Message response:', response);
        if (chrome.runtime.lastError) {
          console.error('Error sending message:', chrome.runtime.lastError);
        }
        document.getElementById('status').textContent = 'Authentication Successful!';
        document.getElementById('message').textContent = 'Closing window...';
        // Give time for message to be processed before closing
        setTimeout(() => {
          try {
            window.close();
          } catch (e) {
            console.log('Cannot close window, user should close manually');
            document.getElementById('message').textContent = 'You can close this window now.';
          }
        }, 1500);
      });
    });
  } catch (err) {
    console.error('Failed to process auth data:', err);
    document.getElementById('status').textContent = 'Authentication Failed';
    document.getElementById('message').textContent = 'Invalid authentication response: ' + err.message;
    document.getElementById('message').classList.add('error');
    document.querySelector('.spinner').style.display = 'none';
  }
} else {
  console.log('No data param found, using legacy fallback', { success, hasData: !!dataParam });
  document.getElementById('status').textContent = 'Authentication Successful!';
  document.getElementById('message').textContent = 'You can close this tab now.';
}

