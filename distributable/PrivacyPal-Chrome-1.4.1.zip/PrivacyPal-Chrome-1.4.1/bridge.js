(() => {
  const DEFAULT_CONFIG = {
    enabled: true,
    apiUrl: "https://api.privacypal.ai",
    apiKey: null,
    debug: true,
    showNotifications: true
  };
  console.log("[PrivacyPal Bridge] Initializing message bridge");
  if (typeof chrome === "undefined" || !chrome.runtime) {
    console.error("[PrivacyPal Bridge] chrome.runtime is not available! This script must run in ISOLATED world.");
  }
  function isContextInvalidatedError(error) {
    if (!error)
      return false;
    const errorMsg = error.message || error.toString() || "";
    return errorMsg.includes("Extension context invalidated") || errorMsg.includes("message port closed") || errorMsg.includes("Extension context invalidated");
  }
  function isRuntimeValid() {
    try {
      if (typeof chrome === "undefined" || !chrome || !chrome.runtime) {
        return false;
      }
      const id = chrome.runtime.id;
      return !!id;
    } catch (e) {
      return false;
    }
  }
  window.addEventListener("message", async (event) => {
    if (event.source !== window)
      return;
    const message = event.data;
    if (!message || message.source !== "privacypal-main")
      return;
    console.log("[PrivacyPal Bridge] Received from MAIN:", message.action);
    if (!isRuntimeValid()) {
      window.postMessage({
        source: "privacypal-bridge",
        id: message.id,
        response: {
          success: false,
          error: "Extension context invalidated. Please reload the page.",
          needsReload: true
        }
      }, "*");
      return;
    }
    if (typeof chrome === "undefined" || !chrome.runtime || !chrome.runtime.sendMessage) {
      console.error("[PrivacyPal Bridge] chrome.runtime.sendMessage is not available");
      window.postMessage({
        source: "privacypal-bridge",
        id: message.id,
        response: {
          success: false,
          error: "Chrome runtime API not available. Bridge must run in ISOLATED world."
        }
      }, "*");
      return;
    }
    try {
      let response;
      if (!isRuntimeValid()) {
        window.postMessage({
          source: "privacypal-bridge",
          id: message.id,
          response: {
            success: false,
            error: "Extension context invalidated. Please reload the page.",
            needsReload: true
          }
        }, "*");
        return;
      }
      if (message.action === "getConfig") {
        chrome.storage.local.get(DEFAULT_CONFIG, (config) => {
          if (chrome.runtime.lastError) {
            const errorMsg = chrome.runtime.lastError.message;
            if (isContextInvalidatedError({ message: errorMsg })) {
              window.postMessage({
                source: "privacypal-bridge",
                id: message.id,
                response: {
                  success: false,
                  error: "Extension context invalidated. Please reload the page.",
                  needsReload: true
                }
              }, "*");
              return;
            }
          }
          window.postMessage({
            source: "privacypal-bridge",
            id: message.id,
            response: { config }
          }, "*");
        });
        return;
      } else if (message.action === "getSession") {
        chrome.storage.local.get(["privacypal_session"], (result) => {
          if (chrome.runtime.lastError) {
            const errorMsg = chrome.runtime.lastError.message;
            if (isContextInvalidatedError({ message: errorMsg })) {
              window.postMessage({
                source: "privacypal-bridge",
                id: message.id,
                response: {
                  success: false,
                  error: "Extension context invalidated. Please reload the page.",
                  needsReload: true
                }
              }, "*");
              return;
            }
          }
          window.postMessage({
            source: "privacypal-bridge",
            id: message.id,
            response: { privacypal_session: result.privacypal_session || null }
          }, "*");
        });
        return;
      }
      console.log("[PrivacyPal Bridge] Forwarding to background:", message.action, {
        hasData: !!message.data,
        hasApiKey: !!message.apiKey,
        platform: message.platform
      });
      try {
        const timeoutPromise = new Promise((_, reject) => {
          setTimeout(() => {
            console.error("[PrivacyPal Bridge] Timeout waiting for background response:", message.action);
            reject(new Error("Background script timeout after 90s"));
          }, 9e4);
        });
        const messagePromise = new Promise((resolve, reject) => {
          try {
            console.log("[PrivacyPal Bridge] Sending message to background:", message.action);
            chrome.runtime.sendMessage({
              action: message.action,
              data: message.data,
              platform: message.platform,
              fileData: message.fileData,
              fileName: message.fileName,
              continuationId: message.continuationId,
              hashes: message.hashes,
              apiUrl: message.apiUrl,
              apiKey: message.apiKey
            }, (response2) => {
              if (chrome.runtime.lastError) {
                const errorMsg = chrome.runtime.lastError.message;
                if (isContextInvalidatedError({ message: errorMsg })) {
                  window.postMessage({
                    source: "privacypal-bridge",
                    id: message.id,
                    response: {
                      success: false,
                      error: "Extension context invalidated. Please reload the page.",
                      needsReload: true
                    }
                  }, "*");
                  reject(new Error("Extension context invalidated"));
                  return;
                }
                console.error("[PrivacyPal Bridge] chrome.runtime.lastError:", errorMsg);
                reject(new Error(errorMsg));
                return;
              }
              if (response2 === void 0) {
                console.error("[PrivacyPal Bridge] Background script returned undefined response");
                reject(new Error("Background script did not respond"));
                return;
              }
              resolve(response2);
            });
          } catch (err) {
            if (!isContextInvalidatedError(err)) {
              console.error("[PrivacyPal Bridge] Error sending message:", err);
            }
            reject(err);
          }
        });
        try {
          response = await Promise.race([messagePromise, timeoutPromise]);
          console.log("[PrivacyPal Bridge] Received response from background:", message.action, {
            success: response?.success,
            hasError: !!response?.error
          });
        } catch (raceError) {
          if (raceError.message.includes("timeout")) {
            console.error("[PrivacyPal Bridge] Timeout waiting for background response:", message.action);
            throw raceError;
          }
          throw raceError;
        }
      } catch (sendError) {
        if (isContextInvalidatedError(sendError)) {
          response = {
            success: false,
            error: "Extension context invalidated. Please reload the page.",
            needsReload: true
          };
        } else {
          console.error("[PrivacyPal Bridge] Error sending message to background:", sendError);
          response = { success: false, error: sendError.message || "Failed to communicate with background script" };
        }
      }
      window.postMessage({
        source: "privacypal-bridge",
        id: message.id,
        response
      }, "*");
    } catch (error) {
      const isContextInvalidated = isContextInvalidatedError(error);
      if (!isContextInvalidated) {
        console.error("[PrivacyPal Bridge] Error:", error);
      }
      window.postMessage({
        source: "privacypal-bridge",
        id: message.id,
        response: {
          success: false,
          error: isContextInvalidated ? "Extension context invalidated. Please reload the page." : error.message || "Unknown error",
          needsReload: isContextInvalidated
        }
      }, "*");
    }
  });
  console.log("[PrivacyPal Bridge] Ready to relay messages");
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2NvbnRlbnQvYnJpZGdlLmpzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyIvKipcclxuICogTWVzc2FnZSBCcmlkZ2UgLSBSZWxheXMgbWVzc2FnZXMgYmV0d2VlbiBNQUlOIHdvcmxkIGFuZCBiYWNrZ3JvdW5kIHNjcmlwdFxyXG4gKiBSdW5zIGluIElTT0xBVEVEIHdvcmxkIHdoZXJlIGNocm9tZS5ydW50aW1lIGlzIGF2YWlsYWJsZVxyXG4gKi9cclxuXHJcbi8vIERlZmF1bHQgY29uZmlnIGZvciBnZXRDb25maWcgZmFsbGJhY2tcclxuY29uc3QgREVGQVVMVF9DT05GSUcgPSB7XHJcbiAgZW5hYmxlZDogdHJ1ZSxcclxuICBhcGlVcmw6ICdodHRwczovL2FwaS5wcml2YWN5cGFsLmFpJyxcclxuICBhcGlLZXk6IG51bGwsXHJcbiAgZGVidWc6IHRydWUsXHJcbiAgc2hvd05vdGlmaWNhdGlvbnM6IHRydWVcclxufTtcclxuXHJcbmNvbnNvbGUubG9nKCdbUHJpdmFjeVBhbCBCcmlkZ2VdIEluaXRpYWxpemluZyBtZXNzYWdlIGJyaWRnZScpO1xyXG5cclxuLy8gQ2hlY2sgaWYgY2hyb21lLnJ1bnRpbWUgaXMgYXZhaWxhYmxlXHJcbmlmICh0eXBlb2YgY2hyb21lID09PSAndW5kZWZpbmVkJyB8fCAhY2hyb21lLnJ1bnRpbWUpIHtcclxuICBjb25zb2xlLmVycm9yKCdbUHJpdmFjeVBhbCBCcmlkZ2VdIGNocm9tZS5ydW50aW1lIGlzIG5vdCBhdmFpbGFibGUhIFRoaXMgc2NyaXB0IG11c3QgcnVuIGluIElTT0xBVEVEIHdvcmxkLicpO1xyXG59XHJcblxyXG4vLyBIZWxwZXIgZnVuY3Rpb24gdG8gY2hlY2sgaWYgZXJyb3IgaXMgY29udGV4dCBpbnZhbGlkYXRpb25cclxuZnVuY3Rpb24gaXNDb250ZXh0SW52YWxpZGF0ZWRFcnJvcihlcnJvcikge1xyXG4gIGlmICghZXJyb3IpIHJldHVybiBmYWxzZTtcclxuICBjb25zdCBlcnJvck1zZyA9IGVycm9yLm1lc3NhZ2UgfHwgZXJyb3IudG9TdHJpbmcoKSB8fCAnJztcclxuICByZXR1cm4gZXJyb3JNc2cuaW5jbHVkZXMoJ0V4dGVuc2lvbiBjb250ZXh0IGludmFsaWRhdGVkJykgfHwgXHJcbiAgICAgICAgIGVycm9yTXNnLmluY2x1ZGVzKCdtZXNzYWdlIHBvcnQgY2xvc2VkJykgfHxcclxuICAgICAgICAgZXJyb3JNc2cuaW5jbHVkZXMoJ0V4dGVuc2lvbiBjb250ZXh0IGludmFsaWRhdGVkJyk7XHJcbn1cclxuXHJcbi8vIEhlbHBlciBmdW5jdGlvbiB0byBzYWZlbHkgY2hlY2sgaWYgcnVudGltZSBpcyB2YWxpZFxyXG5mdW5jdGlvbiBpc1J1bnRpbWVWYWxpZCgpIHtcclxuICB0cnkge1xyXG4gICAgaWYgKHR5cGVvZiBjaHJvbWUgPT09ICd1bmRlZmluZWQnIHx8ICFjaHJvbWUgfHwgIWNocm9tZS5ydW50aW1lKSB7XHJcbiAgICAgIHJldHVybiBmYWxzZTtcclxuICAgIH1cclxuICAgIC8vIFRyeSB0byBhY2Nlc3MgcnVudGltZS5pZCAtIGlmIGNvbnRleHQgaXMgaW52YWxpZCwgdGhpcyB3aWxsIHRocm93XHJcbiAgICBjb25zdCBpZCA9IGNocm9tZS5ydW50aW1lLmlkO1xyXG4gICAgcmV0dXJuICEhaWQ7XHJcbiAgfSBjYXRjaCAoZSkge1xyXG4gICAgcmV0dXJuIGZhbHNlO1xyXG4gIH1cclxufVxyXG5cclxuLy8gTGlzdGVuIGZvciBtZXNzYWdlcyBmcm9tIE1BSU4gd29ybGRcclxud2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ21lc3NhZ2UnLCBhc3luYyAoZXZlbnQpID0+IHtcclxuICAvLyBPbmx5IGFjY2VwdCBtZXNzYWdlcyBmcm9tIHNhbWUgb3JpZ2luXHJcbiAgaWYgKGV2ZW50LnNvdXJjZSAhPT0gd2luZG93KSByZXR1cm47XHJcblxyXG4gIGNvbnN0IG1lc3NhZ2UgPSBldmVudC5kYXRhO1xyXG5cclxuICAvLyBPbmx5IGhhbmRsZSBQcml2YWN5UGFsIG1lc3NhZ2VzXHJcbiAgaWYgKCFtZXNzYWdlIHx8IG1lc3NhZ2Uuc291cmNlICE9PSAncHJpdmFjeXBhbC1tYWluJykgcmV0dXJuO1xyXG5cclxuICBjb25zb2xlLmxvZygnW1ByaXZhY3lQYWwgQnJpZGdlXSBSZWNlaXZlZCBmcm9tIE1BSU46JywgbWVzc2FnZS5hY3Rpb24pO1xyXG5cclxuICAvLyBDaGVjayBpZiBydW50aW1lIGlzIHZhbGlkIGJlZm9yZSBkb2luZyBhbnl0aGluZ1xyXG4gIGlmICghaXNSdW50aW1lVmFsaWQoKSkge1xyXG4gICAgLy8gU2lsZW50bHkgcmV0dXJuIHJlbG9hZCByZXF1ZXN0IC0gZG9uJ3QgbG9nIGFzIGVycm9yXHJcbiAgICB3aW5kb3cucG9zdE1lc3NhZ2Uoe1xyXG4gICAgICBzb3VyY2U6ICdwcml2YWN5cGFsLWJyaWRnZScsXHJcbiAgICAgIGlkOiBtZXNzYWdlLmlkLFxyXG4gICAgICByZXNwb25zZToge1xyXG4gICAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxyXG4gICAgICAgIGVycm9yOiAnRXh0ZW5zaW9uIGNvbnRleHQgaW52YWxpZGF0ZWQuIFBsZWFzZSByZWxvYWQgdGhlIHBhZ2UuJyxcclxuICAgICAgICBuZWVkc1JlbG9hZDogdHJ1ZVxyXG4gICAgICB9XHJcbiAgICB9LCAnKicpO1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuXHJcbiAgLy8gQ2hlY2sgaWYgY2hyb21lLnJ1bnRpbWUgaXMgYXZhaWxhYmxlIGJlZm9yZSB1c2luZyBpdFxyXG4gIGlmICh0eXBlb2YgY2hyb21lID09PSAndW5kZWZpbmVkJyB8fCAhY2hyb21lLnJ1bnRpbWUgfHwgIWNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKCdbUHJpdmFjeVBhbCBCcmlkZ2VdIGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlIGlzIG5vdCBhdmFpbGFibGUnKTtcclxuICAgIC8vIFNlbmQgZXJyb3IgYmFjayB0byBNQUlOIHdvcmxkXHJcbiAgICB3aW5kb3cucG9zdE1lc3NhZ2Uoe1xyXG4gICAgICBzb3VyY2U6ICdwcml2YWN5cGFsLWJyaWRnZScsXHJcbiAgICAgIGlkOiBtZXNzYWdlLmlkLFxyXG4gICAgICByZXNwb25zZToge1xyXG4gICAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxyXG4gICAgICAgIGVycm9yOiAnQ2hyb21lIHJ1bnRpbWUgQVBJIG5vdCBhdmFpbGFibGUuIEJyaWRnZSBtdXN0IHJ1biBpbiBJU09MQVRFRCB3b3JsZC4nXHJcbiAgICAgIH1cclxuICAgIH0sICcqJyk7XHJcbiAgICByZXR1cm47XHJcbiAgfVxyXG5cclxuICB0cnkge1xyXG4gICAgbGV0IHJlc3BvbnNlO1xyXG4gICAgXHJcbiAgICAvLyBEb3VibGUtY2hlY2sgcnVudGltZSBpcyBzdGlsbCB2YWxpZCAoaXQgbWlnaHQgaGF2ZSBiZWVuIGludmFsaWRhdGVkIGJldHdlZW4gY2hlY2tzKVxyXG4gICAgaWYgKCFpc1J1bnRpbWVWYWxpZCgpKSB7XHJcbiAgICAgIC8vIFNpbGVudGx5IHJldHVybiByZWxvYWQgcmVxdWVzdFxyXG4gICAgICB3aW5kb3cucG9zdE1lc3NhZ2Uoe1xyXG4gICAgICAgIHNvdXJjZTogJ3ByaXZhY3lwYWwtYnJpZGdlJyxcclxuICAgICAgICBpZDogbWVzc2FnZS5pZCxcclxuICAgICAgICByZXNwb25zZToge1xyXG4gICAgICAgICAgc3VjY2VzczogZmFsc2UsXHJcbiAgICAgICAgICBlcnJvcjogJ0V4dGVuc2lvbiBjb250ZXh0IGludmFsaWRhdGVkLiBQbGVhc2UgcmVsb2FkIHRoZSBwYWdlLicsXHJcbiAgICAgICAgICBuZWVkc1JlbG9hZDogdHJ1ZVxyXG4gICAgICAgIH1cclxuICAgICAgfSwgJyonKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgXHJcbiAgICAvLyBIYW5kbGUgZ2V0Q29uZmlnIGFuZCBnZXRTZXNzaW9uIGRpcmVjdGx5IGluIGJyaWRnZSAodGhleSBuZWVkIHN0b3JhZ2UgYWNjZXNzKVxyXG4gICAgaWYgKG1lc3NhZ2UuYWN0aW9uID09PSAnZ2V0Q29uZmlnJykge1xyXG4gICAgICBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoREVGQVVMVF9DT05GSUcsIChjb25maWcpID0+IHtcclxuICAgICAgICAvLyBDaGVjayBmb3IgY29udGV4dCBpbnZhbGlkYXRpb24gaW4gY2FsbGJhY2tcclxuICAgICAgICBpZiAoY2hyb21lLnJ1bnRpbWUubGFzdEVycm9yKSB7XHJcbiAgICAgICAgICBjb25zdCBlcnJvck1zZyA9IGNocm9tZS5ydW50aW1lLmxhc3RFcnJvci5tZXNzYWdlO1xyXG4gICAgICAgICAgaWYgKGlzQ29udGV4dEludmFsaWRhdGVkRXJyb3IoeyBtZXNzYWdlOiBlcnJvck1zZyB9KSkge1xyXG4gICAgICAgICAgICB3aW5kb3cucG9zdE1lc3NhZ2Uoe1xyXG4gICAgICAgICAgICAgIHNvdXJjZTogJ3ByaXZhY3lwYWwtYnJpZGdlJyxcclxuICAgICAgICAgICAgICBpZDogbWVzc2FnZS5pZCxcclxuICAgICAgICAgICAgICByZXNwb25zZToge1xyXG4gICAgICAgICAgICAgICAgc3VjY2VzczogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICBlcnJvcjogJ0V4dGVuc2lvbiBjb250ZXh0IGludmFsaWRhdGVkLiBQbGVhc2UgcmVsb2FkIHRoZSBwYWdlLicsXHJcbiAgICAgICAgICAgICAgICBuZWVkc1JlbG9hZDogdHJ1ZVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSwgJyonKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICB3aW5kb3cucG9zdE1lc3NhZ2Uoe1xyXG4gICAgICAgICAgc291cmNlOiAncHJpdmFjeXBhbC1icmlkZ2UnLFxyXG4gICAgICAgICAgaWQ6IG1lc3NhZ2UuaWQsXHJcbiAgICAgICAgICByZXNwb25zZTogeyBjb25maWcgfVxyXG4gICAgICAgIH0sICcqJyk7XHJcbiAgICAgIH0pO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9IGVsc2UgaWYgKG1lc3NhZ2UuYWN0aW9uID09PSAnZ2V0U2Vzc2lvbicpIHtcclxuICAgICAgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KFsncHJpdmFjeXBhbF9zZXNzaW9uJ10sIChyZXN1bHQpID0+IHtcclxuICAgICAgICAvLyBDaGVjayBmb3IgY29udGV4dCBpbnZhbGlkYXRpb24gaW4gY2FsbGJhY2tcclxuICAgICAgICBpZiAoY2hyb21lLnJ1bnRpbWUubGFzdEVycm9yKSB7XHJcbiAgICAgICAgICBjb25zdCBlcnJvck1zZyA9IGNocm9tZS5ydW50aW1lLmxhc3RFcnJvci5tZXNzYWdlO1xyXG4gICAgICAgICAgaWYgKGlzQ29udGV4dEludmFsaWRhdGVkRXJyb3IoeyBtZXNzYWdlOiBlcnJvck1zZyB9KSkge1xyXG4gICAgICAgICAgICB3aW5kb3cucG9zdE1lc3NhZ2Uoe1xyXG4gICAgICAgICAgICAgIHNvdXJjZTogJ3ByaXZhY3lwYWwtYnJpZGdlJyxcclxuICAgICAgICAgICAgICBpZDogbWVzc2FnZS5pZCxcclxuICAgICAgICAgICAgICByZXNwb25zZToge1xyXG4gICAgICAgICAgICAgICAgc3VjY2VzczogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICBlcnJvcjogJ0V4dGVuc2lvbiBjb250ZXh0IGludmFsaWRhdGVkLiBQbGVhc2UgcmVsb2FkIHRoZSBwYWdlLicsXHJcbiAgICAgICAgICAgICAgICBuZWVkc1JlbG9hZDogdHJ1ZVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSwgJyonKTtcclxuICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICB3aW5kb3cucG9zdE1lc3NhZ2Uoe1xyXG4gICAgICAgICAgc291cmNlOiAncHJpdmFjeXBhbC1icmlkZ2UnLFxyXG4gICAgICAgICAgaWQ6IG1lc3NhZ2UuaWQsXHJcbiAgICAgICAgICByZXNwb25zZTogeyBwcml2YWN5cGFsX3Nlc3Npb246IHJlc3VsdC5wcml2YWN5cGFsX3Nlc3Npb24gfHwgbnVsbCB9XHJcbiAgICAgICAgfSwgJyonKTtcclxuICAgICAgfSk7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuICAgIFxyXG4gICAgLy8gRm9yd2FyZCBvdGhlciBtZXNzYWdlcyB0byBiYWNrZ3JvdW5kIHNjcmlwdFxyXG4gICAgY29uc29sZS5sb2coJ1tQcml2YWN5UGFsIEJyaWRnZV0gRm9yd2FyZGluZyB0byBiYWNrZ3JvdW5kOicsIG1lc3NhZ2UuYWN0aW9uLCB7XHJcbiAgICAgIGhhc0RhdGE6ICEhbWVzc2FnZS5kYXRhLFxyXG4gICAgICBoYXNBcGlLZXk6ICEhbWVzc2FnZS5hcGlLZXksXHJcbiAgICAgIHBsYXRmb3JtOiBtZXNzYWdlLnBsYXRmb3JtXHJcbiAgICB9KTtcclxuICAgIFxyXG4gICAgdHJ5IHtcclxuICAgICAgLy8gVXNlIGEgdGltZW91dCB3cmFwcGVyIHRvIGVuc3VyZSB3ZSBkb24ndCB3YWl0IGZvcmV2ZXIgKGluY3JlYXNlZCBmb3Igc2xvdyBBUEkpXHJcbiAgICAgIGNvbnN0IHRpbWVvdXRQcm9taXNlID0gbmV3IFByb21pc2UoKF8sIHJlamVjdCkgPT4ge1xyXG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgICAgY29uc29sZS5lcnJvcignW1ByaXZhY3lQYWwgQnJpZGdlXSBUaW1lb3V0IHdhaXRpbmcgZm9yIGJhY2tncm91bmQgcmVzcG9uc2U6JywgbWVzc2FnZS5hY3Rpb24pO1xyXG4gICAgICAgICAgcmVqZWN0KG5ldyBFcnJvcignQmFja2dyb3VuZCBzY3JpcHQgdGltZW91dCBhZnRlciA5MHMnKSk7XHJcbiAgICAgICAgfSwgOTAwMDApO1xyXG4gICAgICB9KTtcclxuICAgICAgXHJcbiAgICAgIGNvbnN0IG1lc3NhZ2VQcm9taXNlID0gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBjb25zb2xlLmxvZygnW1ByaXZhY3lQYWwgQnJpZGdlXSBTZW5kaW5nIG1lc3NhZ2UgdG8gYmFja2dyb3VuZDonLCBtZXNzYWdlLmFjdGlvbik7XHJcbiAgICAgICAgICBjaHJvbWUucnVudGltZS5zZW5kTWVzc2FnZSh7XHJcbiAgICAgICAgICAgIGFjdGlvbjogbWVzc2FnZS5hY3Rpb24sXHJcbiAgICAgICAgICAgIGRhdGE6IG1lc3NhZ2UuZGF0YSxcclxuICAgICAgICAgICAgcGxhdGZvcm06IG1lc3NhZ2UucGxhdGZvcm0sXHJcbiAgICAgICAgICAgIGZpbGVEYXRhOiBtZXNzYWdlLmZpbGVEYXRhLFxyXG4gICAgICAgICAgICBmaWxlTmFtZTogbWVzc2FnZS5maWxlTmFtZSxcclxuICAgICAgICAgICAgY29udGludWF0aW9uSWQ6IG1lc3NhZ2UuY29udGludWF0aW9uSWQsXHJcbiAgICAgICAgICAgIGhhc2hlczogbWVzc2FnZS5oYXNoZXMsXHJcbiAgICAgICAgICAgIGFwaVVybDogbWVzc2FnZS5hcGlVcmwsXHJcbiAgICAgICAgICAgIGFwaUtleTogbWVzc2FnZS5hcGlLZXlcclxuICAgICAgICAgIH0sIChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgICAgICAvLyBDaGVjayBmb3IgZXJyb3JzXHJcbiAgICAgICAgICAgIGlmIChjaHJvbWUucnVudGltZS5sYXN0RXJyb3IpIHtcclxuICAgICAgICAgICAgICBjb25zdCBlcnJvck1zZyA9IGNocm9tZS5ydW50aW1lLmxhc3RFcnJvci5tZXNzYWdlO1xyXG4gICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgIC8vIEhhbmRsZSBleHRlbnNpb24gY29udGV4dCBpbnZhbGlkYXRlZCAoZXh0ZW5zaW9uIHdhcyByZWxvYWRlZClcclxuICAgICAgICAgICAgICAvLyBEb24ndCBsb2cgYXMgZXJyb3IgLSB0aGlzIGlzIGV4cGVjdGVkIHdoZW4gZXh0ZW5zaW9uIHJlbG9hZHNcclxuICAgICAgICAgICAgICBpZiAoaXNDb250ZXh0SW52YWxpZGF0ZWRFcnJvcih7IG1lc3NhZ2U6IGVycm9yTXNnIH0pKSB7XHJcbiAgICAgICAgICAgICAgICAvLyBTaWxlbnRseSBub3RpZnkgdGhlIHBhZ2UgdGhhdCBleHRlbnNpb24gbmVlZHMgdG8gYmUgcmVsb2FkZWRcclxuICAgICAgICAgICAgICAgIHdpbmRvdy5wb3N0TWVzc2FnZSh7XHJcbiAgICAgICAgICAgICAgICAgIHNvdXJjZTogJ3ByaXZhY3lwYWwtYnJpZGdlJyxcclxuICAgICAgICAgICAgICAgICAgaWQ6IG1lc3NhZ2UuaWQsXHJcbiAgICAgICAgICAgICAgICAgIHJlc3BvbnNlOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgc3VjY2VzczogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICAgICAgZXJyb3I6ICdFeHRlbnNpb24gY29udGV4dCBpbnZhbGlkYXRlZC4gUGxlYXNlIHJlbG9hZCB0aGUgcGFnZS4nLFxyXG4gICAgICAgICAgICAgICAgICAgIG5lZWRzUmVsb2FkOiB0cnVlXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0sICcqJyk7XHJcbiAgICAgICAgICAgICAgICAvLyBSZWplY3Qgd2l0aCBhIHNwZWNpYWwgZXJyb3IgdGhhdCB3b24ndCBiZSBsb2dnZWRcclxuICAgICAgICAgICAgICAgIHJlamVjdChuZXcgRXJyb3IoJ0V4dGVuc2lvbiBjb250ZXh0IGludmFsaWRhdGVkJykpO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAvLyBMb2cgb3RoZXIgZXJyb3JzXHJcbiAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignW1ByaXZhY3lQYWwgQnJpZGdlXSBjaHJvbWUucnVudGltZS5sYXN0RXJyb3I6JywgZXJyb3JNc2cpO1xyXG4gICAgICAgICAgICAgIHJlamVjdChuZXcgRXJyb3IoZXJyb3JNc2cpKTtcclxuICAgICAgICAgICAgICByZXR1cm47XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIC8vIENoZWNrIGlmIHJlc3BvbnNlIGlzIHVuZGVmaW5lZCAoYmFja2dyb3VuZCBzY3JpcHQgZGlkbid0IHJlc3BvbmQpXHJcbiAgICAgICAgICAgIGlmIChyZXNwb25zZSA9PT0gdW5kZWZpbmVkKSB7XHJcbiAgICAgICAgICAgICAgY29uc29sZS5lcnJvcignW1ByaXZhY3lQYWwgQnJpZGdlXSBCYWNrZ3JvdW5kIHNjcmlwdCByZXR1cm5lZCB1bmRlZmluZWQgcmVzcG9uc2UnKTtcclxuICAgICAgICAgICAgICByZWplY3QobmV3IEVycm9yKCdCYWNrZ3JvdW5kIHNjcmlwdCBkaWQgbm90IHJlc3BvbmQnKSk7XHJcbiAgICAgICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgICAgICByZXNvbHZlKHJlc3BvbnNlKTtcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgICAgLy8gRG9uJ3QgbG9nIGNvbnRleHQgaW52YWxpZGF0aW9uIGVycm9yc1xyXG4gICAgICAgICAgaWYgKCFpc0NvbnRleHRJbnZhbGlkYXRlZEVycm9yKGVycikpIHtcclxuICAgICAgICAgICAgY29uc29sZS5lcnJvcignW1ByaXZhY3lQYWwgQnJpZGdlXSBFcnJvciBzZW5kaW5nIG1lc3NhZ2U6JywgZXJyKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIHJlamVjdChlcnIpO1xyXG4gICAgICAgIH1cclxuICAgICAgfSk7XHJcbiAgICAgIFxyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHJlc3BvbnNlID0gYXdhaXQgUHJvbWlzZS5yYWNlKFttZXNzYWdlUHJvbWlzZSwgdGltZW91dFByb21pc2VdKTtcclxuICAgICAgICBjb25zb2xlLmxvZygnW1ByaXZhY3lQYWwgQnJpZGdlXSBSZWNlaXZlZCByZXNwb25zZSBmcm9tIGJhY2tncm91bmQ6JywgbWVzc2FnZS5hY3Rpb24sIHtcclxuICAgICAgICAgIHN1Y2Nlc3M6IHJlc3BvbnNlPy5zdWNjZXNzLFxyXG4gICAgICAgICAgaGFzRXJyb3I6ICEhcmVzcG9uc2U/LmVycm9yXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gY2F0Y2ggKHJhY2VFcnJvcikge1xyXG4gICAgICAgIC8vIElmIHRpbWVvdXQgd2lucyB0aGUgcmFjZSwgcmVqZWN0IHdpdGggdGltZW91dCBlcnJvclxyXG4gICAgICAgIGlmIChyYWNlRXJyb3IubWVzc2FnZS5pbmNsdWRlcygndGltZW91dCcpKSB7XHJcbiAgICAgICAgICBjb25zb2xlLmVycm9yKCdbUHJpdmFjeVBhbCBCcmlkZ2VdIFRpbWVvdXQgd2FpdGluZyBmb3IgYmFja2dyb3VuZCByZXNwb25zZTonLCBtZXNzYWdlLmFjdGlvbik7XHJcbiAgICAgICAgICB0aHJvdyByYWNlRXJyb3I7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRocm93IHJhY2VFcnJvcjtcclxuICAgICAgfVxyXG4gICAgfSBjYXRjaCAoc2VuZEVycm9yKSB7XHJcbiAgICAgIC8vIENoZWNrIGlmIGl0J3MgYW4gZXh0ZW5zaW9uIGNvbnRleHQgaW52YWxpZGF0ZWQgZXJyb3JcclxuICAgICAgaWYgKGlzQ29udGV4dEludmFsaWRhdGVkRXJyb3Ioc2VuZEVycm9yKSkge1xyXG4gICAgICAgIC8vIERvbid0IGxvZyBhcyBlcnJvciAtIHRoaXMgaXMgZXhwZWN0ZWQgd2hlbiBleHRlbnNpb24gcmVsb2Fkc1xyXG4gICAgICAgIHJlc3BvbnNlID0ge1xyXG4gICAgICAgICAgc3VjY2VzczogZmFsc2UsXHJcbiAgICAgICAgICBlcnJvcjogJ0V4dGVuc2lvbiBjb250ZXh0IGludmFsaWRhdGVkLiBQbGVhc2UgcmVsb2FkIHRoZSBwYWdlLicsXHJcbiAgICAgICAgICBuZWVkc1JlbG9hZDogdHJ1ZVxyXG4gICAgICAgIH07XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgLy8gTG9nIG90aGVyIGVycm9yc1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ1tQcml2YWN5UGFsIEJyaWRnZV0gRXJyb3Igc2VuZGluZyBtZXNzYWdlIHRvIGJhY2tncm91bmQ6Jywgc2VuZEVycm9yKTtcclxuICAgICAgICByZXNwb25zZSA9IHsgc3VjY2VzczogZmFsc2UsIGVycm9yOiBzZW5kRXJyb3IubWVzc2FnZSB8fCAnRmFpbGVkIHRvIGNvbW11bmljYXRlIHdpdGggYmFja2dyb3VuZCBzY3JpcHQnIH07XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvLyBTZW5kIHJlc3BvbnNlIGJhY2sgdG8gTUFJTiB3b3JsZFxyXG4gICAgd2luZG93LnBvc3RNZXNzYWdlKHtcclxuICAgICAgc291cmNlOiAncHJpdmFjeXBhbC1icmlkZ2UnLFxyXG4gICAgICBpZDogbWVzc2FnZS5pZCxcclxuICAgICAgcmVzcG9uc2VcclxuICAgIH0sICcqJyk7XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIC8vIENoZWNrIGlmIGl0J3MgYW4gZXh0ZW5zaW9uIGNvbnRleHQgaW52YWxpZGF0ZWQgZXJyb3JcclxuICAgIGNvbnN0IGlzQ29udGV4dEludmFsaWRhdGVkID0gaXNDb250ZXh0SW52YWxpZGF0ZWRFcnJvcihlcnJvcik7XHJcbiAgICBcclxuICAgIC8vIENvbXBsZXRlbHkgc3VwcHJlc3MgY29udGV4dCBpbnZhbGlkYXRpb24gZXJyb3JzIC0gZG9uJ3QgbG9nIHRoZW0gYXQgYWxsXHJcbiAgICBpZiAoIWlzQ29udGV4dEludmFsaWRhdGVkKSB7XHJcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ1tQcml2YWN5UGFsIEJyaWRnZV0gRXJyb3I6JywgZXJyb3IpO1xyXG4gICAgfVxyXG4gICAgXHJcbiAgICAvLyBTZW5kIGVycm9yIGJhY2sgdG8gTUFJTiB3b3JsZFxyXG4gICAgd2luZG93LnBvc3RNZXNzYWdlKHtcclxuICAgICAgc291cmNlOiAncHJpdmFjeXBhbC1icmlkZ2UnLFxyXG4gICAgICBpZDogbWVzc2FnZS5pZCxcclxuICAgICAgcmVzcG9uc2U6IHtcclxuICAgICAgICBzdWNjZXNzOiBmYWxzZSxcclxuICAgICAgICBlcnJvcjogaXNDb250ZXh0SW52YWxpZGF0ZWQgPyAnRXh0ZW5zaW9uIGNvbnRleHQgaW52YWxpZGF0ZWQuIFBsZWFzZSByZWxvYWQgdGhlIHBhZ2UuJyA6IChlcnJvci5tZXNzYWdlIHx8ICdVbmtub3duIGVycm9yJyksXHJcbiAgICAgICAgbmVlZHNSZWxvYWQ6IGlzQ29udGV4dEludmFsaWRhdGVkXHJcbiAgICAgIH1cclxuICAgIH0sICcqJyk7XHJcbiAgfVxyXG59KTtcclxuXHJcbmNvbnNvbGUubG9nKCdbUHJpdmFjeVBhbCBCcmlkZ2VdIFJlYWR5IHRvIHJlbGF5IG1lc3NhZ2VzJyk7XHJcbiJdLAogICJtYXBwaW5ncyI6ICI7QUFNQSxRQUFNLGlCQUFpQjtBQUFBLElBQ3JCLFNBQVM7QUFBQSxJQUNULFFBQVE7QUFBQSxJQUNSLFFBQVE7QUFBQSxJQUNSLE9BQU87QUFBQSxJQUNQLG1CQUFtQjtBQUFBLEVBQ3JCO0FBRUEsVUFBUSxJQUFJLGlEQUFpRDtBQUc3RCxNQUFJLE9BQU8sV0FBVyxlQUFlLENBQUMsT0FBTyxTQUFTO0FBQ3BELFlBQVEsTUFBTSw4RkFBOEY7QUFBQSxFQUM5RztBQUdBLFdBQVMsMEJBQTBCLE9BQU87QUFDeEMsUUFBSSxDQUFDO0FBQU8sYUFBTztBQUNuQixVQUFNLFdBQVcsTUFBTSxXQUFXLE1BQU0sU0FBUyxLQUFLO0FBQ3RELFdBQU8sU0FBUyxTQUFTLCtCQUErQixLQUNqRCxTQUFTLFNBQVMscUJBQXFCLEtBQ3ZDLFNBQVMsU0FBUywrQkFBK0I7QUFBQSxFQUMxRDtBQUdBLFdBQVMsaUJBQWlCO0FBQ3hCLFFBQUk7QUFDRixVQUFJLE9BQU8sV0FBVyxlQUFlLENBQUMsVUFBVSxDQUFDLE9BQU8sU0FBUztBQUMvRCxlQUFPO0FBQUEsTUFDVDtBQUVBLFlBQU0sS0FBSyxPQUFPLFFBQVE7QUFDMUIsYUFBTyxDQUFDLENBQUM7QUFBQSxJQUNYLFNBQVMsR0FBRztBQUNWLGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUdBLFNBQU8saUJBQWlCLFdBQVcsT0FBTyxVQUFVO0FBRWxELFFBQUksTUFBTSxXQUFXO0FBQVE7QUFFN0IsVUFBTSxVQUFVLE1BQU07QUFHdEIsUUFBSSxDQUFDLFdBQVcsUUFBUSxXQUFXO0FBQW1CO0FBRXRELFlBQVEsSUFBSSwyQ0FBMkMsUUFBUSxNQUFNO0FBR3JFLFFBQUksQ0FBQyxlQUFlLEdBQUc7QUFFckIsYUFBTyxZQUFZO0FBQUEsUUFDakIsUUFBUTtBQUFBLFFBQ1IsSUFBSSxRQUFRO0FBQUEsUUFDWixVQUFVO0FBQUEsVUFDUixTQUFTO0FBQUEsVUFDVCxPQUFPO0FBQUEsVUFDUCxhQUFhO0FBQUEsUUFDZjtBQUFBLE1BQ0YsR0FBRyxHQUFHO0FBQ047QUFBQSxJQUNGO0FBR0EsUUFBSSxPQUFPLFdBQVcsZUFBZSxDQUFDLE9BQU8sV0FBVyxDQUFDLE9BQU8sUUFBUSxhQUFhO0FBQ25GLGNBQVEsTUFBTSxpRUFBaUU7QUFFL0UsYUFBTyxZQUFZO0FBQUEsUUFDakIsUUFBUTtBQUFBLFFBQ1IsSUFBSSxRQUFRO0FBQUEsUUFDWixVQUFVO0FBQUEsVUFDUixTQUFTO0FBQUEsVUFDVCxPQUFPO0FBQUEsUUFDVDtBQUFBLE1BQ0YsR0FBRyxHQUFHO0FBQ047QUFBQSxJQUNGO0FBRUEsUUFBSTtBQUNGLFVBQUk7QUFHSixVQUFJLENBQUMsZUFBZSxHQUFHO0FBRXJCLGVBQU8sWUFBWTtBQUFBLFVBQ2pCLFFBQVE7QUFBQSxVQUNSLElBQUksUUFBUTtBQUFBLFVBQ1osVUFBVTtBQUFBLFlBQ1IsU0FBUztBQUFBLFlBQ1QsT0FBTztBQUFBLFlBQ1AsYUFBYTtBQUFBLFVBQ2Y7QUFBQSxRQUNGLEdBQUcsR0FBRztBQUNOO0FBQUEsTUFDRjtBQUdBLFVBQUksUUFBUSxXQUFXLGFBQWE7QUFDbEMsZUFBTyxRQUFRLE1BQU0sSUFBSSxnQkFBZ0IsQ0FBQyxXQUFXO0FBRW5ELGNBQUksT0FBTyxRQUFRLFdBQVc7QUFDNUIsa0JBQU0sV0FBVyxPQUFPLFFBQVEsVUFBVTtBQUMxQyxnQkFBSSwwQkFBMEIsRUFBRSxTQUFTLFNBQVMsQ0FBQyxHQUFHO0FBQ3BELHFCQUFPLFlBQVk7QUFBQSxnQkFDakIsUUFBUTtBQUFBLGdCQUNSLElBQUksUUFBUTtBQUFBLGdCQUNaLFVBQVU7QUFBQSxrQkFDUixTQUFTO0FBQUEsa0JBQ1QsT0FBTztBQUFBLGtCQUNQLGFBQWE7QUFBQSxnQkFDZjtBQUFBLGNBQ0YsR0FBRyxHQUFHO0FBQ047QUFBQSxZQUNGO0FBQUEsVUFDRjtBQUNBLGlCQUFPLFlBQVk7QUFBQSxZQUNqQixRQUFRO0FBQUEsWUFDUixJQUFJLFFBQVE7QUFBQSxZQUNaLFVBQVUsRUFBRSxPQUFPO0FBQUEsVUFDckIsR0FBRyxHQUFHO0FBQUEsUUFDUixDQUFDO0FBQ0Q7QUFBQSxNQUNGLFdBQVcsUUFBUSxXQUFXLGNBQWM7QUFDMUMsZUFBTyxRQUFRLE1BQU0sSUFBSSxDQUFDLG9CQUFvQixHQUFHLENBQUMsV0FBVztBQUUzRCxjQUFJLE9BQU8sUUFBUSxXQUFXO0FBQzVCLGtCQUFNLFdBQVcsT0FBTyxRQUFRLFVBQVU7QUFDMUMsZ0JBQUksMEJBQTBCLEVBQUUsU0FBUyxTQUFTLENBQUMsR0FBRztBQUNwRCxxQkFBTyxZQUFZO0FBQUEsZ0JBQ2pCLFFBQVE7QUFBQSxnQkFDUixJQUFJLFFBQVE7QUFBQSxnQkFDWixVQUFVO0FBQUEsa0JBQ1IsU0FBUztBQUFBLGtCQUNULE9BQU87QUFBQSxrQkFDUCxhQUFhO0FBQUEsZ0JBQ2Y7QUFBQSxjQUNGLEdBQUcsR0FBRztBQUNOO0FBQUEsWUFDRjtBQUFBLFVBQ0Y7QUFDQSxpQkFBTyxZQUFZO0FBQUEsWUFDakIsUUFBUTtBQUFBLFlBQ1IsSUFBSSxRQUFRO0FBQUEsWUFDWixVQUFVLEVBQUUsb0JBQW9CLE9BQU8sc0JBQXNCLEtBQUs7QUFBQSxVQUNwRSxHQUFHLEdBQUc7QUFBQSxRQUNSLENBQUM7QUFDRDtBQUFBLE1BQ0Y7QUFHQSxjQUFRLElBQUksaURBQWlELFFBQVEsUUFBUTtBQUFBLFFBQzNFLFNBQVMsQ0FBQyxDQUFDLFFBQVE7QUFBQSxRQUNuQixXQUFXLENBQUMsQ0FBQyxRQUFRO0FBQUEsUUFDckIsVUFBVSxRQUFRO0FBQUEsTUFDcEIsQ0FBQztBQUVELFVBQUk7QUFFRixjQUFNLGlCQUFpQixJQUFJLFFBQVEsQ0FBQyxHQUFHLFdBQVc7QUFDaEQscUJBQVcsTUFBTTtBQUNmLG9CQUFRLE1BQU0sZ0VBQWdFLFFBQVEsTUFBTTtBQUM1RixtQkFBTyxJQUFJLE1BQU0scUNBQXFDLENBQUM7QUFBQSxVQUN6RCxHQUFHLEdBQUs7QUFBQSxRQUNWLENBQUM7QUFFRCxjQUFNLGlCQUFpQixJQUFJLFFBQVEsQ0FBQyxTQUFTLFdBQVc7QUFDdEQsY0FBSTtBQUNGLG9CQUFRLElBQUksc0RBQXNELFFBQVEsTUFBTTtBQUNoRixtQkFBTyxRQUFRLFlBQVk7QUFBQSxjQUN6QixRQUFRLFFBQVE7QUFBQSxjQUNoQixNQUFNLFFBQVE7QUFBQSxjQUNkLFVBQVUsUUFBUTtBQUFBLGNBQ2xCLFVBQVUsUUFBUTtBQUFBLGNBQ2xCLFVBQVUsUUFBUTtBQUFBLGNBQ2xCLGdCQUFnQixRQUFRO0FBQUEsY0FDeEIsUUFBUSxRQUFRO0FBQUEsY0FDaEIsUUFBUSxRQUFRO0FBQUEsY0FDaEIsUUFBUSxRQUFRO0FBQUEsWUFDbEIsR0FBRyxDQUFDQSxjQUFhO0FBRWYsa0JBQUksT0FBTyxRQUFRLFdBQVc7QUFDNUIsc0JBQU0sV0FBVyxPQUFPLFFBQVEsVUFBVTtBQUkxQyxvQkFBSSwwQkFBMEIsRUFBRSxTQUFTLFNBQVMsQ0FBQyxHQUFHO0FBRXBELHlCQUFPLFlBQVk7QUFBQSxvQkFDakIsUUFBUTtBQUFBLG9CQUNSLElBQUksUUFBUTtBQUFBLG9CQUNaLFVBQVU7QUFBQSxzQkFDUixTQUFTO0FBQUEsc0JBQ1QsT0FBTztBQUFBLHNCQUNQLGFBQWE7QUFBQSxvQkFDZjtBQUFBLGtCQUNGLEdBQUcsR0FBRztBQUVOLHlCQUFPLElBQUksTUFBTSwrQkFBK0IsQ0FBQztBQUNqRDtBQUFBLGdCQUNGO0FBR0Esd0JBQVEsTUFBTSxpREFBaUQsUUFBUTtBQUN2RSx1QkFBTyxJQUFJLE1BQU0sUUFBUSxDQUFDO0FBQzFCO0FBQUEsY0FDRjtBQUdBLGtCQUFJQSxjQUFhLFFBQVc7QUFDMUIsd0JBQVEsTUFBTSxtRUFBbUU7QUFDakYsdUJBQU8sSUFBSSxNQUFNLG1DQUFtQyxDQUFDO0FBQ3JEO0FBQUEsY0FDRjtBQUVBLHNCQUFRQSxTQUFRO0FBQUEsWUFDbEIsQ0FBQztBQUFBLFVBQ0gsU0FBUyxLQUFLO0FBRVosZ0JBQUksQ0FBQywwQkFBMEIsR0FBRyxHQUFHO0FBQ25DLHNCQUFRLE1BQU0sOENBQThDLEdBQUc7QUFBQSxZQUNqRTtBQUNBLG1CQUFPLEdBQUc7QUFBQSxVQUNaO0FBQUEsUUFDRixDQUFDO0FBRUQsWUFBSTtBQUNGLHFCQUFXLE1BQU0sUUFBUSxLQUFLLENBQUMsZ0JBQWdCLGNBQWMsQ0FBQztBQUM5RCxrQkFBUSxJQUFJLDBEQUEwRCxRQUFRLFFBQVE7QUFBQSxZQUNwRixTQUFTLFVBQVU7QUFBQSxZQUNuQixVQUFVLENBQUMsQ0FBQyxVQUFVO0FBQUEsVUFDeEIsQ0FBQztBQUFBLFFBQ0gsU0FBUyxXQUFXO0FBRWxCLGNBQUksVUFBVSxRQUFRLFNBQVMsU0FBUyxHQUFHO0FBQ3pDLG9CQUFRLE1BQU0sZ0VBQWdFLFFBQVEsTUFBTTtBQUM1RixrQkFBTTtBQUFBLFVBQ1I7QUFDQSxnQkFBTTtBQUFBLFFBQ1I7QUFBQSxNQUNGLFNBQVMsV0FBVztBQUVsQixZQUFJLDBCQUEwQixTQUFTLEdBQUc7QUFFeEMscUJBQVc7QUFBQSxZQUNULFNBQVM7QUFBQSxZQUNULE9BQU87QUFBQSxZQUNQLGFBQWE7QUFBQSxVQUNmO0FBQUEsUUFDRixPQUFPO0FBRUwsa0JBQVEsTUFBTSw0REFBNEQsU0FBUztBQUNuRixxQkFBVyxFQUFFLFNBQVMsT0FBTyxPQUFPLFVBQVUsV0FBVywrQ0FBK0M7QUFBQSxRQUMxRztBQUFBLE1BQ0Y7QUFHQSxhQUFPLFlBQVk7QUFBQSxRQUNqQixRQUFRO0FBQUEsUUFDUixJQUFJLFFBQVE7QUFBQSxRQUNaO0FBQUEsTUFDRixHQUFHLEdBQUc7QUFBQSxJQUNSLFNBQVMsT0FBTztBQUVkLFlBQU0sdUJBQXVCLDBCQUEwQixLQUFLO0FBRzVELFVBQUksQ0FBQyxzQkFBc0I7QUFDekIsZ0JBQVEsTUFBTSw4QkFBOEIsS0FBSztBQUFBLE1BQ25EO0FBR0EsYUFBTyxZQUFZO0FBQUEsUUFDakIsUUFBUTtBQUFBLFFBQ1IsSUFBSSxRQUFRO0FBQUEsUUFDWixVQUFVO0FBQUEsVUFDUixTQUFTO0FBQUEsVUFDVCxPQUFPLHVCQUF1QiwyREFBNEQsTUFBTSxXQUFXO0FBQUEsVUFDM0csYUFBYTtBQUFBLFFBQ2Y7QUFBQSxNQUNGLEdBQUcsR0FBRztBQUFBLElBQ1I7QUFBQSxFQUNGLENBQUM7QUFFRCxVQUFRLElBQUksNkNBQTZDOyIsCiAgIm5hbWVzIjogWyJyZXNwb25zZSJdCn0K
