(() => {
  const DEFAULT_CONFIG = {
    enabled: true,
    apiUrl: "http://localhost:42026",
    // 'https://api.privacypal.ai',
    apiKey: null,
    debug: true,
    showNotifications: true
  };
  function isContextInvalidatedError(error) {
    if (!error)
      return false;
    const errorMsg = error.message || error.toString() || "";
    return errorMsg.includes("Extension context invalidated") || errorMsg.includes("message port closed") || errorMsg.includes("Extension context invalidated");
  }
  function isRuntimeValid() {
    try {
      if (typeof chrome === "undefined" || !chrome || !chrome.runtime) {
        return false;
      }
      const id = chrome.runtime.id;
      return !!id;
    } catch (e) {
      return false;
    }
  }
  function isEdgeBrowser() {
    return navigator.userAgent.includes("Edg/");
  }
  const PING_CONFIG = isEdgeBrowser() ? {
    timeout: 5e3,
    // 5 seconds for Edge
    maxRetries: 3,
    // 3 retry attempts
    retryDelay: 1e3,
    // 1 second between retries
    wakeUpDelay: 500
    // 500ms delay before first ping
  } : {
    timeout: 2e3,
    // 2 seconds for Chrome (unchanged)
    maxRetries: 0,
    // No retries for Chrome (unchanged)
    retryDelay: 0,
    // No delay for Chrome (unchanged)
    wakeUpDelay: 0
    // No wake-up delay for Chrome (unchanged)
  };
  async function wakeServiceWorker() {
    if (PING_CONFIG.wakeUpDelay > 0) {
      try {
        await new Promise((resolve) => {
          chrome.storage.local.get(["keepAlive"], () => {
            resolve();
          });
        });
      } catch (e) {
      }
      await new Promise((resolve) => setTimeout(resolve, PING_CONFIG.wakeUpDelay));
    }
  }
  async function pingServiceWorker() {
    await wakeServiceWorker();
    const maxRetries = PING_CONFIG.maxRetries;
    const timeout = PING_CONFIG.timeout;
    const retryDelay = PING_CONFIG.retryDelay;
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      const isAlive = await new Promise((resolve) => {
        if (!isRuntimeValid()) {
          resolve(false);
          return;
        }
        const timeoutId = setTimeout(() => {
          resolve(false);
        }, timeout);
        try {
          chrome.runtime.sendMessage({ action: "ping" }, (response) => {
            clearTimeout(timeoutId);
            if (chrome.runtime.lastError) {
              resolve(false);
            } else {
              resolve(response && response.pong === true);
            }
          });
        } catch (err) {
          clearTimeout(timeoutId);
          resolve(false);
        }
      });
      if (isAlive) {
        return true;
      }
      if (attempt < maxRetries && retryDelay > 0) {
        await new Promise((resolve) => setTimeout(resolve, retryDelay * (attempt + 1)));
      }
    }
    return false;
  }
  window.addEventListener("message", async (event) => {
    if (event.source !== window)
      return;
    const message = event.data;
    if (!message || message.source !== "privacypal-main")
      return;
    if (!isRuntimeValid()) {
      window.postMessage({
        source: "privacypal-bridge",
        id: message.id,
        response: {
          success: false,
          error: "Extension context invalidated. Please reload the page.",
          needsReload: true
        }
      }, "*");
      return;
    }
    if (typeof chrome === "undefined" || !chrome.runtime || !chrome.runtime.sendMessage) {
      window.postMessage({
        source: "privacypal-bridge",
        id: message.id,
        response: {
          success: false,
          error: "Chrome runtime API not available. Bridge must run in ISOLATED world."
        }
      }, "*");
      return;
    }
    try {
      let response;
      if (!isRuntimeValid()) {
        window.postMessage({
          source: "privacypal-bridge",
          id: message.id,
          response: {
            success: false,
            error: "Extension context invalidated. Please reload the page.",
            needsReload: true
          }
        }, "*");
        return;
      }
      if (message.action === "getConfig") {
        chrome.storage.local.get(DEFAULT_CONFIG, (config) => {
          if (chrome.runtime.lastError) {
            const errorMsg = chrome.runtime.lastError.message;
            if (isContextInvalidatedError({ message: errorMsg })) {
              window.postMessage({
                source: "privacypal-bridge",
                id: message.id,
                response: {
                  success: false,
                  error: "Extension context invalidated. Please reload the page.",
                  needsReload: true
                }
              }, "*");
              return;
            }
          }
          window.postMessage({
            source: "privacypal-bridge",
            id: message.id,
            response: { config }
          }, "*");
        });
        return;
      } else if (message.action === "getSession") {
        chrome.storage.local.get(["privacypal_session"], (result) => {
          if (chrome.runtime.lastError) {
            const errorMsg = chrome.runtime.lastError.message;
            if (isContextInvalidatedError({ message: errorMsg })) {
              window.postMessage({
                source: "privacypal-bridge",
                id: message.id,
                response: {
                  success: false,
                  error: "Extension context invalidated. Please reload the page.",
                  needsReload: true
                }
              }, "*");
              return;
            }
          }
          window.postMessage({
            source: "privacypal-bridge",
            id: message.id,
            response: { privacypal_session: result.privacypal_session || null }
          }, "*");
        });
        return;
      } else if (message.action === "pingServiceWorker") {
        (async () => {
          try {
            const isAlive = await pingServiceWorker();
            window.postMessage({
              source: "privacypal-bridge",
              id: message.id,
              response: { success: isAlive, pong: isAlive }
            }, "*");
          } catch (error) {
            window.postMessage({
              source: "privacypal-bridge",
              id: message.id,
              response: { success: false, pong: false, error: error.message }
            }, "*");
          }
        })();
        return true;
      }
      const requiresServiceWorker = message.action === "encodeData" || message.action === "encodeFile";
      if (requiresServiceWorker) {
        const isAlive = await pingServiceWorker();
        if (!isAlive) {
          response = {
            success: false,
            error: "Service worker is not responding. Please reload the page or extension. This prevents CORS errors in Edge."
          };
          window.postMessage({
            source: "privacypal-bridge",
            id: message.id,
            response
          }, "*");
          return;
        }
        if (isEdgeBrowser() && PING_CONFIG.wakeUpDelay > 0) {
          await new Promise((resolve) => setTimeout(resolve, 100));
        }
      }
      try {
        const timeoutPromise = new Promise((_, reject) => {
          setTimeout(() => {
            reject(new Error("Background script timeout after 90s"));
          }, 9e4);
        });
        const messagePromise = new Promise((resolve, reject) => {
          try {
            chrome.runtime.sendMessage({
              action: message.action,
              data: message.data,
              platform: message.platform,
              model: message.model,
              files: message.files,
              // Pass file information
              continuationId: message.continuationId,
              sessionContinuationId: message.sessionContinuationId,
              // CRITICAL: Forward sessionContinuationId for session grouping
              tokensIn: message.tokensIn,
              tokensOut: message.tokensOut,
              fileData: message.fileData,
              fileName: message.fileName,
              hashes: message.hashes,
              apiUrl: message.apiUrl,
              apiKey: message.apiKey
            }, (response2) => {
              if (chrome.runtime.lastError) {
                const errorMsg = chrome.runtime.lastError.message;
                if (isContextInvalidatedError({ message: errorMsg })) {
                  window.postMessage({
                    source: "privacypal-bridge",
                    id: message.id,
                    response: {
                      success: false,
                      error: "Extension context invalidated. Please reload the page.",
                      needsReload: true
                    }
                  }, "*");
                  reject(new Error("Extension context invalidated"));
                  return;
                }
                reject(new Error(errorMsg));
                return;
              }
              if (response2 === void 0) {
                reject(new Error("Background script did not respond"));
                return;
              }
              resolve(response2);
            });
          } catch (err) {
            reject(err);
          }
        });
        try {
          response = await Promise.race([messagePromise, timeoutPromise]);
        } catch (raceError) {
          throw raceError;
        }
      } catch (sendError) {
        if (isContextInvalidatedError(sendError)) {
          response = {
            success: false,
            error: "Extension context invalidated. Please reload the page.",
            needsReload: true
          };
        } else {
          response = { success: false, error: sendError.message || "Failed to communicate with background script" };
        }
      }
      window.postMessage({
        source: "privacypal-bridge",
        id: message.id,
        response
      }, "*");
    } catch (error) {
      const isContextInvalidated = isContextInvalidatedError(error);
      window.postMessage({
        source: "privacypal-bridge",
        id: message.id,
        response: {
          success: false,
          error: isContextInvalidated ? "Extension context invalidated. Please reload the page." : error.message || "Unknown error",
          needsReload: isContextInvalidated
        }
      }, "*");
    }
  });
})();
