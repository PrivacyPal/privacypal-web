
        // Buffer polyfill for browser (popup context)
        if (typeof globalThis !== 'undefined' && typeof Buffer === 'undefined') {
          globalThis.Buffer = {
            from: (data, encoding) => {
              if (typeof data === 'string') {
                const encoder = new TextEncoder();
                return encoder.encode(data);
              }
              return data;
            },
            isBuffer: () => false
          };
        }
      
(() => {
  // src/config/config.js
  var BUILD_MODE = "production";
  var ENDPOINTS = {
    development: {
      apiUrl: "http://localhost:42026",
      userPortalUrl: "http://localhost:5174"
    },
    production: {
      apiUrl: "https://api.privacypal.ai",
      userPortalUrl: "https://portal.privacypal.ai"
    }
  };
  var DEFAULT_ENDPOINTS = BUILD_MODE === "development" ? ENDPOINTS.development : ENDPOINTS.production;
  var IS_DEV_BUILD = BUILD_MODE === "development";
  async function loadConfig() {
    if (IS_DEV_BUILD) {
      return DEFAULT_ENDPOINTS;
    }
    try {
      const stored = await chrome.storage.local.get(["apiUrl", "userPortalUrl"]);
      return {
        apiUrl: stored.apiUrl || DEFAULT_ENDPOINTS.apiUrl,
        userPortalUrl: stored.userPortalUrl || DEFAULT_ENDPOINTS.userPortalUrl
      };
    } catch (error) {
      return DEFAULT_ENDPOINTS;
    }
  }
  async function saveConfig(config) {
    try {
      await chrome.storage.local.set({
        apiUrl: config.apiUrl,
        userPortalUrl: config.userPortalUrl
      });
      return true;
    } catch (error) {
      return false;
    }
  }

  // src/auth/auth-service.js
  var AuthService = class {
    constructor() {
      this.jwtTokens = null;
      this.userProfile = null;
      this.tokenRefreshTimer = null;
    }
    async initialize() {
      await this.restoreSession();
    }
    async restoreSession() {
      try {
        const storage = await chrome.storage.local.get(["privacypal_session"]);
        if (storage.privacypal_session?.jwtTokens) {
          this.jwtTokens = storage.privacypal_session.jwtTokens;
          this.userProfile = storage.privacypal_session.userProfile;
          if (this.jwtTokens.expires_at > Date.now()) {
            this.setupTokenRefresh();
            return true;
          }
          const refreshed = await this.refreshTokens();
          return !!refreshed;
        }
        return false;
      } catch (error) {
        console.error("Session restore failed:", error);
        return false;
      }
    }
    async authenticate(provider, credentials) {
      if (provider === "local") {
        return await this.authenticateLocal(credentials);
      } else if (provider === "google" || provider === "microsoft") {
        return await this.authenticateOAuth(provider);
      } else {
        throw new Error(`Unsupported authentication provider: ${provider}`);
      }
    }
    async authenticateLocal(credentials) {
      try {
        const config = await loadConfig();
        const response = await fetch(`${config.apiUrl}/api/user/login`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            email: credentials.email,
            password: credentials.password
          })
        });
        const data = await response.json();
        if (response.ok && (data.data?.token || data.token)) {
          const token = data.data?.token || data.token;
          const user = data.data?.user || data.user || { email: credentials.email };
          this.jwtTokens = {
            access_token: token,
            token_type: "Bearer",
            expires_in: 28800,
            // 8 hours
            expires_at: Date.now() + 28800 * 1e3
          };
          this.userProfile = user;
          await this.persistSession();
          this.setupTokenRefresh();
          this.updateAuthBadge(true);
          return { success: true, user: this.userProfile };
        }
        return { success: false, error: data.error || data.message || "Login failed" };
      } catch (error) {
        console.error("Local authentication error:", error);
        return { success: false, error: error.message || "Network error" };
      }
    }
    async authenticateOAuth(provider) {
      try {
        const state = crypto.randomUUID();
        const redirectUri = chrome.identity.getRedirectURL("oauth2callback");
        await chrome.storage.local.set({
          authState: state,
          authProvider: provider,
          authTimestamp: Date.now()
        });
        const config = await loadConfig();
        const authUrl = `${config.apiUrl}/api/auth/${provider}?state=${state}&redirect_uri=${encodeURIComponent(redirectUri)}`;
        const responseUrl = await chrome.identity.launchWebAuthFlow({
          url: authUrl,
          interactive: true
        });
        const url = new URL(responseUrl);
        const success = url.searchParams.get("success");
        const dataParam = url.searchParams.get("data");
        const returnedState = url.searchParams.get("state");
        if (success !== "true" || !dataParam) {
          const error = url.searchParams.get("error") || "Authentication failed";
          throw new Error(error);
        }
        if (returnedState !== state) {
          throw new Error("State mismatch - possible CSRF attack");
        }
        let base64Data = dataParam.replace(/-/g, "+").replace(/_/g, "/");
        const padding = (4 - base64Data.length % 4) % 4;
        base64Data = base64Data + "=".repeat(padding);
        const decoded = atob(base64Data);
        const authData = JSON.parse(decoded);
        const normalizedTokens = {
          access_token: authData.tokens.accessToken,
          token_type: authData.tokens.tokenType || "Bearer",
          expires_in: authData.tokens.expiresIn,
          expires_at: Date.now() + authData.tokens.expiresIn * 1e3,
          sessionId: crypto.randomUUID()
        };
        const sessionData = {
          jwtTokens: normalizedTokens,
          userProfile: authData.user,
          sessionId: normalizedTokens.sessionId,
          sessionStartTime: Date.now(),
          timestamp: Date.now()
        };
        await chrome.storage.local.set({ privacypal_session: sessionData });
        this.jwtTokens = normalizedTokens;
        this.userProfile = authData.user;
        this.setupTokenRefresh();
        this.updateAuthBadge(true);
        return { success: true, user: this.userProfile };
      } catch (error) {
        console.error(`${provider} authentication error:`, error);
        throw error;
      }
    }
    async getJWTToken() {
      if (this.jwtTokens && this.jwtTokens.expires_at > Date.now() + 6e4) {
        return this.jwtTokens;
      }
      const storage = await chrome.storage.local.get(["privacypal_session"]);
      if (storage.privacypal_session?.jwtTokens) {
        this.jwtTokens = storage.privacypal_session.jwtTokens;
        if (this.jwtTokens.expires_at > Date.now() + 6e4) {
          return this.jwtTokens;
        }
      }
      const refreshed = await this.refreshTokens();
      return refreshed || null;
    }
    async refreshTokens() {
      try {
        const storage = await chrome.storage.local.get(["privacypal_session"]);
        if (!storage.privacypal_session?.jwtTokens?.access_token) {
          return null;
        }
        const oldToken = storage.privacypal_session.jwtTokens.access_token;
        const config = await loadConfig();
        const response = await fetch(`${config.apiUrl}/api/user/refresh-token`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ token: oldToken })
        });
        if (!response.ok) {
          const errorData = await response.json().catch(() => ({}));
          console.warn("[AuthService] Token refresh failed:", errorData.error || response.statusText);
          return null;
        }
        const data = await response.json();
        const newToken = data.data?.token || data.token;
        if (!newToken) {
          console.warn("[AuthService] No token in refresh response");
          return null;
        }
        this.jwtTokens = {
          access_token: newToken,
          token_type: "Bearer",
          expires_in: 28800,
          // 8 hours
          expires_at: Date.now() + 28800 * 1e3
        };
        await this.persistSession();
        this.setupTokenRefresh();
        console.log("[AuthService] Token refreshed successfully");
        return this.jwtTokens;
      } catch (error) {
        console.warn("[AuthService] Token refresh error:", error.message);
        return null;
      }
    }
    setupTokenRefresh() {
      if (this.tokenRefreshTimer) {
        clearTimeout(this.tokenRefreshTimer);
      }
      if (this.jwtTokens?.expires_in) {
        const refreshTime = (this.jwtTokens.expires_in - 900) * 1e3;
        this.tokenRefreshTimer = setTimeout(() => {
          console.log("[AuthService] Auto-refreshing token before expiration");
          this.refreshTokens().catch(console.error);
        }, refreshTime);
      }
    }
    async persistSession() {
      const sessionData = {
        jwtTokens: this.jwtTokens,
        userProfile: this.userProfile,
        sessionId: this.sessionId || crypto.randomUUID(),
        sessionStartTime: this.sessionStartTime || Date.now(),
        timestamp: Date.now()
      };
      if (!this.sessionId) {
        this.sessionId = sessionData.sessionId;
      }
      if (!this.sessionStartTime) {
        this.sessionStartTime = sessionData.sessionStartTime;
      }
      await chrome.storage.local.set({
        privacypal_session: sessionData
      });
    }
    async getAuthStatus() {
      try {
        const tokens = await this.getJWTToken();
        if (tokens && tokens.expires_at > Date.now()) {
          return {
            authenticated: true,
            user: this.userProfile
          };
        }
      } catch (error) {
        console.error("Auth status check failed:", error);
      }
      return { authenticated: false };
    }
    async logout() {
      if (this.tokenRefreshTimer) {
        clearTimeout(this.tokenRefreshTimer);
        this.tokenRefreshTimer = null;
      }
      this.jwtTokens = null;
      this.userProfile = null;
      await chrome.storage.local.remove(["privacypal_session", "authState", "authProvider", "authTimestamp"]);
      this.updateAuthBadge(false);
      return { success: true };
    }
    async isAuthenticated() {
      try {
        const tokens = await this.getJWTToken();
        return !!tokens && tokens.expires_at > Date.now();
      } catch (error) {
        return false;
      }
    }
    async getToken() {
      const tokens = await this.getJWTToken();
      return tokens?.access_token || null;
    }
    async getCurrentUser() {
      return this.userProfile;
    }
    updateAuthBadge(isAuthenticated2) {
      try {
        if (chrome.action?.setBadgeText) {
          chrome.action.setBadgeText({ text: isAuthenticated2 ? "ON" : "OFF" });
          chrome.action.setBadgeBackgroundColor({
            color: isAuthenticated2 ? "#10b981" : "#ef4444"
          });
          chrome.action.setTitle({
            title: isAuthenticated2 ? "PrivacyPal - Authenticated" : "PrivacyPal - Not Authenticated"
          });
        }
      } catch (error) {
        console.error("Failed to update badge:", error);
      }
    }
  };
  var authService = new AuthService();
  var auth_service_default = authService;

  // src/popup/popup.js
  var elements = {
    // Auth view
    authView: document.getElementById("authView"),
    mainView: document.getElementById("mainView"),
    loginTab: document.getElementById("loginTab"),
    signupTab: document.getElementById("signupTab"),
    loginForm: document.getElementById("loginForm"),
    signupForm: document.getElementById("signupForm"),
    loginEmail: document.getElementById("loginEmail"),
    loginPassword: document.getElementById("loginPassword"),
    loginBtn: document.getElementById("loginBtn"),
    signupFirstName: document.getElementById("signupFirstName"),
    signupLastName: document.getElementById("signupLastName"),
    signupEmail: document.getElementById("signupEmail"),
    signupPassword: document.getElementById("signupPassword"),
    signupBtn: document.getElementById("signupBtn"),
    googleLoginBtn: document.getElementById("googleLoginBtn"),
    microsoftLoginBtn: document.getElementById("microsoftLoginBtn"),
    googleSignupBtn: document.getElementById("googleSignupBtn"),
    microsoftSignupBtn: document.getElementById("microsoftSignupBtn"),
    authError: document.getElementById("authError"),
    logoutBtn: document.getElementById("logoutBtn"),
    // Main view
    enabledToggle: document.getElementById("enabledToggle"),
    statusIndicator: document.getElementById("statusIndicator"),
    statusDot: document.querySelector(".status-dot"),
    statusText: document.querySelector(".status-text"),
    themeToggleBtn: document.getElementById("themeToggleBtn"),
    settingsBtn: document.getElementById("settingsBtn"),
    shareBtn: document.getElementById("shareBtn"),
    app: document.querySelector(".app"),
    settingsOverlay: document.getElementById("settingsOverlay"),
    settingsPanel: document.getElementById("settingsPanel"),
    closeSettingsBtn: document.getElementById("closeSettingsBtn"),
    shareOverlay: document.getElementById("shareOverlay"),
    sharePanel: document.getElementById("sharePanel"),
    closeShareBtn: document.getElementById("closeShareBtn"),
    generateInviteBtn: document.getElementById("generateInviteBtn"),
    inviteLinkInput: document.getElementById("inviteLinkInput"),
    copyInviteBtn: document.getElementById("copyInviteBtn"),
    copyIcon: document.getElementById("copyIcon"),
    checkIcon: document.getElementById("checkIcon"),
    shareStatus: document.getElementById("shareStatus"),
    apiUrl: document.getElementById("apiUrl"),
    userPortalUrl: document.getElementById("userPortalUrl"),
    userEmail: document.getElementById("userEmail"),
    showNotifications: document.getElementById("showNotifications"),
    debugMode: document.getElementById("debugMode"),
    testConnectionBtn: document.getElementById("testConnectionBtn"),
    saveSettingsBtn: document.getElementById("saveSettingsBtn"),
    connectionStatus: document.getElementById("connectionStatus"),
    versionNumber: document.getElementById("versionNumber")
  };
  var currentConfig = {};
  var settingsPanelVisible = false;
  var sharePanelVisible = false;
  var isDarkMode = true;
  var isAuthenticated = false;
  async function init() {
    await auth_service_default.initialize();
    const authStatus = await auth_service_default.getAuthStatus();
    isAuthenticated = authStatus.authenticated;
    loadVersion();
    await loadTheme();
    if (isAuthenticated) {
      showMainView();
      await displayUserEmail();
      await loadConfig2();
      setupEventListeners();
      updateUI();
    } else {
      showAuthView();
      setupAuthEventListeners();
    }
  }
  function loadVersion() {
    if (elements.versionNumber) {
      try {
        const manifest = chrome.runtime.getManifest();
        elements.versionNumber.textContent = `v${manifest.version}`;
      } catch (error) {
      }
    }
  }
  async function loadTheme() {
    return new Promise((resolve) => {
      chrome.storage.local.get(["darkMode"], (result) => {
        isDarkMode = result.darkMode !== false;
        updateTheme();
        resolve();
      });
    });
  }
  function updateTheme() {
    if (elements.app) {
      if (isDarkMode) {
        elements.app.classList.add("pp-dark-mode");
        elements.app.classList.remove("pp-light-mode");
      } else {
        elements.app.classList.add("pp-light-mode");
        elements.app.classList.remove("pp-dark-mode");
      }
    }
  }
  async function loadConfig2() {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ action: "getConfig" }, async (response) => {
        if (response?.config) {
          currentConfig = response.config;
          let apiUrl = currentConfig.apiUrl || DEFAULT_ENDPOINTS.apiUrl;
          let userPortalUrl = currentConfig.userPortalUrl || DEFAULT_ENDPOINTS.userPortalUrl;
          if (apiUrl.includes("localhost:42026") || apiUrl.includes("127.0.0.1:42026")) {
            apiUrl = DEFAULT_ENDPOINTS.apiUrl;
            await chrome.runtime.sendMessage({
              action: "updateConfig",
              config: { ...currentConfig, apiUrl }
            });
          }
          if (userPortalUrl.includes("localhost:5174") || userPortalUrl.includes("127.0.0.1:5174")) {
            userPortalUrl = DEFAULT_ENDPOINTS.userPortalUrl;
            await chrome.runtime.sendMessage({
              action: "updateConfig",
              config: { ...currentConfig, userPortalUrl }
            });
          }
          elements.enabledToggle.checked = currentConfig.enabled !== false;
          elements.apiUrl.value = apiUrl;
          if (elements.userPortalUrl) {
            elements.userPortalUrl.value = userPortalUrl;
          }
          elements.showNotifications.checked = currentConfig.showNotifications !== false;
          elements.debugMode.checked = currentConfig.debug === true;
        }
        resolve();
      });
    });
  }
  async function displayUserEmail() {
    try {
      const session = await chrome.storage.local.get(["privacypal_session"]);
      if (session.privacypal_session?.userProfile?.email && elements.userEmail) {
        elements.userEmail.textContent = session.privacypal_session.userProfile.email;
        elements.userEmail.title = session.privacypal_session.userProfile.email;
      } else if (elements.userEmail) {
        elements.userEmail.textContent = "";
        elements.userEmail.title = "";
      }
    } catch (error) {
    }
  }
  function showAuthView() {
    if (elements.authView)
      elements.authView.style.display = "block";
    if (elements.mainView)
      elements.mainView.style.display = "none";
  }
  function showMainView() {
    if (elements.authView)
      elements.authView.style.display = "none";
    if (elements.mainView)
      elements.mainView.style.display = "block";
  }
  function setupAuthEventListeners() {
    if (elements.loginTab) {
      elements.loginTab.addEventListener("click", () => {
        elements.loginTab.classList.add("active");
        elements.signupTab.classList.remove("active");
        elements.loginForm.style.display = "block";
        elements.signupForm.style.display = "none";
        hideAuthError();
      });
    }
    if (elements.signupTab) {
      elements.signupTab.addEventListener("click", () => {
        elements.signupTab.classList.add("active");
        elements.loginTab.classList.remove("active");
        elements.signupForm.style.display = "block";
        elements.loginForm.style.display = "none";
        hideAuthError();
      });
    }
    if (elements.loginBtn) {
      elements.loginBtn.addEventListener("click", async () => {
        await handleLogin();
      });
    }
    if (elements.signupBtn) {
      elements.signupBtn.addEventListener("click", async () => {
        await handleSignup();
      });
    }
    if (elements.googleLoginBtn) {
      elements.googleLoginBtn.addEventListener("click", () => handleOAuth("google"));
    }
    if (elements.microsoftLoginBtn) {
      elements.microsoftLoginBtn.addEventListener("click", () => handleOAuth("microsoft"));
    }
    if (elements.googleSignupBtn) {
      elements.googleSignupBtn.addEventListener("click", () => handleOAuth("google"));
    }
    if (elements.microsoftSignupBtn) {
      elements.microsoftSignupBtn.addEventListener("click", () => handleOAuth("microsoft"));
    }
    if (elements.loginPassword) {
      elements.loginPassword.addEventListener("keypress", (e) => {
        if (e.key === "Enter")
          handleLogin();
      });
    }
    if (elements.signupPassword) {
      elements.signupPassword.addEventListener("keypress", (e) => {
        if (e.key === "Enter")
          handleSignup();
      });
    }
  }
  async function handleLogin() {
    const email = elements.loginEmail?.value.trim();
    const password = elements.loginPassword?.value;
    if (!email || !password) {
      showAuthError("Please enter email and password");
      return;
    }
    elements.loginBtn.disabled = true;
    elements.loginBtn.textContent = "Signing in...";
    hideAuthError();
    try {
      const result = await auth_service_default.authenticate("local", { email, password });
      if (result.success) {
        isAuthenticated = true;
        showMainView();
        await loadConfig2();
        setupEventListeners();
        updateUI();
      } else {
        showAuthError(result.error || "Login failed");
      }
    } catch (error) {
      showAuthError(error.message || "An error occurred");
    } finally {
      elements.loginBtn.disabled = false;
      elements.loginBtn.textContent = "Sign In";
    }
  }
  async function handleSignup() {
    const firstName = elements.signupFirstName?.value.trim();
    const lastName = elements.signupLastName?.value.trim();
    const email = elements.signupEmail?.value.trim();
    const password = elements.signupPassword?.value;
    if (!firstName || !lastName || !email || !password) {
      showAuthError("Please fill in all fields");
      return;
    }
    elements.signupBtn.disabled = true;
    elements.signupBtn.textContent = "Creating account...";
    hideAuthError();
    try {
      const config = await loadConfig();
      const registerResponse = await fetch(`${config.apiUrl}/api/user/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ firstName, lastName, email, password })
      });
      const registerData = await registerResponse.json();
      if (registerResponse.ok && registerData.token) {
        const loginResult = await auth_service_default.authenticate("local", { email, password });
        if (loginResult.success) {
          isAuthenticated = true;
          showMainView();
          await displayUserEmail();
          await loadConfig2();
          setupEventListeners();
          updateUI();
        } else {
          showAuthError("Account created but login failed. Please try signing in.");
        }
      } else {
        showAuthError(registerData.error || "Registration failed");
      }
    } catch (error) {
      showAuthError(error.message || "An error occurred");
    } finally {
      elements.signupBtn.disabled = false;
      elements.signupBtn.textContent = "Create Account";
    }
  }
  async function handleOAuth(provider) {
    try {
      const btn = provider === "google" ? elements.googleLoginBtn || elements.googleSignupBtn : elements.microsoftLoginBtn || elements.microsoftSignupBtn;
      if (btn) {
        btn.disabled = true;
        btn.textContent = "Connecting...";
      }
      hideAuthError();
      const result = await auth_service_default.authenticate(provider);
      if (result.success) {
        isAuthenticated = true;
        showMainView();
        await displayUserEmail();
        await loadConfig2();
        setupEventListeners();
        updateUI();
      } else {
        showAuthError(result.error || "Authentication failed");
      }
    } catch (error) {
      showAuthError(error.message || "An error occurred");
    } finally {
      const btn = provider === "google" ? elements.googleLoginBtn || elements.googleSignupBtn : elements.microsoftLoginBtn || elements.microsoftSignupBtn;
      if (btn) {
        btn.disabled = false;
        const isLogin = elements.loginForm?.style.display !== "none";
        btn.textContent = provider === "google" ? isLogin ? "Continue with Google" : "Sign up with Google" : isLogin ? "Continue with Microsoft" : "Sign up with Microsoft";
      }
    }
  }
  function showAuthError(message) {
    if (elements.authError) {
      elements.authError.textContent = message;
      elements.authError.style.display = "block";
    }
  }
  function hideAuthError() {
    if (elements.authError) {
      elements.authError.style.display = "none";
    }
  }
  function updateUI() {
    const isEnabled = elements.enabledToggle?.checked;
    if (isEnabled && elements.statusDot) {
      elements.statusDot.classList.remove("inactive");
      if (elements.statusText)
        elements.statusText.textContent = "Protection Active";
    } else if (elements.statusDot) {
      elements.statusDot.classList.add("inactive");
      if (elements.statusText)
        elements.statusText.textContent = "Protection Disabled";
    }
  }
  function setupEventListeners() {
    if (elements.logoutBtn) {
      elements.logoutBtn.addEventListener("click", async () => {
        await auth_service_default.logout();
        isAuthenticated = false;
        if (elements.userEmail) {
          elements.userEmail.textContent = "";
          elements.userEmail.title = "";
        }
        showAuthView();
        setupAuthEventListeners();
      });
    }
    if (elements.enabledToggle) {
      elements.enabledToggle.addEventListener("change", async () => {
        const enabled = elements.enabledToggle.checked;
        await saveConfig2({ enabled });
        updateUI();
      });
    }
    elements.themeToggleBtn.addEventListener("click", () => {
      isDarkMode = !isDarkMode;
      updateTheme();
      chrome.storage.local.set({ darkMode: isDarkMode });
    });
    elements.settingsBtn.addEventListener("click", () => {
      openSettingsPanel();
    });
    elements.closeSettingsBtn.addEventListener("click", () => {
      closeSettingsPanel();
    });
    elements.settingsOverlay.addEventListener("click", (e) => {
      if (e.target === elements.settingsOverlay) {
        closeSettingsPanel();
      }
    });
    elements.shareBtn.addEventListener("click", () => {
      openSharePanel();
    });
    elements.closeShareBtn.addEventListener("click", () => {
      closeSharePanel();
    });
    elements.shareOverlay.addEventListener("click", (e) => {
      if (e.target === elements.shareOverlay) {
        closeSharePanel();
      }
    });
    elements.generateInviteBtn.addEventListener("click", async () => {
      await generateInviteLink();
    });
    elements.copyInviteBtn.addEventListener("click", () => {
      copyInviteLink();
    });
    elements.testConnectionBtn.addEventListener("click", async () => {
      await testConnection();
    });
    elements.saveSettingsBtn.addEventListener("click", async () => {
      await saveSettings();
    });
  }
  async function testConnection() {
    const apiUrl = elements.apiUrl.value.trim();
    if (!apiUrl) {
      showConnectionStatus("Please enter API URL", "error");
      return;
    }
    const session = await chrome.storage.local.get(["privacypal_session"]);
    let apiKey = null;
    if (session.privacypal_session?.jwtTokens?.access_token) {
      const tokens = session.privacypal_session.jwtTokens;
      if (tokens.expires_at && tokens.expires_at > Date.now()) {
        apiKey = tokens.access_token;
      } else {
        showConnectionStatus("Token expired - please sign in again", "error");
        return;
      }
    } else {
      showConnectionStatus("Not authenticated - please sign in", "error");
      return;
    }
    elements.testConnectionBtn.textContent = "Testing...";
    elements.testConnectionBtn.disabled = true;
    try {
      const response = await new Promise((resolve) => {
        chrome.runtime.sendMessage(
          {
            action: "testConnection",
            apiUrl,
            apiKey
          },
          resolve
        );
      });
      if (response.success) {
        showConnectionStatus("\u2713 Connected to PrivacyPal API", "success");
      } else {
        showConnectionStatus(`\u2717 ${response.error}`, "error");
      }
    } catch (error) {
      showConnectionStatus(`\u2717 Connection failed: ${error.message}`, "error");
    } finally {
      elements.testConnectionBtn.textContent = "Test Connection";
      elements.testConnectionBtn.disabled = false;
    }
  }
  async function saveSettings() {
    const config = {
      apiUrl: elements.apiUrl.value.trim(),
      userPortalUrl: elements.userPortalUrl?.value.trim() || DEFAULT_ENDPOINTS.userPortalUrl,
      // Don't save apiKey - it comes from authenticated session
      showNotifications: elements.showNotifications.checked,
      debug: elements.debugMode.checked
    };
    await saveConfig({
      apiUrl: config.apiUrl,
      userPortalUrl: config.userPortalUrl
    });
    await new Promise((resolve) => {
      chrome.runtime.sendMessage({
        action: "updateConfig",
        config
      }, resolve);
    });
    showConnectionStatus("\u2713 Settings saved successfully", "success");
    setTimeout(() => {
      elements.connectionStatus.style.display = "none";
      closeSettingsPanel();
    }, 1500);
  }
  function openSettingsPanel() {
    settingsPanelVisible = true;
    elements.settingsOverlay.style.display = "block";
    setTimeout(() => {
      elements.settingsOverlay.classList.add("visible");
    }, 10);
  }
  function closeSettingsPanel() {
    settingsPanelVisible = false;
    elements.settingsOverlay.classList.remove("visible");
    setTimeout(() => {
      elements.settingsOverlay.style.display = "none";
    }, 300);
  }
  async function saveConfig2(config) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage(
        { action: "updateConfig", config },
        (response) => {
          if (response?.success) {
            currentConfig = { ...currentConfig, ...config };
          }
          resolve();
        }
      );
    });
  }
  function showConnectionStatus(message, type) {
    elements.connectionStatus.textContent = message;
    elements.connectionStatus.className = `connection-status ${type}`;
    elements.connectionStatus.style.display = "block";
  }
  function openSharePanel() {
    sharePanelVisible = true;
    elements.shareOverlay.style.display = "block";
    setTimeout(() => {
      elements.shareOverlay.classList.add("visible");
    }, 10);
  }
  function closeSharePanel() {
    sharePanelVisible = false;
    elements.shareOverlay.classList.remove("visible");
    setTimeout(() => {
      elements.shareOverlay.style.display = "none";
      if (elements.inviteLinkInput) {
        elements.inviteLinkInput.value = "";
      }
      if (elements.copyIcon && elements.checkIcon) {
        elements.copyIcon.style.display = "block";
        elements.checkIcon.style.display = "none";
      }
      if (elements.shareStatus) {
        elements.shareStatus.style.display = "none";
      }
    }, 300);
  }
  async function generateInviteLink() {
    const session = await chrome.storage.local.get(["privacypal_session"]);
    let apiKey = null;
    if (session.privacypal_session?.jwtTokens?.access_token) {
      const tokens = session.privacypal_session.jwtTokens;
      if (tokens.expires_at && tokens.expires_at > Date.now()) {
        apiKey = tokens.access_token;
      } else {
        showShareStatus("Token expired - please sign in again", "error");
        return;
      }
    } else {
      showShareStatus("Not authenticated - please sign in", "error");
      return;
    }
    const config = await loadConfig();
    const apiUrl = config.apiUrl || DEFAULT_ENDPOINTS.apiUrl;
    elements.generateInviteBtn.textContent = "Generating...";
    elements.generateInviteBtn.disabled = true;
    hideShareStatus();
    try {
      const response = await fetch(`${apiUrl}/api/company/invite`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-access-token": apiKey
        }
      });
      const data = await response.json();
      if (response.ok && (data.inviteUrl || data.hash)) {
        const portalUrl = config.userPortalUrl || DEFAULT_ENDPOINTS.userPortalUrl;
        let inviteHash = data.hash;
        if (!inviteHash && data.inviteUrl) {
          const match = data.inviteUrl.match(/\/invite\/([^\/\?]+)/);
          if (match) {
            inviteHash = match[1];
          }
        }
        if (inviteHash) {
          const fullInviteUrl = `${portalUrl}/invite/${inviteHash}`;
          elements.inviteLinkInput.value = fullInviteUrl;
          showShareStatus("\u2713 Invite link generated successfully", "success");
        } else {
          showShareStatus("\u2717 Invalid response format from server", "error");
        }
      } else {
        showShareStatus(`\u2717 ${data.error || "Failed to generate invite link"}`, "error");
      }
    } catch (error) {
      showShareStatus(`\u2717 Failed to generate invite link: ${error.message}`, "error");
    } finally {
      elements.generateInviteBtn.textContent = "Generate Invite Link";
      elements.generateInviteBtn.disabled = false;
    }
  }
  async function copyInviteLink() {
    const inviteLink = elements.inviteLinkInput.value.trim();
    if (!inviteLink) {
      showShareStatus("Please generate an invite link first", "error");
      return;
    }
    try {
      await navigator.clipboard.writeText(inviteLink);
      elements.copyIcon.style.display = "none";
      elements.checkIcon.style.display = "block";
      showShareStatus("\u2713 Link copied to clipboard", "success");
      setTimeout(() => {
        elements.copyIcon.style.display = "block";
        elements.checkIcon.style.display = "none";
      }, 2e3);
    } catch (error) {
      showShareStatus(`\u2717 Failed to copy: ${error.message}`, "error");
    }
  }
  function showShareStatus(message, type) {
    if (elements.shareStatus) {
      elements.shareStatus.textContent = message;
      elements.shareStatus.className = `connection-status ${type}`;
      elements.shareStatus.style.display = "block";
    }
  }
  function hideShareStatus() {
    if (elements.shareStatus) {
      elements.shareStatus.style.display = "none";
    }
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
