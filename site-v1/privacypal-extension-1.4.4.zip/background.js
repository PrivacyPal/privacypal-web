var self = (() => {
  // src/config/config.js
  var BUILD_MODE = "production";
  var ENDPOINTS = {
    development: {
      apiUrl: "http://localhost:42026",
      userPortalUrl: "http://localhost:5174"
    },
    production: {
      apiUrl: "https://api.privacypal.ai",
      userPortalUrl: "https://portal.privacypal.ai"
    }
  };
  var DEFAULT_ENDPOINTS = BUILD_MODE === "development" ? ENDPOINTS.development : ENDPOINTS.production;
  var IS_DEV_BUILD = BUILD_MODE === "development";
  async function loadConfig() {
    if (IS_DEV_BUILD) {
      return DEFAULT_ENDPOINTS;
    }
    try {
      const stored = await chrome.storage.local.get(["apiUrl", "userPortalUrl"]);
      return {
        apiUrl: stored.apiUrl || DEFAULT_ENDPOINTS.apiUrl,
        userPortalUrl: stored.userPortalUrl || DEFAULT_ENDPOINTS.userPortalUrl
      };
    } catch (error) {
      return DEFAULT_ENDPOINTS;
    }
  }

  // src/background/service-worker.js
  var DEFAULT_CONFIG = {
    enabled: true,
    apiUrl: DEFAULT_ENDPOINTS.apiUrl,
    userPortalUrl: DEFAULT_ENDPOINTS.userPortalUrl,
    // apiKey is no longer stored here - it comes from authenticated user's JWT token
    debug: true,
    showNotifications: true
  };
  var stats = {
    requestsIntercepted: 0,
    responsesModified: 0,
    dataProtected: 0,
    lastInterception: null,
    sessionStart: Date.now(),
    continuationIds: []
    // Track all continuationIds for accurate stats
  };
  async function getCurrentJWTToken() {
    try {
      const result = await chrome.storage.local.get(["privacypal_session"]);
      const session = result.privacypal_session;
      if (session?.jwtTokens?.access_token) {
        const token = session.jwtTokens.access_token;
        return token;
      }
      return null;
    } catch (error) {
      return null;
    }
  }
  chrome.runtime.onInstalled.addListener(async (details) => {
    const config = await loadConfig();
    const initialConfig = {
      ...DEFAULT_CONFIG,
      apiUrl: config.apiUrl,
      userPortalUrl: config.userPortalUrl
    };
    const existing = await chrome.storage.local.get(["apiUrl", "userPortalUrl", "enabled", "debug", "showNotifications"]);
    const configToSave = {
      ...DEFAULT_CONFIG,
      apiUrl: existing.apiUrl || config.apiUrl,
      userPortalUrl: existing.userPortalUrl || config.userPortalUrl,
      enabled: existing.enabled !== void 0 ? existing.enabled : DEFAULT_CONFIG.enabled,
      debug: existing.debug !== void 0 ? existing.debug : DEFAULT_CONFIG.debug,
      showNotifications: existing.showNotifications !== void 0 ? existing.showNotifications : DEFAULT_CONFIG.showNotifications
    };
    await chrome.storage.local.set(configToSave);
    await chrome.storage.local.set({ stats });
    if (details.reason === "install") {
      const finalConfig = await loadConfig();
      chrome.tabs.create({
        url: finalConfig.userPortalUrl
      });
    }
  });
  chrome.runtime.onConnect.addListener((port) => {
    port.onDisconnect.addListener(() => {
    });
  });
  try {
    if (chrome && chrome.alarms) {
      chrome.alarms.create("privacypal-keepalive", {
        delayInMinutes: 0.25,
        // 15 seconds
        periodInMinutes: 0.25
        // Repeat every 15 seconds
      }).catch((err) => {
      });
      chrome.alarms.onAlarm.addListener((alarm) => {
        if (alarm && alarm.name === "privacypal-keepalive") {
          try {
            chrome.storage.local.get(["keepAlive"], () => {
            });
          } catch (err) {
          }
        }
      });
    }
  } catch (error) {
  }
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    chrome.storage.local.get(["keepAlive"], () => {
    });
    if (request.type === "OAUTH_COMPLETE") {
      sendResponse({ success: true, received: true });
      return true;
    }
    switch (request.action) {
      case "ping":
        sendResponse({ success: true, pong: true });
        return false;
      case "interceptorReady":
        handleInterceptorReady(request, sender);
        sendResponse({ success: true });
        break;
      case "requestIntercepted":
        handleRequestIntercepted(request, sender);
        sendResponse({ success: true });
        break;
      case "encodeData":
        (async () => {
          try {
            await chrome.storage.local.get(["keepAlive"]);
          } catch (e) {
          }
          let responseSent = false;
          const safeSendResponse = (response) => {
            if (!responseSent) {
              try {
                sendResponse(response);
                responseSent = true;
              } catch (err) {
                responseSent = true;
              }
            }
          };
          try {
            let apiKey = request.apiKey;
            if (!apiKey) {
              apiKey = await getCurrentJWTToken();
            }
            let tokenInfo = null;
            if (apiKey) {
              try {
                const parts = apiKey.split(".");
                if (parts.length === 3) {
                  const payload = JSON.parse(atob(parts[1].replace(/-/g, "+").replace(/_/g, "/")));
                  tokenInfo = {
                    isValidFormat: true,
                    payload: {
                      user_id: payload.user_id,
                      email: payload.email,
                      exp: payload.exp,
                      iat: payload.iat,
                      expiresAt: payload.exp ? new Date(payload.exp * 1e3).toISOString() : null,
                      isExpired: payload.exp ? payload.exp < Date.now() / 1e3 : null
                    }
                  };
                } else {
                  tokenInfo = { isValidFormat: false, reason: "Not a JWT (does not have 3 parts)" };
                }
              } catch (e) {
                tokenInfo = { isValidFormat: false, reason: `Decode error: ${e.message}` };
              }
            }
            if (!apiKey) {
              safeSendResponse({
                success: false,
                error: "Not authenticated. Please sign in to use PrivacyPal."
              });
              return;
            }
            const encodePromise = proxyEncodeRequest(
              request.data,
              request.apiUrl || DEFAULT_ENDPOINTS.apiUrl,
              apiKey,
              request.platform,
              request.model,
              request.files || [],
              request.sessionContinuationId || null
              // Pass session continuationID
            );
            const timeoutPromise = new Promise((_, reject) => {
              setTimeout(() => {
                reject(new Error("Encode request timed out after 60 seconds"));
              }, 6e4);
            });
            const result = await Promise.race([encodePromise, timeoutPromise]);
            safeSendResponse(result);
          } catch (error) {
            const errorMessage = error.message || String(error);
            safeSendResponse({
              success: false,
              error: errorMessage,
              timeout: errorMessage.includes("timeout")
            });
          }
        })();
        return true;
      case "decodeData":
        (async () => {
          let responseSent = false;
          const safeSendResponse = (response) => {
            if (!responseSent) {
              try {
                sendResponse(response);
                responseSent = true;
              } catch (err) {
                responseSent = true;
              }
            }
          };
          try {
            let apiKey = request.apiKey || await getCurrentJWTToken();
            if (!apiKey) {
              safeSendResponse({
                success: false,
                error: "Not authenticated. Please sign in to use PrivacyPal."
              });
              return;
            }
            const result = await proxyDecodeRequest(request.data, request.continuationId, request.hashes, request.apiUrl || DEFAULT_ENDPOINTS.apiUrl, apiKey);
            safeSendResponse(result);
          } catch (error) {
            safeSendResponse({ success: false, error: error.message || String(error) });
          }
        })();
        return true;
      case "encodeFile":
        (async () => {
          try {
            await chrome.storage.local.get(["keepAlive"]);
          } catch (e) {
          }
          let responseSent = false;
          const safeSendResponse = (response) => {
            if (!responseSent) {
              try {
                sendResponse(response);
                responseSent = true;
              } catch (err) {
                responseSent = true;
              }
            }
          };
          try {
            let apiKey = request.apiKey || await getCurrentJWTToken();
            if (!apiKey) {
              safeSendResponse({
                success: false,
                error: "Not authenticated. Please sign in to use PrivacyPal."
              });
              return;
            }
            const encodePromise = proxyEncodeFileRequest(
              request.fileData,
              request.fileName,
              request.apiUrl || DEFAULT_ENDPOINTS.apiUrl,
              apiKey,
              request.platform,
              request.fileSize,
              request.fileType
            );
            const timeoutPromise = new Promise((_, reject) => {
              setTimeout(() => {
                reject(new Error("File encode request timed out after 60 seconds"));
              }, 6e4);
            });
            const result = await Promise.race([encodePromise, timeoutPromise]);
            safeSendResponse(result);
          } catch (error) {
            const errorMessage = error.message || String(error);
            safeSendResponse({
              success: false,
              error: errorMessage,
              timeout: errorMessage.includes("timeout")
            });
          }
        })();
        return true;
      case "updateAuditTokens":
        (async () => {
          try {
            let apiKey = request.apiKey;
            if (!apiKey) {
              apiKey = await getCurrentJWTToken();
            }
            if (!apiKey) {
              sendResponse({ success: false, error: "No authentication token available" });
              return;
            }
            const result = await proxyUpdateAuditTokens(
              request.continuationId,
              request.tokensIn || 0,
              request.tokensOut || 0,
              request.model || null,
              request.apiUrl || DEFAULT_ENDPOINTS.apiUrl,
              apiKey
            );
            sendResponse(result);
          } catch (error) {
            sendResponse({ success: false, error: error.message });
          }
        })();
        return true;
      case "getConfig":
        chrome.storage.local.get(["apiUrl", "userPortalUrl", "enabled", "debug", "showNotifications"], (result) => {
          try {
            let apiUrl = result.apiUrl || DEFAULT_CONFIG.apiUrl;
            let userPortalUrl = result.userPortalUrl || DEFAULT_CONFIG.userPortalUrl;
            if (apiUrl.includes("localhost:42026") || apiUrl.includes("127.0.0.1:42026")) {
              apiUrl = DEFAULT_CONFIG.apiUrl;
              chrome.storage.local.set({ apiUrl });
            }
            if (userPortalUrl.includes("localhost:5174") || userPortalUrl.includes("127.0.0.1:5174")) {
              userPortalUrl = DEFAULT_CONFIG.userPortalUrl;
              chrome.storage.local.set({ userPortalUrl });
            }
            const config = {
              ...DEFAULT_CONFIG,
              ...result,
              apiUrl,
              userPortalUrl
            };
            sendResponse({ config });
          } catch (err) {
            sendResponse({ config: DEFAULT_CONFIG });
          }
        });
        return true;
      case "getSession":
        chrome.storage.local.get(["privacypal_session"], (result) => {
          try {
            sendResponse({ privacypal_session: result.privacypal_session || null });
          } catch (err) {
          }
        });
        return true;
      case "updateConfig":
        chrome.storage.local.set(request.config, () => {
          sendResponse({ success: true });
          broadcastConfigChange(request.config);
        });
        return true;
      case "getStats":
        chrome.storage.local.get(["stats"], (result) => {
          const currentStats = result.stats || stats;
          sendResponse({ stats: currentStats });
        });
        return true;
      case "resetStats":
        stats = {
          requestsIntercepted: 0,
          responsesModified: 0,
          dataProtected: 0,
          lastInterception: null,
          sessionStart: Date.now(),
          continuationIds: []
        };
        chrome.storage.local.set({ stats }, () => {
          sendResponse({ success: true, stats });
        });
        return true;
      case "recordContinuationId":
        recordContinuationId(request.continuationId, request.dataProtected);
        sendResponse({ success: true });
        return true;
      case "testConnection":
        (async () => {
          try {
            const apiKey = await getCurrentJWTToken();
            if (!apiKey) {
              sendResponse({ success: false, error: "Not authenticated. Please sign in to test connection." });
              return;
            }
            const result = await testConnection(request.apiUrl || DEFAULT_ENDPOINTS.apiUrl, apiKey);
            sendResponse(result);
          } catch (error) {
            sendResponse({ success: false, error: error.message });
          }
        })();
        return true;
      default:
        sendResponse({ error: "Unknown action" });
    }
  });
  function handleInterceptorReady(data, sender) {
    if (sender.tab?.id) {
      chrome.action.setBadgeText({
        text: "\u2713",
        tabId: sender.tab.id
      });
      chrome.action.setBadgeBackgroundColor({
        color: "#4169e1",
        tabId: sender.tab.id
      });
    }
  }
  function handleRequestIntercepted(data, sender) {
    if (data.continuationId) {
      const dataProtected = data.stats?.dataProtected || 0;
      recordContinuationId(data.continuationId, dataProtected);
    } else {
      stats.requestsIntercepted = data.stats?.requestsIntercepted || 0;
      stats.responsesModified = data.stats?.responsesModified || 0;
      stats.dataProtected = (stats.dataProtected || 0) + (data.stats?.dataProtected || 0);
      stats.lastInterception = (/* @__PURE__ */ new Date()).toISOString();
      chrome.storage.local.set({ stats });
    }
    chrome.storage.local.get(["showNotifications"], (result) => {
      if (result.showNotifications) {
        showInterceptionNotification(data.platform, sender.tab?.id);
      }
    });
  }
  function recordContinuationId(continuationId, dataProtected = 0) {
    if (!continuationId)
      return;
    chrome.storage.local.get(["stats"], (result) => {
      const currentStats = result.stats || { ...stats };
      if (!currentStats.continuationIds) {
        currentStats.continuationIds = [];
      }
      if (!currentStats.continuationIds.includes(continuationId)) {
        currentStats.continuationIds.push(continuationId);
        currentStats.requestsIntercepted = currentStats.continuationIds.length;
        currentStats.lastInterception = (/* @__PURE__ */ new Date()).toISOString();
      }
      currentStats.dataProtected = (currentStats.dataProtected || 0) + (dataProtected || 0);
      stats = currentStats;
      chrome.storage.local.set({ stats });
    });
  }
  function showInterceptionNotification(platform, tabId) {
    if (!tabId)
      return;
    chrome.action.setBadgeText({
      text: "\u{1F6E1}\uFE0F",
      tabId
    });
    chrome.action.setBadgeBackgroundColor({
      color: "#10a37f",
      tabId
    });
    setTimeout(() => {
      chrome.action.setBadgeText({
        text: "\u2713",
        tabId
      });
      chrome.action.setBadgeBackgroundColor({
        color: "#4169e1",
        tabId
      });
    }, 2e3);
  }
  function broadcastConfigChange(config) {
    chrome.tabs.query({}, (tabs) => {
      tabs.forEach((tab) => {
        chrome.tabs.sendMessage(tab.id, {
          action: "configUpdated",
          config
        }).catch(() => {
        });
      });
    });
  }
  async function testConnection(apiUrl, apiKey) {
    try {
      const response = await fetch(`${apiUrl}/health`, {
        method: "GET",
        headers: {
          "x-access-token": apiKey,
          "Content-Type": "application/json"
        },
        // Edge may require explicit fetch options to recognize service worker context
        mode: "cors",
        credentials: "omit",
        cache: "no-cache"
      });
      if (response.ok) {
        return { success: true, message: "Connected to PrivacyPal API" };
      } else {
        return {
          success: false,
          error: `API returned status ${response.status}`
        };
      }
    } catch (error) {
      return {
        success: false,
        error: `Connection failed: ${error.message}`
      };
    }
  }
  chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === "complete" && tab.url) {
      const isChatGPT = tab.url.includes("chatgpt.com");
      const isClaude = tab.url.includes("claude.ai");
      if (isChatGPT || isClaude) {
        chrome.action.setBadgeText({
          text: "\u2713",
          tabId
        });
        chrome.action.setBadgeBackgroundColor({
          color: "#4169e1",
          tabId
        });
      }
    }
  });
  chrome.runtime.onStartup.addListener(async () => {
    const result = await chrome.storage.local.get(["stats"]);
    if (result.stats) {
      stats = result.stats;
    }
  });
  chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.create({
      id: "privacypal-toggle",
      title: "Toggle PrivacyPal Protection",
      contexts: ["page"]
    });
    chrome.contextMenus.create({
      id: "privacypal-stats",
      title: "View Protection Statistics",
      contexts: ["page"]
    });
  });
  chrome.contextMenus.onClicked.addListener((info, tab) => {
    switch (info.menuItemId) {
      case "privacypal-toggle":
        toggleProtection();
        break;
      case "privacypal-stats":
        showStatsNotification();
        break;
    }
  });
  async function toggleProtection() {
    const result = await chrome.storage.local.get(["enabled"]);
    const newState = !result.enabled;
    await chrome.storage.local.set({ enabled: newState });
    broadcastConfigChange({ enabled: newState });
  }
  async function showStatsNotification() {
    const result = await chrome.storage.local.get(["stats"]);
    const currentStats = result.stats || stats;
  }
  async function proxyEncodeRequest(data, apiUrl, apiKey, platform = null, model = null, files = [], sessionContinuationId = null) {
    try {
      if (!data) {
        throw new Error("No data provided for encode request");
      }
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 6e4);
      try {
        const headers = {
          "Content-Type": "application/json"
        };
        if (apiKey) {
          headers["x-access-token"] = apiKey;
          let tokenPayload = null;
          try {
            const parts = apiKey.split(".");
            if (parts.length === 3) {
              tokenPayload = JSON.parse(atob(parts[1].replace(/-/g, "+").replace(/_/g, "/")));
            }
          } catch (e) {
          }
        } else {
          throw new Error("No authentication token available. Please sign in to use PrivacyPal.");
        }
        const requestBody = {
          data,
          sourceContainer: "browser_extension",
          metadata: {
            source: "chat_interceptor",
            platform: platform || "browser_extension",
            model: model || null,
            files: files || [],
            // Include file information
            timestamp: Date.now()
          }
        };
        if (sessionContinuationId) {
          requestBody.sessionContinuationId = sessionContinuationId;
        }
        try {
          await chrome.storage.local.get(["keepAlive"]);
        } catch (e) {
        }
        console.log("[PrivacyPal] Making encode request from service worker:", {
          url: `${apiUrl}/api/scanner/encode`,
          hasSelf: typeof self !== "undefined",
          hasWindow: typeof self !== "undefined",
          hasDocument: typeof document !== "undefined"
        });
        const keepAliveInterval = setInterval(() => {
          try {
            chrome.storage.local.get(["keepAlive"], () => {
            });
          } catch (e) {
          }
        }, 1e3);
        let response;
        try {
          response = await fetch(`${apiUrl}/api/scanner/encode`, {
            method: "POST",
            headers,
            body: JSON.stringify(requestBody),
            signal: controller.signal,
            // Explicitly set mode to ensure Edge recognizes this as extension-origin request
            // With host_permissions, this should bypass CORS, but Edge may need explicit mode
            mode: "cors",
            credentials: "omit",
            // Don't send cookies, but may help Edge recognize context
            cache: "no-cache"
            // Ensure fresh request
          });
        } catch (fetchError) {
          const errorMsg = fetchError.message || String(fetchError) || "Unknown error";
          const isCorsError = errorMsg.includes("CORS") || errorMsg.includes("cors") || errorMsg.includes("Access-Control");
          console.error("[PrivacyPal] Fetch error in service worker:", {
            error: errorMsg,
            errorName: fetchError.name,
            url: `${apiUrl}/api/scanner/encode`,
            isCorsError,
            note: isCorsError ? "CORS errors should NOT occur in service workers. This suggests Edge is executing fetch from wrong context." : "Non-CORS error"
          });
          if (isCorsError) {
            throw new Error(`CORS error in service worker (unexpected): ${errorMsg}. This may be an Edge-specific issue where service worker fetches are being treated as content script requests.`);
          }
          throw fetchError;
        } finally {
          clearInterval(keepAliveInterval);
        }
        clearTimeout(timeoutId);
        if (!response.ok) {
          const errorText = await response.text();
          let errorDetails;
          try {
            errorDetails = JSON.parse(errorText);
          } catch {
            errorDetails = { raw: errorText };
          }
          if (response.status === 401) {
            const storage = await chrome.storage.local.get(["privacypal_session"]);
            if (storage.privacypal_session?.jwtTokens?.access_token) {
              const config = await loadConfig();
              try {
                const refreshResponse = await fetch(`${config.apiUrl}/api/user/refresh-token`, {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({ token: storage.privacypal_session.jwtTokens.access_token })
                });
                if (refreshResponse.ok) {
                  const refreshData = await refreshResponse.json();
                  const newToken = refreshData.data?.token || refreshData.token;
                  if (newToken) {
                    storage.privacypal_session.jwtTokens.access_token = newToken;
                    storage.privacypal_session.jwtTokens.expires_at = Date.now() + 28800 * 1e3;
                    await chrome.storage.local.set({ privacypal_session: storage.privacypal_session });
                    const retryHeaders = {
                      "Content-Type": "application/json",
                      "x-access-token": newToken
                    };
                    const retryController = new AbortController();
                    const retryTimeoutId = setTimeout(() => retryController.abort(), 6e4);
                    const retryResponse = await fetch(`${apiUrl}/api/scanner/encode`, {
                      method: "POST",
                      headers: retryHeaders,
                      body: JSON.stringify({
                        data,
                        sourceContainer: "browser_extension",
                        metadata: {
                          source: "chat_interceptor",
                          platform: platform || "browser_extension",
                          timestamp: Date.now()
                        }
                      }),
                      signal: retryController.signal
                    });
                    clearTimeout(retryTimeoutId);
                    if (retryResponse.ok) {
                      const retryResult = await retryResponse.json();
                      return { success: true, data: retryResult };
                    }
                  }
                }
              } catch (refreshError) {
              }
            }
            const errorMsg = errorDetails?.message || errorDetails?.error || errorText;
            throw new Error(`Authentication failed (401). Token expired or invalid. Please sign in again. Details: ${errorMsg}`);
          }
          throw new Error(`Encode API returned ${response.status}: ${errorText}`);
        }
        const result = await response.json();
        return { success: true, data: result };
      } catch (fetchError) {
        clearTimeout(timeoutId);
        if (fetchError.name === "AbortError") {
          throw new Error("Encode request timed out after 60 seconds");
        }
        if (fetchError.message && fetchError.message.includes("CORS")) {
          console.error("[PrivacyPal] CORS error in service worker - this should not happen. Error:", fetchError);
          throw new Error(`CORS error: Service worker requests should not be subject to CORS. This may be an Edge-specific issue. Original error: ${fetchError.message}`);
        }
        throw fetchError;
      }
    } catch (error) {
      throw error;
    }
  }
  async function proxyDecodeRequest(data, continuationId, hashes, apiUrl, apiKey) {
    try {
      if (!apiKey) {
        throw new Error("No API key provided for decode request");
      }
      const response = await fetch(`${apiUrl}/api/scanner/decode`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-access-token": apiKey
        },
        body: JSON.stringify({
          continuationId,
          data,
          sensitiveHashes: hashes,
          authorization: {
            token: apiKey,
            purpose: "Browser Extension - Decode AI Response",
            type: "jwt"
          }
        }),
        // Edge may require explicit fetch options to recognize service worker context
        mode: "cors",
        credentials: "omit",
        cache: "no-cache"
      });
      if (!response.ok) {
        throw new Error(`Decode API returned ${response.status}`);
      }
      const result = await response.json();
      return { success: true, data: result };
    } catch (error) {
      return { success: false, error: error.message };
    }
  }
  async function proxyEncodeFileRequest(fileData, fileName, apiUrl, apiKey, platform = null, fileSize = null, fileType = null) {
    try {
      if (!fileData) {
        throw new Error("No file data provided for encode request");
      }
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 6e4);
      try {
        try {
          await chrome.storage.local.get(["keepAlive"]);
        } catch (e) {
        }
        console.log("[PrivacyPal] Making file encode request from service worker:", {
          url: `${apiUrl}/api/scanner/encode`
        });
        const keepAliveInterval = setInterval(() => {
          try {
            chrome.storage.local.get(["keepAlive"], () => {
            });
          } catch (e) {
          }
        }, 1e3);
        let response;
        try {
          response = await fetch(`${apiUrl}/api/scanner/encode`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              ...apiKey ? { "x-access-token": apiKey } : {}
            },
            body: JSON.stringify({
              data: fileData,
              sourceContainer: "browser_extension",
              sourceElement: "file_upload",
              metadata: {
                source: "file_upload",
                platform: platform || "browser_extension",
                fileName,
                fileSize,
                fileType,
                timestamp: Date.now()
              }
            }),
            signal: controller.signal,
            // Explicitly set mode to ensure Edge recognizes this as extension-origin request
            // With host_permissions, this should bypass CORS, but Edge may need explicit mode
            mode: "cors",
            credentials: "omit",
            // Don't send cookies, but may help Edge recognize context
            cache: "no-cache"
            // Ensure fresh request
          });
        } finally {
          clearInterval(keepAliveInterval);
        }
        clearTimeout(timeoutId);
        if (!response.ok) {
          const errorText = await response.text();
          throw new Error(`Encode API returned ${response.status}: ${errorText}`);
        }
        const result = await response.json();
        return { success: true, data: result };
      } catch (fetchError) {
        clearTimeout(timeoutId);
        if (fetchError.name === "AbortError") {
          throw new Error("File encode request timed out after 60 seconds");
        }
        if (fetchError.message && fetchError.message.includes("CORS")) {
          console.error("[PrivacyPal] CORS error in service worker - this should not happen. Error:", fetchError);
          throw new Error(`CORS error: Service worker requests should not be subject to CORS. This may be an Edge-specific issue. Original error: ${fetchError.message}`);
        }
        throw fetchError;
      }
    } catch (error) {
      return { success: false, error: error.message || String(error) };
    }
  }
  async function proxyUpdateAuditTokens(continuationId, tokensIn, tokensOut, model, apiUrl, apiKey) {
    try {
      if (!continuationId) {
        throw new Error("No continuationId provided");
      }
      const response = await fetch(`${apiUrl}/api/company/audit-logs/update-tokens`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-access-token": apiKey
        },
        body: JSON.stringify({
          continuationId,
          tokensIn: parseInt(tokensIn) || 0,
          tokensOut: parseInt(tokensOut) || 0,
          model: model || null
        })
      });
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Update tokens API returned ${response.status}: ${errorText}`);
      }
      const result = await response.json();
      return { success: true, data: result };
    } catch (error) {
      return { success: false, error: error.message || String(error) };
    }
  }
})();
