PrivacyPal brand assets

Full guidelines: https://privacypal.ai/brand/

logo/      the lockup: logo (light grounds) and logo-white (navy and dark photos), SVG and PNG
penguin/   the logo mark on its own: the Twemoji penguin emoji, unaltered (SVG, PNG 64 to 2048),
           and Twemoji's own source file (source/)
app-icon/  the penguin on the white rounded tile (app icon, avatars) and the favicon
social/    the profile picture (platforms crop it to a circle), LinkedIn, X and YouTube banners,
           square post examples

The penguin and its credit
The mark is the penguin emoji (U+1F427) from Twemoji v17.0.3, Copyright Twitter, Inc. and
other contributors, licensed under CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/).
Source: https://github.com/jdecked/twemoji
Credit it wherever you publish it, in a way that fits the medium: this line in the small print,
or a link to https://privacypal.ai/brand/, which carries it.
  Penguin emoji graphic from Twemoji, © Twitter, Inc. and other contributors, licensed under CC BY 4.0.
The penguin artwork is not exclusive to PrivacyPal. The PrivacyPal marks are the
"🐧 PrivacyPal" lockup and the PrivacyPal word mark.

Rules in short
1. Use the files. Never redraw, recolor, flip, outline or restyle the penguin, and never use
   Apple's or another vendor's emoji artwork.
2. Clear space around the logo equals the height of the penguin, on every side.
3. Below 120px wide on screen, use the penguin alone (penguin.svg) or the app icon.
4. On navy or dark photography use logo-white: the penguin keeps its colors, the wordmark turns
   white. Never whiten the logo with a filter. No gold tile.
5. Colors: Deep Navy #01204E, Signal Teal #028391, Penguin Gold #FFAC33.
6. Packs: Personal (free), Family and Max. The product is PrivacyPal.

Questions: press@privacypal.ai
